# TAPAS GUI (Home -> steps)

options(shiny.maxRequestSize = 500 * 1024^2) # 500 MB

.tapas_norm_path <- function(x) {
  x <- as.character(x)
  x[is.na(x)] <- ""
  x <- trimws(x)
  if (!nzchar(x)) return(NA_character_)
  normalizePath(x, winslash = "/", mustWork = FALSE)
}

.tapas_rscript_bin <- function() {
  file.path(R.home("bin"), if (.Platform$OS.type == "windows") "Rscript.exe" else "Rscript")
}

.tapas_capture <- function(expr) {
  msgs <- character(0)
  out <- character(0)
  ok <- TRUE
  err <- NULL
  res <- NULL

  expr_sub <- substitute(expr)

  res <- tryCatch(
    withCallingHandlers(
      {
        out <<- capture.output(
          {
            res <<- eval(expr_sub, envir = parent.frame())
          },
          type = "output"
        )
        res
      },
      message = function(m) {
        msgs <<- c(msgs, paste0("[MESSAGE] ", conditionMessage(m)))
        invokeRestart("muffleMessage")
      },
      warning = function(w) {
        msgs <<- c(msgs, paste0("[WARNING] ", conditionMessage(w)))
        invokeRestart("muffleWarning")
      }
    ),
    error = function(e) {
      ok <<- FALSE
      err <<- conditionMessage(e)
      NULL
    }
  )

  list(ok = ok, res = res, log = paste(c(out, msgs), collapse = "\n"), err = err)
}

# Launch a TAPAS GUI function (another Shiny app) in a separate R process.
.tapas_launch_external <- function(fun, args = list(), save_return_rds = NULL) {
  if (!is.character(fun) || length(fun) != 1L || !nzchar(fun)) stop("fun must be a non-empty string")
  rscript <- .tapas_rscript_bin()
  if (!file.exists(rscript)) stop("Rscript not found: ", rscript)
  
  tmp <- tempfile("tapas_ext_")
  dir.create(tmp, recursive = TRUE, showWarnings = FALSE)
  
  script <- file.path(tmp, "run.R")
  logf   <- file.path(tmp, "run.log")
  
  arg_code <- paste(capture.output(dput(args)), collapse = "\n")
  
  save_code <- ""
  if (!is.null(save_return_rds) && nzchar(save_return_rds)) {
    save_return_rds <- .tapas_norm_path(save_return_rds)
    save_code <- paste0("\ntry(saveRDS(res, ", dput(save_return_rds), "), silent = TRUE)\n")
  }
  
  # 关键：把当前会话的 libPaths 注入到子进程（避免 Rscript 找不到 TAPAS）
  lib_code <- paste(capture.output(dput(.libPaths())), collapse = "\n")
  
  lines <- c(
    paste0(".libPaths(", lib_code, ")"),
    # 关键：让子进程把 URL 明确打印出来（并尝试打开浏览器）
    "options(shiny.viewer = NULL)",
    "options(shiny.launch.browser = function(url){",
    "  cat('TAPAS_LISTENING_ON ', url, '\\n', sep='')",
    "  flush.console()",
    "  try(utils::browseURL(url), silent = TRUE)",
    "})",
    "suppressPackageStartupMessages(library(TAPAS))",
    paste0("args <- ", arg_code),
    paste0("res <- do.call(TAPAS::", fun, ", args)"),
    save_code,
    "invisible(NULL)"
  )
  writeLines(lines, script, useBytes = TRUE)
  
  # 不要吞错：把 stdout/stderr 写到 log（主 GUI 里至少能告诉用户 log 在哪）
  ok <- TRUE
  err <- NULL
  tryCatch({
    system2(rscript, args = c("--vanilla", shQuote(script)),
            wait = FALSE, stdout = logf, stderr = logf)
  }, error = function(e) {
    ok <<- FALSE
    err <<- conditionMessage(e)
  })
  
  invisible(list(
    script = script,
    log = logf,
    save_return_rds = save_return_rds,
    rscript = rscript,
    ok = ok,
    err = err
  ))
}


if (!requireNamespace("shiny", quietly = TRUE)) stop("Package 'shiny' is required.")
if (!requireNamespace("DT", quietly = TRUE)) stop("Package 'DT' is required.")

library(shiny)

ui <- navbarPage(
  title = "TAPAS GUI",
  id = "tapas_tab",

  tabPanel(
    "Home",
    fluidPage(
      tags$style(".tapas-card{padding:14px;border:1px solid #ddd;border-radius:10px;margin-bottom:12px} .tapas-title{font-weight:600;font-size:16px;margin-bottom:8px}"),
      fluidRow(
        column(
          6,
          div(class = "tapas-card",
              div(class = "tapas-title", "Prepare FASTA for prediction"),
              actionButton("go_fasta", "Open FASTA builder")),
          div(class = "tapas-card",
              div(class = "tapas-title", "Class I"),
              actionButton("go_c1_s1", "Stage 1"),
              actionButton("go_c1_filter", "Filter"),
              actionButton("go_c1_s2", "Stage 2"),
              actionButton("go_c1_manual", "Manual assembly"))
        ),
        column(
          6,
          div(class = "tapas-card",
              div(class = "tapas-title", "Class II"),
              actionButton("go_c2_s1", "Stage 1"),
              actionButton("go_c2_filter", "Filter"),
              actionButton("go_c2_s2", "Stage 2"),
              actionButton("go_c2_manual", "Manual assembly")),
          div(class = "tapas-card",
              div(class = "tapas-title", "Session"),
              verbatimTextOutput("session_last_paths"))
        )
      )
    )
  ),

  tabPanel(
    "FASTA",
    fluidPage(
      h4("FASTA builder (GUI)"),
      p("This opens the existing TAPAS FASTA builder in a separate window."),
      textInput("fasta_out_dir", "Output directory", value = tempdir()),
      textInput("fasta_3ca_default", "Default 3CA xlsx path (optional)", value = ""),
      actionButton("launch_fasta_builder", "Launch FASTA builder"),
      tags$hr(),
      verbatimTextOutput("fasta_launch_info")
    )
  ),

  tabPanel(
    "Class I - Stage 1",
    sidebarLayout(
      sidebarPanel(
        textInput("c1_s1_in_dir", "NetMHCpan output directory (in_dir)", value = ""),
        textInput("c1_s1_fasta", "Protein FASTA used for mapping (fasta_file)", value = ""),
        textInput("c1_s1_out_dir", "Output directory (out_dir)", value = ""),
        textInput("c1_s1_out_base", "Output base (out_base)", value = "s1"),
        numericInput("c1_s1_rank_thr", "Rank threshold (rank_thr)", value = 0.5, min = 0, step = 0.01),
        checkboxInput("c1_s1_recursive", "Search in_dir recursively", value = FALSE),
        numericInput("c1_s1_exclude_last", "Exclude last N columns when flattening", value = 2, min = 0, step = 1),
        checkboxInput("c1_s1_overwrite", "Overwrite cleaned outputs", value = TRUE),
        tags$hr(),
        checkboxInput("c1_s1_use_athena", "Use ATHENA filter", value = FALSE),
        textInput("c1_s1_athena_file", "ATHENA file (optional)", value = ""),
        numericInput("c1_s1_athena_thr", "ATHENA threshold", value = NA_real_, step = 0.01),
        checkboxInput("c1_s1_want_supertypes", "Want supertypes", value = FALSE),
        actionButton("run_c1_s1", "Run Class I Stage 1"),
        tags$hr(),
        actionButton("use_c1_s1_to_c1_filter", "Use Stage1 outputs in Filter tab"),
        actionButton("use_c1_s1_to_c1_s2", "Use Stage1 outputs in Stage2 tab")
      ),
      mainPanel(
        h4("Run log"),
        verbatimTextOutput("c1_s1_log"),
        tags$hr(),
        h4("Outputs"),
        DT::DTOutput("c1_s1_outputs")
      )
    )
  ),

  tabPanel(
    "Class I - Filter",
    fluidPage(
      h4("Interactive filter (GUI)"),
      p("This opens the existing TAPAS filter GUI in a separate window. After exporting, a small return RDS is written so you can load paths back here."),
      textInput("c1_filter_stage1_state", "Stage1 state RDS (stage1_state_rds)", value = ""),
      textInput("c1_filter_stage1_tsv", "Stage1 peptide TSV (stage1_tsv; used if state not provided)", value = ""),
      textInput("c1_filter_tpm", "TPM xlsx (optional)", value = ""),
      textInput("c1_filter_threeca", "3CA xlsx (optional)", value = ""),
      textInput("c1_filter_threeca_sheet", "3CA sheet (optional)", value = ""),
      textInput("c1_filter_out_dir", "Output directory (out_dir)", value = ""),
      textInput("c1_filter_out_base", "Output base (out_base)", value = "filtered"),
      actionButton("launch_c1_filter", "Launch Filter GUI"),
      tags$hr(),
      h4("Load Filter return RDS"),
      textInput("c1_filter_return_rds", "Return RDS path (written by launcher)", value = ""),
      actionButton("load_c1_filter_return", "Load return RDS"),
      tags$hr(),
      actionButton("use_c1_filter_to_c1_s2", "Use filtered Stage1 state in Stage2 tab"),
      verbatimTextOutput("c1_filter_info"),
      DT::DTOutput("c1_filter_outputs")
    )
  ),

  tabPanel(
    "Class I - Stage 2",
    sidebarLayout(
      sidebarPanel(
        textInput("c1_s2_stage1_state", "Filtered Stage1 state RDS (stage1_state_rds)", value = ""),
        checkboxInput("c1_s2_use_netchop", "Use NetChop boundary scores", value = TRUE),
        textInput("c1_s2_netchop_txt", "NetChop output txt (netchop_txt)", value = ""),
        numericInput("c1_s2_netchop_thr", "NetChop threshold (netchop_thr)", value = 0.5, min = 0, max = 1, step = 0.01),
        textInput("c1_s2_out_dir", "Output directory (out_dir)", value = ""),
        textInput("c1_s2_out_base", "Output base (out_base)", value = "s2"),
        numericInput("c1_s2_n_chains", "Number of chains (n_chains)", value = 4, min = 1, step = 1),
        numericInput("c1_s2_max_chain_AA", "Max chain length AA (max_chain_AA)", value = 100, min = 1, step = 1),
        checkboxInput("c1_s2_use_maximize", "Maximize (try all start peptides)", value = TRUE),
        checkboxInput("c1_s2_verbose", "Verbose", value = TRUE),
        checkboxInput("c1_s2_overwrite", "Overwrite outputs", value = TRUE),
        actionButton("run_c1_s2", "Run Class I Stage 2"),
        tags$hr(),
        actionButton("use_c1_s2_to_c1_manual", "Use Stage2 state in Manual Assembly tab")
      ),
      mainPanel(
        h4("Run log"),
        verbatimTextOutput("c1_s2_log"),
        tags$hr(),
        h4("Outputs"),
        DT::DTOutput("c1_s2_outputs")
      )
    )
  ),

  tabPanel(
    "Class I - Manual",
    fluidPage(
      h4("Manual assembly (GUI)"),
      p("This opens the existing TAPAS manual assembly GUI in a separate window."),
      textInput("c1_manual_stage2_state", "Stage2 state RDS (stage2_state_rds)", value = ""),
      textInput("c1_manual_out_base", "Output base (out_base)", value = "manual_assembly"),
      checkboxInput("c1_manual_use_netchop", "Use NetChop mode (override)", value = TRUE),
      actionButton("launch_c1_manual", "Launch Manual Assembly GUI"),
      tags$hr(),
      verbatimTextOutput("c1_manual_info")
    )
  ),

  tabPanel(
    "Class II - Stage 1",
    sidebarLayout(
      sidebarPanel(
        textInput("c2_s1_in_dir", "NetMHCIIpan output directory (in_dir)", value = ""),
        textInput("c2_s1_fasta", "Protein FASTA used for mapping (fasta_file)", value = ""),
        textInput("c2_s1_out_dir", "Output directory (out_dir)", value = ""),
        textInput("c2_s1_out_base", "Output base (out_base)", value = "s1_classII"),
        numericInput("c2_s1_rank_thr", "Rank threshold (rank_thr)", value = 0.25, min = 0, step = 0.01),
        numericInput("c2_s1_len_min", "Peptide length min", value = 13, min = 1, step = 1),
        numericInput("c2_s1_len_max", "Peptide length max", value = 25, min = 1, step = 1),
        checkboxInput("c2_s1_recursive", "Search in_dir recursively", value = FALSE),
        numericInput("c2_s1_exclude_last", "Exclude last N columns when flattening", value = 2, min = 0, step = 1),
        checkboxInput("c2_s1_overwrite", "Overwrite cleaned outputs", value = TRUE),
        actionButton("run_c2_s1", "Run Class II Stage 1"),
        tags$hr(),
        actionButton("use_c2_s1_to_c2_filter", "Use Stage1 outputs in Filter tab"),
        actionButton("use_c2_s1_to_c2_s2", "Use Stage1 outputs in Stage2 tab")
      ),
      mainPanel(
        h4("Run log"),
        verbatimTextOutput("c2_s1_log"),
        tags$hr(),
        h4("Outputs"),
        DT::DTOutput("c2_s1_outputs")
      )
    )
  ),

  tabPanel(
    "Class II - Filter",
    fluidPage(
      h4("Interactive filter (GUI)"),
      p("Uses the same filter GUI (gene-level)."),
      textInput("c2_filter_stage1_state", "Stage1 state RDS (stage1_state_rds)", value = ""),
      textInput("c2_filter_stage1_tsv", "Stage1 peptide TSV (stage1_tsv; used if state not provided)", value = ""),
      textInput("c2_filter_tpm", "TPM xlsx (optional)", value = ""),
      textInput("c2_filter_threeca", "3CA xlsx (optional)", value = ""),
      textInput("c2_filter_threeca_sheet", "3CA sheet (optional)", value = ""),
      textInput("c2_filter_out_dir", "Output directory (out_dir)", value = ""),
      textInput("c2_filter_out_base", "Output base (out_base)", value = "filtered_classII"),
      actionButton("launch_c2_filter", "Launch Filter GUI"),
      tags$hr(),
      h4("Load Filter return RDS"),
      textInput("c2_filter_return_rds", "Return RDS path (written by launcher)", value = ""),
      actionButton("load_c2_filter_return", "Load return RDS"),
      tags$hr(),
      actionButton("use_c2_filter_to_c2_s2", "Use filtered Stage1 state in Stage2 tab"),
      verbatimTextOutput("c2_filter_info"),
      DT::DTOutput("c2_filter_outputs")
    )
  ),

  tabPanel(
    "Class II - Stage 2",
    sidebarLayout(
      sidebarPanel(
        textInput("c2_s2_stage1_state", "Filtered Stage1 state RDS (stage1_state_rds)", value = ""),
        textInput("c2_s2_out_dir", "Output directory (out_dir)", value = ""),
        textInput("c2_s2_out_base", "Output base (out_base)", value = "s2_classII"),
        numericInput("c2_s2_n_chains", "Number of chains (n_chains)", value = 4, min = 1, step = 1),
        numericInput("c2_s2_max_chain_AA", "Max chain length AA (max_chain_AA)", value = 100, min = 1, step = 1),
        checkboxInput("c2_s2_use_maximize", "Maximize (try all start peptides)", value = TRUE),
        checkboxInput("c2_s2_overwrite", "Overwrite outputs", value = TRUE),
        actionButton("run_c2_s2", "Run Class II Stage 2"),
        tags$hr(),
        actionButton("use_c2_s2_to_c2_manual", "Use Stage2 state in Manual Assembly tab")
      ),
      mainPanel(
        h4("Run log"),
        verbatimTextOutput("c2_s2_log"),
        tags$hr(),
        h4("Outputs"),
        DT::DTOutput("c2_s2_outputs")
      )
    )
  ),

  tabPanel(
    "Class II - Manual",
    fluidPage(
      h4("Manual assembly (GUI)"),
      p("This opens the existing TAPAS Class II manual assembly GUI in a separate window."),
      textInput("c2_manual_stage2_state", "Stage2 state RDS (stage2_state_rds)", value = ""),
      textInput("c2_manual_out_base", "Output base (out_base)", value = "manual_assembly_classII"),
      actionButton("launch_c2_manual", "Launch Manual Assembly GUI"),
      tags$hr(),
      verbatimTextOutput("c2_manual_info")
    )
  )
)

server <- function(input, output, session) {
  `%||%` <- function(a, b) if (!is.null(a) && length(a) && !all(is.na(a))) a else b

  rv <- reactiveValues(
    last_c1_s1 = NULL,
    last_c1_filter = NULL,
    last_c1_s2 = NULL,
    last_c2_s1 = NULL,
    last_c2_filter = NULL,
    last_c2_s2 = NULL,
    last_fasta_launch = NULL,
    last_external = NULL
  )

  # ---- Home navigation ----
  observeEvent(input$go_fasta,       updateNavbarPage(session, "tapas_tab", selected = "FASTA"), ignoreInit = TRUE)
  observeEvent(input$go_c1_s1,       updateNavbarPage(session, "tapas_tab", selected = "Class I - Stage 1"), ignoreInit = TRUE)
  observeEvent(input$go_c1_filter,   updateNavbarPage(session, "tapas_tab", selected = "Class I - Filter"), ignoreInit = TRUE)
  observeEvent(input$go_c1_s2,       updateNavbarPage(session, "tapas_tab", selected = "Class I - Stage 2"), ignoreInit = TRUE)
  observeEvent(input$go_c1_manual,   updateNavbarPage(session, "tapas_tab", selected = "Class I - Manual"), ignoreInit = TRUE)
  observeEvent(input$go_c2_s1,       updateNavbarPage(session, "tapas_tab", selected = "Class II - Stage 1"), ignoreInit = TRUE)
  observeEvent(input$go_c2_filter,   updateNavbarPage(session, "tapas_tab", selected = "Class II - Filter"), ignoreInit = TRUE)
  observeEvent(input$go_c2_s2,       updateNavbarPage(session, "tapas_tab", selected = "Class II - Stage 2"), ignoreInit = TRUE)
  observeEvent(input$go_c2_manual,   updateNavbarPage(session, "tapas_tab", selected = "Class II - Manual"), ignoreInit = TRUE)

  # ---- Session summary ----
  output$session_last_paths <- renderText({
    lines <- character(0)
    if (!is.null(rv$last_c1_s1)) lines <- c(lines, paste0("Class I Stage1: ", rv$last_c1_s1$stage1_state_rds %||% ""))
    if (!is.null(rv$last_c1_filter)) lines <- c(lines, paste0("Class I Filter: ", rv$last_c1_filter$stage1_state_filtered_rds %||% ""))
    if (!is.null(rv$last_c1_s2)) lines <- c(lines, paste0("Class I Stage2: ", rv$last_c1_s2$stage2_state_rds %||% ""))
    if (!is.null(rv$last_c2_s1)) lines <- c(lines, paste0("Class II Stage1: ", rv$last_c2_s1$stage1_state_rds %||% ""))
    if (!is.null(rv$last_c2_filter)) lines <- c(lines, paste0("Class II Filter: ", rv$last_c2_filter$stage1_state_filtered_rds %||% ""))
    if (!is.null(rv$last_c2_s2)) lines <- c(lines, paste0("Class II Stage2: ", rv$last_c2_s2$stage2_state_rds %||% ""))
    if (!length(lines)) return("No steps run yet in this session.")
    paste(lines, collapse = "\n")
  })

  # ---- FASTA builder (external) ----
  observeEvent(input$launch_fasta_builder, {
    args <- list(out_dir = .tapas_norm_path(input$fasta_out_dir) %||% tempdir())
    if (nzchar(trimws(input$fasta_3ca_default))) {
      args$threeca_default_path <- input$fasta_3ca_default
    }
    rv$last_external <- .tapas_launch_external("fasta_for_prediction", args)
    rv$last_fasta_launch <- rv$last_external
    output$fasta_launch_info <- renderText({
      paste0("Launched. Script: ", rv$last_external$script)
    })
  }, ignoreInit = TRUE)

  # ---- Class I Stage 1 ----
  c1_s1_result <- reactiveVal(NULL)
  c1_s1_log <- reactiveVal("")

  observeEvent(input$run_c1_s1, {
    c1_s1_log("")
    c1_s1_result(NULL)

    args <- list(
      in_dir = .tapas_norm_path(input$c1_s1_in_dir),
      fasta_file = .tapas_norm_path(input$c1_s1_fasta),
      out_dir = .tapas_norm_path(input$c1_s1_out_dir),
      out_base = input$c1_s1_out_base,
      rank_thr = as.numeric(input$c1_s1_rank_thr),
      use_athena = isTRUE(input$c1_s1_use_athena),
      athena_file = .tapas_norm_path(input$c1_s1_athena_file),
      athena_thr = as.numeric(input$c1_s1_athena_thr),
      want_supertypes = isTRUE(input$c1_s1_want_supertypes),
      recursive = isTRUE(input$c1_s1_recursive),
      exclude_last = as.integer(input$c1_s1_exclude_last),
      overwrite = isTRUE(input$c1_s1_overwrite)
    )

    withProgress(message = "Running Class I Stage 1...", value = 0, {
      incProgress(0.2)
      cap <- .tapas_capture({ do.call(TAPAS::classI_stage1, args) })
      incProgress(0.8)
      if (!cap$ok) {
        c1_s1_log(paste0("ERROR: ", cap$err, "\n\n", cap$log))
        return(NULL)
      }
      res <- cap$res
      c1_s1_result(res)
      rv$last_c1_s1 <- res
      c1_s1_log(paste0(cap$log, if (nzchar(cap$log)) "\n\n" else "", "DONE."))
    })
  }, ignoreInit = TRUE)

  output$c1_s1_log <- renderText(c1_s1_log())
  output$c1_s1_outputs <- DT::renderDT({
    res <- c1_s1_result()
    if (is.null(res)) return(DT::datatable(data.frame(), options = list(pageLength = 5)))
    df <- data.frame(
      key = names(res),
      value = vapply(res, function(x) {
        if (is.null(x)) return(NA_character_)
        if (is.atomic(x) && length(x) == 1) return(as.character(x))
        if (is.data.frame(x)) return(paste0("<data.frame> n=", nrow(x)))
        paste0("<", class(x)[1], ">")
      }, character(1)),
      stringsAsFactors = FALSE
    )
    DT::datatable(df, rownames = FALSE, options = list(pageLength = 10))
  })

  observeEvent(input$use_c1_s1_to_c1_filter, {
    res <- rv$last_c1_s1
    if (is.null(res)) return(NULL)
    updateTextInput(session, "c1_filter_stage1_state", value = res$stage1_state_rds %||% "")
    updateTextInput(session, "c1_filter_stage1_tsv", value = res$peptide_tsv %||% "")
    updateTextInput(session, "c1_filter_out_dir", value = dirname(res$stage1_state_rds %||% res$peptide_tsv %||% ""))
  }, ignoreInit = TRUE)

  observeEvent(input$use_c1_s1_to_c1_s2, {
    res <- rv$last_c1_s1
    if (is.null(res)) return(NULL)
    updateTextInput(session, "c1_s2_stage1_state", value = res$stage1_state_rds %||% "")
    updateTextInput(session, "c1_s2_out_dir", value = dirname(res$stage1_state_rds %||% ""))
  }, ignoreInit = TRUE)

  # ---- Class I Filter (external) ----
  c1_filter_loaded <- reactiveVal(NULL)
  c1_filter_info <- reactiveVal("")

  observeEvent(input$launch_c1_filter, {
    out_dir <- .tapas_norm_path(input$c1_filter_out_dir)
    out_base <- input$c1_filter_out_base
    if (is.na(out_dir) || !nzchar(out_dir)) {
      c1_filter_info("ERROR: out_dir is required.")
      return(NULL)
    }
    dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
    ret_rds <- file.path(out_dir, paste0(out_base, "_filter_gui_return.rds"))

    args <- list(
      stage1_state_rds = .tapas_norm_path(input$c1_filter_stage1_state),
      stage1_tsv = .tapas_norm_path(input$c1_filter_stage1_tsv),
      tpm_xlsx = .tapas_norm_path(input$c1_filter_tpm),
      threeca_xlsx = .tapas_norm_path(input$c1_filter_threeca),
      threeca_sheet = input$c1_filter_threeca_sheet,
      out_dir = out_dir,
      out_base = out_base
    )

    rv$last_external <- .tapas_launch_external("classI_filter_gui", args, save_return_rds = ret_rds)
    updateTextInput(session, "c1_filter_return_rds", value = ret_rds)
    c1_filter_info(paste0("Launched. Return RDS will be written to: ", ret_rds))
  }, ignoreInit = TRUE)

  observeEvent(input$load_c1_filter_return, {
    p <- .tapas_norm_path(input$c1_filter_return_rds)
    if (is.na(p) || !file.exists(p)) {
      c1_filter_info("ERROR: return RDS not found.")
      c1_filter_loaded(NULL)
      return(NULL)
    }
    x <- tryCatch(readRDS(p), error = function(e) e)
    if (inherits(x, "error")) {
      c1_filter_info(paste0("ERROR reading RDS: ", x$message))
      c1_filter_loaded(NULL)
      return(NULL)
    }
    c1_filter_loaded(x)
    rv$last_c1_filter <- x
    c1_filter_info(paste0("Loaded: ", p))
  }, ignoreInit = TRUE)

  output$c1_filter_info <- renderText(c1_filter_info())
  output$c1_filter_outputs <- DT::renderDT({
    x <- c1_filter_loaded()
    if (is.null(x)) return(DT::datatable(data.frame(), options = list(pageLength = 5)))
    df <- data.frame(
      key = names(x),
      value = vapply(x, function(v) {
        if (is.null(v)) return(NA_character_)
        if (is.atomic(v) && length(v) == 1) return(as.character(v))
        paste0("<", class(v)[1], ">")
      }, character(1)),
      stringsAsFactors = FALSE
    )
    DT::datatable(df, rownames = FALSE, options = list(pageLength = 10))
  })

  observeEvent(input$use_c1_filter_to_c1_s2, {
    x <- rv$last_c1_filter
    if (is.null(x)) return(NULL)
    updateTextInput(session, "c1_s2_stage1_state", value = x$stage1_state_filtered_rds %||% "")
  }, ignoreInit = TRUE)

  # ---- Class I Stage 2 ----
  c1_s2_result <- reactiveVal(NULL)
  c1_s2_log <- reactiveVal("")

  observeEvent(input$run_c1_s2, {
    c1_s2_log("")
    c1_s2_result(NULL)

    args <- list(
      stage1_state_rds = .tapas_norm_path(input$c1_s2_stage1_state),
      netchop_txt = .tapas_norm_path(input$c1_s2_netchop_txt),
      use_netchop = isTRUE(input$c1_s2_use_netchop),
      out_dir = .tapas_norm_path(input$c1_s2_out_dir),
      out_base = input$c1_s2_out_base,
      netchop_thr = as.numeric(input$c1_s2_netchop_thr),
      n_chains = as.integer(input$c1_s2_n_chains),
      max_chain_AA = as.integer(input$c1_s2_max_chain_AA),
      use_maximize = isTRUE(input$c1_s2_use_maximize),
      verbose = isTRUE(input$c1_s2_verbose),
      overwrite = isTRUE(input$c1_s2_overwrite)
    )

    withProgress(message = "Running Class I Stage 2...", value = 0, {
      incProgress(0.2)
      cap <- .tapas_capture({ do.call(TAPAS::classI_stage2, args) })
      incProgress(0.8)
      if (!cap$ok) {
        c1_s2_log(paste0("ERROR: ", cap$err, "\n\n", cap$log))
        return(NULL)
      }
      res <- cap$res
      c1_s2_result(res)
      rv$last_c1_s2 <- res
      c1_s2_log(paste0(cap$log, if (nzchar(cap$log)) "\n\n" else "", "DONE."))
    })
  }, ignoreInit = TRUE)

  output$c1_s2_log <- renderText(c1_s2_log())
  output$c1_s2_outputs <- DT::renderDT({
    res <- c1_s2_result()
    if (is.null(res)) return(DT::datatable(data.frame(), options = list(pageLength = 5)))
    df <- data.frame(
      key = names(res),
      value = vapply(res, function(x) {
        if (is.null(x)) return(NA_character_)
        if (is.atomic(x) && length(x) == 1) return(as.character(x))
        paste0("<", class(x)[1], ">")
      }, character(1)),
      stringsAsFactors = FALSE
    )
    DT::datatable(df, rownames = FALSE, options = list(pageLength = 10))
  })

  observeEvent(input$use_c1_s2_to_c1_manual, {
    res <- rv$last_c1_s2
    if (is.null(res)) return(NULL)
    updateTextInput(session, "c1_manual_stage2_state", value = res$stage2_state_rds %||% "")
  }, ignoreInit = TRUE)

  # ---- Class I Manual (external) ----
  observeEvent(input$launch_c1_manual, {
    args <- list(
      stage2_state_rds = .tapas_norm_path(input$c1_manual_stage2_state),
      out_base = input$c1_manual_out_base,
      launch_browser = TRUE,
      use_netchop = isTRUE(input$c1_manual_use_netchop)
    )
    rv$last_external <- .tapas_launch_external("classI_manual_assembly_ui", args)
    output$c1_manual_info <- renderText({ paste0("Launched. Script: ", rv$last_external$script) })
  }, ignoreInit = TRUE)

  # ---- Class II Stage 1 ----
  c2_s1_result <- reactiveVal(NULL)
  c2_s1_log <- reactiveVal("")

  observeEvent(input$run_c2_s1, {
    c2_s1_log("")
    c2_s1_result(NULL)

    lr <- c(as.integer(input$c2_s1_len_min), as.integer(input$c2_s1_len_max))
    if (any(!is.finite(lr)) || lr[1] <= 0 || lr[2] < lr[1]) lr <- c(13L, 25L)

    args <- list(
      in_dir = .tapas_norm_path(input$c2_s1_in_dir),
      fasta_file = .tapas_norm_path(input$c2_s1_fasta),
      out_dir = .tapas_norm_path(input$c2_s1_out_dir),
      out_base = input$c2_s1_out_base,
      rank_thr = as.numeric(input$c2_s1_rank_thr),
      length_range = lr,
      recursive = isTRUE(input$c2_s1_recursive),
      exclude_last = as.integer(input$c2_s1_exclude_last),
      overwrite = isTRUE(input$c2_s1_overwrite)
    )

    withProgress(message = "Running Class II Stage 1...", value = 0, {
      incProgress(0.2)
      cap <- .tapas_capture({ do.call(TAPAS::classII_stage1, args) })
      incProgress(0.8)
      if (!cap$ok) {
        c2_s1_log(paste0("ERROR: ", cap$err, "\n\n", cap$log))
        return(NULL)
      }
      res <- cap$res
      c2_s1_result(res)
      rv$last_c2_s1 <- res
      c2_s1_log(paste0(cap$log, if (nzchar(cap$log)) "\n\n" else "", "DONE."))
    })
  }, ignoreInit = TRUE)

  output$c2_s1_log <- renderText(c2_s1_log())
  output$c2_s1_outputs <- DT::renderDT({
    res <- c2_s1_result()
    if (is.null(res)) return(DT::datatable(data.frame(), options = list(pageLength = 5)))
    df <- data.frame(
      key = names(res),
      value = vapply(res, function(x) {
        if (is.null(x)) return(NA_character_)
        if (is.atomic(x) && length(x) == 1) return(as.character(x))
        if (is.data.frame(x)) return(paste0("<data.frame> n=", nrow(x)))
        paste0("<", class(x)[1], ">")
      }, character(1)),
      stringsAsFactors = FALSE
    )
    DT::datatable(df, rownames = FALSE, options = list(pageLength = 10))
  })

  observeEvent(input$use_c2_s1_to_c2_filter, {
    res <- rv$last_c2_s1
    if (is.null(res)) return(NULL)
    updateTextInput(session, "c2_filter_stage1_state", value = res$stage1_state_rds %||% "")
    updateTextInput(session, "c2_filter_stage1_tsv", value = res$peptide_tsv %||% "")
    updateTextInput(session, "c2_filter_out_dir", value = dirname(res$stage1_state_rds %||% res$peptide_tsv %||% ""))
  }, ignoreInit = TRUE)

  observeEvent(input$use_c2_s1_to_c2_s2, {
    res <- rv$last_c2_s1
    if (is.null(res)) return(NULL)
    updateTextInput(session, "c2_s2_stage1_state", value = res$stage1_state_rds %||% "")
    updateTextInput(session, "c2_s2_out_dir", value = dirname(res$stage1_state_rds %||% ""))
  }, ignoreInit = TRUE)

  # ---- Class II Filter (external, reuse classI_filter_gui) ----
  c2_filter_loaded <- reactiveVal(NULL)
  c2_filter_info <- reactiveVal("")

  observeEvent(input$launch_c2_filter, {
    out_dir <- .tapas_norm_path(input$c2_filter_out_dir)
    out_base <- input$c2_filter_out_base
    if (is.na(out_dir) || !nzchar(out_dir)) {
      c2_filter_info("ERROR: out_dir is required.")
      return(NULL)
    }
    dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
    ret_rds <- file.path(out_dir, paste0(out_base, "_filter_gui_return.rds"))

    args <- list(
      stage1_state_rds = .tapas_norm_path(input$c2_filter_stage1_state),
      stage1_tsv = .tapas_norm_path(input$c2_filter_stage1_tsv),
      tpm_xlsx = .tapas_norm_path(input$c2_filter_tpm),
      threeca_xlsx = .tapas_norm_path(input$c2_filter_threeca),
      threeca_sheet = input$c2_filter_threeca_sheet,
      out_dir = out_dir,
      out_base = out_base
    )

    rv$last_external <- .tapas_launch_external("classI_filter_gui", args, save_return_rds = ret_rds)
    updateTextInput(session, "c2_filter_return_rds", value = ret_rds)
    c2_filter_info(paste0("Launched. Return RDS will be written to: ", ret_rds))
  }, ignoreInit = TRUE)

  observeEvent(input$load_c2_filter_return, {
    p <- .tapas_norm_path(input$c2_filter_return_rds)
    if (is.na(p) || !file.exists(p)) {
      c2_filter_info("ERROR: return RDS not found.")
      c2_filter_loaded(NULL)
      return(NULL)
    }
    x <- tryCatch(readRDS(p), error = function(e) e)
    if (inherits(x, "error")) {
      c2_filter_info(paste0("ERROR reading RDS: ", x$message))
      c2_filter_loaded(NULL)
      return(NULL)
    }
    c2_filter_loaded(x)
    rv$last_c2_filter <- x
    c2_filter_info(paste0("Loaded: ", p))
  }, ignoreInit = TRUE)

  output$c2_filter_info <- renderText(c2_filter_info())
  output$c2_filter_outputs <- DT::renderDT({
    x <- c2_filter_loaded()
    if (is.null(x)) return(DT::datatable(data.frame(), options = list(pageLength = 5)))
    df <- data.frame(
      key = names(x),
      value = vapply(x, function(v) {
        if (is.null(v)) return(NA_character_)
        if (is.atomic(v) && length(v) == 1) return(as.character(v))
        paste0("<", class(v)[1], ">")
      }, character(1)),
      stringsAsFactors = FALSE
    )
    DT::datatable(df, rownames = FALSE, options = list(pageLength = 10))
  })

  observeEvent(input$use_c2_filter_to_c2_s2, {
    x <- rv$last_c2_filter
    if (is.null(x)) return(NULL)
    updateTextInput(session, "c2_s2_stage1_state", value = x$stage1_state_filtered_rds %||% "")
  }, ignoreInit = TRUE)

  # ---- Class II Stage 2 ----
  c2_s2_result <- reactiveVal(NULL)
  c2_s2_log <- reactiveVal("")

  observeEvent(input$run_c2_s2, {
    c2_s2_log("")
    c2_s2_result(NULL)

    args <- list(
      stage1_state_rds = .tapas_norm_path(input$c2_s2_stage1_state),
      out_dir = .tapas_norm_path(input$c2_s2_out_dir),
      out_base = input$c2_s2_out_base,
      n_chains = as.integer(input$c2_s2_n_chains),
      max_chain_AA = as.integer(input$c2_s2_max_chain_AA),
      use_maximize = isTRUE(input$c2_s2_use_maximize),
      overwrite = isTRUE(input$c2_s2_overwrite)
    )

    withProgress(message = "Running Class II Stage 2...", value = 0, {
      incProgress(0.2)
      cap <- .tapas_capture({ do.call(TAPAS::classII_stage2, args) })
      incProgress(0.8)
      if (!cap$ok) {
        c2_s2_log(paste0("ERROR: ", cap$err, "\n\n", cap$log))
        return(NULL)
      }
      res <- cap$res
      c2_s2_result(res)
      rv$last_c2_s2 <- res
      c2_s2_log(paste0(cap$log, if (nzchar(cap$log)) "\n\n" else "", "DONE."))
    })
  }, ignoreInit = TRUE)

  output$c2_s2_log <- renderText(c2_s2_log())
  output$c2_s2_outputs <- DT::renderDT({
    res <- c2_s2_result()
    if (is.null(res)) return(DT::datatable(data.frame(), options = list(pageLength = 5)))
    df <- data.frame(
      key = names(res),
      value = vapply(res, function(x) {
        if (is.null(x)) return(NA_character_)
        if (is.atomic(x) && length(x) == 1) return(as.character(x))
        paste0("<", class(x)[1], ">")
      }, character(1)),
      stringsAsFactors = FALSE
    )
    DT::datatable(df, rownames = FALSE, options = list(pageLength = 10))
  })

  observeEvent(input$use_c2_s2_to_c2_manual, {
    res <- rv$last_c2_s2
    if (is.null(res)) return(NULL)
    updateTextInput(session, "c2_manual_stage2_state", value = res$stage2_state_rds %||% "")
  }, ignoreInit = TRUE)

  # ---- Class II Manual (external) ----
  observeEvent(input$launch_c2_manual, {
    args <- list(
      stage2_state_rds = .tapas_norm_path(input$c2_manual_stage2_state),
      out_base = input$c2_manual_out_base,
      launch_browser = TRUE
    )
    rv$last_external <- .tapas_launch_external("classII_manual_assembly_ui", args)
    output$c2_manual_info <- renderText({ paste0("Launched. Script: ", rv$last_external$script) })
  }, ignoreInit = TRUE)
}

shinyApp(ui, server)
