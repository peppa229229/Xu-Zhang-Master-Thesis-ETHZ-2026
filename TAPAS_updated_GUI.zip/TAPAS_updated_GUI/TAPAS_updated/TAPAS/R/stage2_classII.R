#' Stage2: assemble peptides into chains (Class II, no NetChop)
#'
#' Class II assembly does NOT use NetChop. The user only supplies:
#' - `n_chains`: maximum number of chains to build
#' - `max_chain_AA`: maximum amino-acid length per chain
#'
#' The default (use_maximize=TRUE) uses a deterministic first-fit-decreasing
#' packing strategy (sort peptides by length desc, then place into the first chain
#' with remaining capacity). This approximates maximizing total incorporated AA
#' under chain count and length constraints.
#'
#' Output format is compatible with the Class I downstream tooling, except that
#' NetChop-related fields are absent/NA.
#'
#' @param stage1_state_rds Filtered Stage1 state RDS.
#' @param out_dir Output directory.
#' @param out_base Output base name.
#' @param n_chains Maximum number of chains to build.
#' @param max_chain_AA Maximum AA length per chain.
#' @param use_maximize If TRUE, do first-fit-decreasing packing; else sequential packing.
#' @param verbose Print progress messages.
#' @param overwrite Overwrite outputs.
#' @return List of written output paths.
#' @export
classII_stage2 <- function(stage1_state_rds,
                           out_dir,
                           out_base = "classII_stage2",
                           n_chains = 10,
                           max_chain_AA = 250,
                           use_maximize = TRUE,
                           verbose = TRUE,
                           overwrite = TRUE) {

  stopifnot(is.character(stage1_state_rds), length(stage1_state_rds) == 1, nzchar(stage1_state_rds))
  if (!file.exists(stage1_state_rds)) stop("stage1_state_rds does not exist: ", stage1_state_rds)

  stopifnot(is.character(out_dir), length(out_dir) == 1, nzchar(out_dir))
  out_dir <- .ensure_dir(out_dir)

  n_chains <- suppressWarnings(as.integer(n_chains))
  max_chain_AA <- suppressWarnings(as.integer(max_chain_AA))
  if (!is.finite(n_chains) || n_chains < 1) stop("n_chains must be a positive integer.")
  if (!is.finite(max_chain_AA) || max_chain_AA < 1) stop("max_chain_AA must be a positive integer.")

  # output paths
  chain_tsv <- file.path(out_dir, paste0(out_base, "_chains.tsv"))
  edge_tsv  <- file.path(out_dir, paste0(out_base, "_edges.tsv"))
  unassigned_tsv <- file.path(out_dir, paste0(out_base, "_unassigned_peptides.tsv"))
  stage2_state_rds <- file.path(out_dir, paste0(out_base, "_stage2_state.rds"))

  if (!isTRUE(overwrite)) {
    for (p in c(chain_tsv, edge_tsv, unassigned_tsv, stage2_state_rds)) {
      if (file.exists(p)) stop("Output already exists (overwrite=FALSE): ", p)
    }
  }

  st1 <- readRDS(stage1_state_rds)
  pep <- st1$res_pep2_merged
  if (is.null(pep) || !is.data.frame(pep) || !nrow(pep)) stop("Stage1 state missing res_pep2_merged.")
  pep <- as.data.frame(pep, stringsAsFactors = FALSE)
  if (!"Peptide" %in% names(pep)) stop("Stage1 peptides missing 'Peptide' column.")

  # gene/protein annotation
  gene_candidates <- c("ProteinID.x", "ProteinID", "ID", "Gene", "HUGO")
  gene_col <- gene_candidates[gene_candidates %in% names(pep)][1]
  if (is.na(gene_col) || is.null(gene_col)) gene_col <- NULL

  pep$Peptide <- toupper(trimws(as.character(pep$Peptide)))
  if (!is.null(gene_col)) pep[[gene_col]] <- trimws(as.character(pep[[gene_col]]))

  pep_sources <- data.table::as.data.table(pep)
  pep_sources <- pep_sources[!is.na(Peptide) & nchar(Peptide) > 0]
  if (!is.null(gene_col)) {
    pep_sources[, GeneSrc := get(gene_col)]
  } else {
    pep_sources[, GeneSrc := NA_character_]
  }
  src_dt <- pep_sources[, .(
    source_proteins = {
      v <- unique(GeneSrc)
      v <- v[!is.na(v) & nzchar(v)]
      if (!length(v)) NA_character_ else paste(sort(v), collapse = ",")
    }
  ), by = "Peptide"]

  # peptide universe
  pep_universe <- sort(unique(src_dt$Peptide))
  pep_universe <- pep_universe[!is.na(pep_universe) & nzchar(pep_universe)]
  if (!length(pep_universe)) stop("No peptides found in Stage1 state.")

  # ---- chain packing ----
  .pack_ffd <- function(peptides, n_chains, max_chain_AA) {
    # sort by length desc, then lexicographic
    o <- order(-nchar(peptides), peptides)
    peptides <- peptides[o]

    chains <- vector("list", n_chains)
    lens <- integer(n_chains)
    for (i in seq_len(n_chains)) chains[[i]] <- character(0)

    unassigned <- character(0)

    for (p in peptides) {
      lp <- nchar(p)
      placed <- FALSE
      for (cid in seq_len(n_chains)) {
        if ((lens[cid] + lp) <= max_chain_AA) {
          chains[[cid]] <- c(chains[[cid]], p)
          lens[cid] <- lens[cid] + lp
          placed <- TRUE
          break
        }
      }
      if (!placed) unassigned <- c(unassigned, p)
    }

    list(chains = chains, lens = lens, unassigned = unassigned)
  }

  .pack_sequential <- function(peptides, n_chains, max_chain_AA) {
    chains <- vector("list", n_chains)
    lens <- integer(n_chains)
    for (i in seq_len(n_chains)) chains[[i]] <- character(0)

    cid <- 1L
    for (p in peptides) {
      lp <- nchar(p)
      if (cid > n_chains) break
      if (lens[cid] > 0L && (lens[cid] + lp) > max_chain_AA) {
        cid <- cid + 1L
        if (cid > n_chains) break
      }
      if (lp <= max_chain_AA) {
        chains[[cid]] <- c(chains[[cid]], p)
        lens[cid] <- lens[cid] + lp
      }
    }

    used <- unique(unlist(chains))
    unassigned <- setdiff(peptides, used)
    list(chains = chains, lens = lens, unassigned = unassigned)
  }

  if (isTRUE(verbose)) {
    message(sprintf(
      "Class II stage2: %d peptides, n_chains=%d, max_chain_AA=%d, use_maximize=%s",
      length(pep_universe), n_chains, max_chain_AA, ifelse(isTRUE(use_maximize), "TRUE", "FALSE")
    ))
  }

  pack <- if (isTRUE(use_maximize)) {
    .pack_ffd(pep_universe, n_chains = n_chains, max_chain_AA = max_chain_AA)
  } else {
    .pack_sequential(pep_universe, n_chains = n_chains, max_chain_AA = max_chain_AA)
  }

  chains <- pack$chains
  unused_peptides <- pack$unassigned

  # chain table
  src_map <- setNames(src_dt$source_proteins, src_dt$Peptide)

  chain_rows <- list()
  for (i in seq_along(chains)) {
    ch <- chains[[i]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    if (!length(ch)) next
    ch_len <- sum(nchar(ch))
    ch_seq <- paste0(ch, collapse = "")
    ch_peps <- paste(ch, collapse = "|")
    ch_src <- vapply(ch, function(p) {
      s <- unname(src_map[[p]])
      if (is.null(s) || is.na(s) || !nzchar(s)) "NA" else s
    }, character(1))
    chain_rows[[length(chain_rows) + 1L]] <- data.frame(
      chain_id = i,
      n_peptides = length(ch),
      chain_AA = ch_len,
      chain_sequence = ch_seq,
      peptides = ch_peps,
      peptide_sources = paste(ch_src, collapse = ";"),
      stringsAsFactors = FALSE
    )
  }

  if (length(chain_rows)) {
    chain_df <- do.call(rbind, chain_rows)
  } else {
    chain_df <- data.frame(
      chain_id = integer(0),
      n_peptides = integer(0),
      chain_AA = integer(0),
      chain_sequence = character(0),
      peptides = character(0),
      peptide_sources = character(0),
      stringsAsFactors = FALSE
    )
  }

  # edges table (no NetChop): record concatenations with NA score
  edge_rows <- list()
  k <- 0L
  for (cid in seq_along(chains)) {
    ch <- chains[[cid]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    if (length(ch) < 2) next
    for (step in 2:length(ch)) {
      k <- k + 1L
      edge_rows[[k]] <- data.frame(
        chain_id = cid,
        step = step - 1L,
        A = ch[[step - 1L]],
        B = ch[[step]],
        netchop_score_boundary = NA_real_,
        stringsAsFactors = FALSE
      )
    }
  }
  edges_df <- if (length(edge_rows)) do.call(rbind, edge_rows) else data.frame(
    chain_id = integer(0),
    step = integer(0),
    A = character(0),
    B = character(0),
    netchop_score_boundary = numeric(0),
    stringsAsFactors = FALSE
  )

  unassigned_df <- data.frame(
    Peptide = unused_peptides,
    pep_len = nchar(unused_peptides),
    source_proteins = unname(src_map[unused_peptides]),
    stringsAsFactors = FALSE
  )

  readr::write_tsv(chain_df, chain_tsv)
  readr::write_tsv(edges_df, edge_tsv)
  readr::write_tsv(unassigned_df, unassigned_tsv)

  saveRDS(
    list(
      stage1_state_rds = stage1_state_rds,
      chains = chains,
      chain_table = chain_df,
      edge_table = edges_df,
      unassigned_table = unassigned_df,
      peptide_sources = data.frame(Peptide = names(src_map), source_proteins = unname(src_map), stringsAsFactors = FALSE),
      pep_universe = pep_universe,
      n_chains = n_chains,
      max_chain_AA = max_chain_AA,
      use_maximize = isTRUE(use_maximize),
      use_netchop = FALSE,
      netchop_thr = NA_real_,
      edges_passing = data.frame(A = character(0), B = character(0), netchop_score_boundary = numeric(0), stringsAsFactors = FALSE)
    ),
    stage2_state_rds
  )

  invisible(list(
    chain_tsv = chain_tsv,
    edge_tsv = edge_tsv,
    unassigned_tsv = unassigned_tsv,
    stage2_state_rds = stage2_state_rds
  ))
}
