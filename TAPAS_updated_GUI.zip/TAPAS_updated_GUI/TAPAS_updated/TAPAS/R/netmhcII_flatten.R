# NetMHCIIpan cleaning -------------------------------------------------------
#
# These helpers are adapted from the netmhc2panpost package, but renamed to avoid
# clashing with the Class I NetMHCpan cleaning functions in this package.

# Internal: read xls/xlsx/tsv without assuming headers
.read_any_II <- function(path, want_header_only = FALSE) {
  ext <- tolower(tools::file_ext(path))

  try_read <- function(fun) {
    tryCatch(fun(path, col_names = FALSE), error = function(e) NULL)
  }

  raw <- switch(
    ext,
    "xlsx" = try_read(readxl::read_xlsx),
    "xls"  = try_read(readxl::read_xls),
    NULL
  )

  if (is.null(raw)) {
    raw <- tryCatch(
      read.delim(
        path,
        header = FALSE,
        sep = "\t",
        quote = "",
        check.names = FALSE,
        stringsAsFactors = FALSE,
        comment.char = ""
      ),
      error = function(e) NULL
    )
  }

  if (is.null(raw)) return(NULL)
  if (isTRUE(want_header_only)) return(raw[seq_len(min(2, nrow(raw))), , drop = FALSE])
  raw
}

# Internal: filename-based skip for NetMHCIIpan outputs
.should_skip_by_name_II <- function(bn) {
  if (grepl("(?i)^~\\$.*\\.xlsx$", bn, perl = TRUE)) return(TRUE)
  if (grepl("(?i)final_peptide_list", bn, perl = TRUE)) return(TRUE)
  if (grepl("(?i)\\bfinal\\b", bn, perl = TRUE)) return(TRUE)
  if (grepl("(?i)_cleaned\\.txt$", bn, perl = TRUE)) return(TRUE)
  FALSE
}

# Internal: sniff NetMHCIIpan-like tables (two-row header contains 'Core')
.is_netmhcII_like <- function(path) {
  bn <- basename(path)
  if (.should_skip_by_name_II(bn)) return(FALSE)
  hdr <- .read_any_II(path, want_header_only = TRUE)
  if (is.null(hdr) || ncol(hdr) < 3 || nrow(hdr) < 1) return(FALSE)
  hdr1 <- tolower(trimws(as.character(hdr[1, ])))
  hdr2 <- if (nrow(hdr) >= 2) tolower(trimws(as.character(hdr[2, ]))) else character(0)
  any(hdr2 == "core") || any(hdr1 == "core")
}

#' @keywords internal
flatten_netmhcII_file <- function(infile,
                                  outfile = sub("\\.(xls|xlsx)$", "_cleaned.txt", infile, ignore.case = TRUE),
                                  exclude_last = 2) {
  raw <- .read_any_II(infile, want_header_only = FALSE)
  if (is.null(raw)) stop("Cannot read file as Excel or TSV: ", infile)
  n <- ncol(raw)
  if (n < 3) stop("Input has too few columns: ", infile)
  if (exclude_last < 0 || exclude_last >= n) stop("exclude_last is invalid")

  hdr1 <- as.character(raw[1, ])
  hdr2 <- as.character(raw[2, ])

  hdr1[is.na(hdr1) | grepl("^\\s*$", hdr1)] <- NA_character_
  for (i in seq_len(n)) {
    if (i > 1 && is.na(hdr1[i])) hdr1[i] <- hdr1[i - 1]
  }

  start_idx <- which(tolower(trimws(hdr2)) == "core")[1]
  use_row <- 2L
  if (is.na(start_idx)) {
    start_idx <- which(tolower(trimws(hdr1)) == "core")[1]
    use_row <- 1L
  }
  if (is.na(start_idx)) stop("Header rows do not contain 'core' in: ", infile)

  rename_until <- n - exclude_last
  base_names <- hdr1
  leaf_names <- if (use_row == 2L) hdr2 else hdr1

  new_names <- leaf_names
  idx <- seq_len(n) >= start_idx & seq_len(n) <= rename_until &
    !is.na(leaf_names) & nzchar(leaf_names)
  new_names[idx] <- paste0(base_names[idx], "_", leaf_names[idx])
  new_names <- gsub("\\s+", "", new_names)

  dat <- raw[-c(1, 2), , drop = FALSE]
  colnames(dat) <- new_names

  # best-effort type conversion
  dat[] <- lapply(dat, function(x) {
    if (is.character(x)) type.convert(x, as.is = TRUE) else x
  })

  utils::write.table(dat, file = outfile, sep = "\t", quote = FALSE, row.names = FALSE)
  invisible(dat)
}

#' @keywords internal
process_netmhcII_dir <- function(dir,
                                 pattern = "(?i)\\.(xls|xlsx)$",
                                 recursive = FALSE,
                                 outdir = file.path(dir, "cleaned"),
                                 exclude_last = 2,
                                 overwrite = TRUE) {
  if (!dir.exists(dir)) stop("Directory not found: ", dir)
  outdir <- .ensure_dir(outdir)

  files_all <- list.files(dir, pattern = pattern, recursive = recursive, full.names = TRUE)
  if (!length(files_all)) stop("No xls/xlsx found in: ", dir)

  files_all <- files_all[!vapply(basename(files_all), .should_skip_by_name_II, logical(1))]
  files <- files_all[vapply(files_all, .is_netmhcII_like, logical(1))]
  if (!length(files)) {
    stop("No NetMHCIIpan-like xls/xlsx found (no 'Core' in the first two header rows).")
  }

  wrote_any <- FALSE
  for (f in files) {
    outname <- sub("(?i)\\.(xls|xlsx)$", "_cleaned.txt", basename(f), perl = TRUE)
    outfile <- file.path(outdir, outname)
    if (file.exists(outfile) && !isTRUE(overwrite)) next

    ok <- tryCatch(
      {
        flatten_netmhcII_file(f, outfile = outfile, exclude_last = exclude_last)
        TRUE
      },
      error = function(e) {
        msg <- conditionMessage(e)
        if (grepl("Header rows do not contain 'core'", msg, fixed = TRUE)) {
          message(sprintf("Skipped (no 'Core' header): %s", basename(f)))
        } else {
          message(sprintf("Failed to flatten %s (%s)", basename(f), msg))
        }
        FALSE
      }
    )

    if (isTRUE(ok) && file.exists(outfile)) {
      wrote_any <- TRUE
      message("Flattened: ", basename(f), " -> ", outfile)
    }
  }

  if (!wrote_any) stop("No cleaned outputs produced under: ", outdir)
  outdir
}

#' @keywords internal
read_cleanedII_dir <- function(cleaned_dir) {
  cleaned_files <- list.files(cleaned_dir, pattern = "(?i)_cleaned\\.txt$", full.names = TRUE)
  if (!length(cleaned_files)) stop("No *_cleaned.txt found under: ", cleaned_dir)

  dts <- lapply(cleaned_files, function(f) {
    dt <- tryCatch(
      data.table::fread(f, sep = "\t", header = TRUE, na.strings = c("", "NA")),
      error = function(e) NULL
    )
    if (is.null(dt)) return(NULL)
    dt$SourceFile <- basename(f)
    dt
  })

  dts <- dts[!vapply(dts, is.null, logical(1))]
  if (!length(dts)) stop("Failed to read any cleaned files in: ", cleaned_dir)
  data.table::rbindlist(dts, fill = TRUE, use.names = TRUE)
}
