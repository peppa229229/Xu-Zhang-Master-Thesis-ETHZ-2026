#' Stage 1: NetMHCIIpan post-processing -> peptide table (Class II)
#'
#' This function mirrors `classI_stage1()` but for NetMHCIIpan outputs:
#' - NetMHCIIpan exports are typically multiple xls/xlsx files with a two-row header;
#'   these are flattened to *_cleaned.txt and merged.
#' - A per-row winner allele/rank is computed as the minimum across *_Rank columns.
#' - Peptides are filtered by winner_rank < rank_thr and (optionally) by length range.
#' - Peptides are mapped to protein sequences from the provided FASTA, then merged
#'   into non-overlapping intervals per protein.
#'
#' Output format is compatible with `classI_filter_gui()`.
#'
#' @param in_dir Folder containing NetMHCIIpan xls/xlsx outputs.
#' @param fasta_file Protein FASTA used for peptide-to-protein mapping.
#' @param out_dir Output directory.
#' @param out_base Output base name (no extension).
#' @param rank_thr Keep rows with winner_rank < rank_thr.
#' @param length_range Optional integer vector length 2, e.g. c(13, 25). If NULL, no length filter.
#' @param recursive Whether to search in_dir recursively.
#' @param exclude_last How many trailing columns to exclude when flattening header.
#' @param overwrite Overwrite cleaned outputs.
#' @return A list of output paths and in-memory objects.
#' @export
classII_stage1 <- function(in_dir,
                           fasta_file,
                           out_dir,
                           out_base = "classII_stage1",
                           rank_thr = 0.25,
                           length_range = c(13, 25),
                           recursive = FALSE,
                           exclude_last = 2,
                           overwrite = TRUE) {

  stopifnot(is.character(in_dir), length(in_dir) == 1, nzchar(in_dir))
  stopifnot(is.character(fasta_file), length(fasta_file) == 1, nzchar(fasta_file))
  stopifnot(is.character(out_dir), length(out_dir) == 1, nzchar(out_dir))
  if (!dir.exists(in_dir)) stop("in_dir does not exist: ", in_dir)
  if (!file.exists(fasta_file)) stop("fasta_file does not exist: ", fasta_file)

  out_dir <- .ensure_dir(out_dir)

  # --- validate length_range ---
  if (!is.null(length_range)) {
    if (!is.numeric(length_range) || length(length_range) != 2) {
      stop("length_range must be NULL or a numeric vector of length 2 (e.g. c(13, 25)).")
    }
    length_range <- as.integer(length_range)
    if (any(!is.finite(length_range)) || length_range[1] <= 0 || length_range[2] < length_range[1]) {
      stop("length_range must be positive integers with length_range[2] >= length_range[1].")
    }
  }

  # 1) Flatten/clean NetMHCIIpan outputs
  cleaned_dir <- process_netmhcII_dir(
    dir = in_dir,
    recursive = recursive,
    outdir = file.path(in_dir, "cleaned"),
    exclude_last = exclude_last,
    overwrite = overwrite
  )

  # 2) Read merged cleaned tables
  dt <- read_cleanedII_dir(cleaned_dir)
  if (!nrow(dt)) stop("No rows found after reading cleaned NetMHCIIpan tables.")

  # 3) Standardize peptide column name if needed
  if (!("Peptide" %in% names(dt))) {
    pep_col <- grep("^Peptide$|peptide", names(dt), ignore.case = TRUE, value = TRUE)
    if (length(pep_col)) {
      data.table::setnames(dt, pep_col[1], "Peptide")
    }
  }
  if (!("Peptide" %in% names(dt))) stop("No 'Peptide' column after merging NetMHCIIpan tables.")

  dt$Peptide <- toupper(trimws(as.character(dt$Peptide)))
  dt <- dt[!is.na(Peptide) & nzchar(Peptide), ]
  if (!nrow(dt)) stop("No valid peptides after cleaning.")

  # 4) Winner allele/rank
  w <- compute_winner(dt)
  dt$winner_allele <- w$winner_allele
  dt$winner_rank   <- w$winner_rank

  # normalize allele formatting (remove suffix, remove leading HLA-)
  dt$winner_allele <- gsub("_Rank$", "", gsub("^HLA-", "", as.character(dt$winner_allele)))

  # 5) Filter by rank
  keep_idx <- !is.na(dt$winner_rank) & (dt$winner_rank < rank_thr)
  res <- dt[keep_idx, , drop = FALSE]
  if (!nrow(res)) stop("No peptides passed rank_thr = ", rank_thr)

  # 6) Optional length filter
  if (!is.null(length_range)) {
    L <- nchar(as.character(res$Peptide))
    res <- res[L >= length_range[1] & L <= length_range[2], , drop = FALSE]
    if (!nrow(res)) {
      stop(sprintf(
        "No peptides remained after length_range filter [%d, %d].",
        length_range[1], length_range[2]
      ))
    }
  }

  # keep first occurrence per peptide
  res <- res[!duplicated(res$Peptide), , drop = FALSE]

  # 7) Map peptides to FASTA proteins and positions
  aa <- Biostrings::readAAStringSet(fasta_file)
  prot_names <- names(aa)
  seq_lookup <- data.table::data.table(ProteinID = prot_names, full_seq = as.character(aa))

  peps <- unique(toupper(as.character(res$Peptide)))
  peps <- peps[!is.na(peps) & nzchar(peps)]
  if (!length(peps)) stop("No peptides after filtering / cleaning.")

  match_list <- lapply(peps, function(p) {
    mi <- Biostrings::vmatchPattern(Biostrings::AAString(p), aa, max.mismatch = 0, fixed = TRUE)
    hits <- lapply(seq_along(mi), function(i) {
      if (length(mi[[i]]) > 0) {
        data.table::data.table(
          Peptide   = p,
          ProteinID = prot_names[i],
          Pos_start = Biostrings::start(mi[[i]]),
          Pos_end   = Biostrings::end(mi[[i]])
        )
      } else NULL
    })
    data.table::rbindlist(hits, use.names = TRUE, fill = TRUE)
  })

  peptide_hits <- data.table::rbindlist(match_list, use.names = TRUE, fill = TRUE)
  if (!nrow(peptide_hits)) {
    stop("No peptides matched the FASTA. Check that fasta_file corresponds to the NetMHCIIpan input sequences.")
  }

  res_pep2 <- merge(as.data.frame(res), peptide_hits, by = "Peptide", all.x = TRUE)
  res_pep2 <- merge(res_pep2, seq_lookup, by = "ProteinID", all.x = TRUE)

  # 8) Merge overlapping intervals per ProteinID
  res_pep2_df <- as.data.frame(res_pep2, stringsAsFactors = FALSE)
  split_list <- split(res_pep2_df, res_pep2_df$ProteinID)
  merged_list <- lapply(split_list, merge_intervals_one)
  res_pep2_merged <- do.call(rbind, merged_list)
  if (is.null(res_pep2_merged) || nrow(res_pep2_merged) == 0) {
    stop("No merged intervals produced. Check FASTA mapping.")
  }

  # 9) Write peptide table
  tsv_path <- file.path(out_dir, paste0(out_base, "_res_pep2_merged.tsv"))
  readr::write_tsv(res_pep2_merged, tsv_path)

  # 10) Save stage1 state
  stage1_state_rds <- file.path(out_dir, paste0(out_base, "_stage1_state.rds"))
  saveRDS(
    list(
      res_pep2_merged = res_pep2_merged,
      tsv_path        = tsv_path,
      fasta_file      = fasta_file,
      cleaned_dir     = cleaned_dir,
      rank_thr        = rank_thr,
      length_range    = length_range
    ),
    stage1_state_rds
  )

  invisible(list(
    cleaned_dir      = cleaned_dir,
    peptide_tsv      = tsv_path,
    stage1_state_rds = stage1_state_rds,
    res_pep2_merged  = res_pep2_merged
  ))
}
