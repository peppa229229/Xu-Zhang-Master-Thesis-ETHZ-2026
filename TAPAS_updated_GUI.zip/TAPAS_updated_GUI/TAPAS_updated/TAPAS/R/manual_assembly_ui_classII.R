# Compared to classI_manual_assembly_ui():
# - No NetChop score / threshold
# - No insertion suggestions
# - Keeps gene highlight + gene constraints, plus simple manual add/remove

#' Launch the manual assembly Shiny UI (Class II)
#'
#' This UI allows editing chains for Class II without NetChop:
#' - View chain summaries and gene distribution
#' - Highlight peptides by gene
#' - Add gene constraints (gene -> allowed chain IDs) and rebuild chains under constraints
#' - Manually move peptides from unassigned to chain head/tail, or detach head/tail
#' - Export the current state as a zip
#'
#' @param stage2_state_rds Class II Stage2 state RDS (from `classII_stage2()`).
#' @param out_base Output base name used for the exported zip contents.
#' @param launch_browser Whether to open the browser.
#' @export
classII_manual_assembly_ui <- function(stage2_state_rds,
                                       out_base = "classII_manual",
                                       launch_browser = TRUE) {
  if (!requireNamespace("shiny", quietly = TRUE)) stop("Package 'shiny' is required.")
  if (!requireNamespace("DT", quietly = TRUE)) stop("Package 'DT' is required.")
  
  stopifnot(is.character(stage2_state_rds), length(stage2_state_rds) == 1, nzchar(stage2_state_rds))
  if (!file.exists(stage2_state_rds)) stop("stage2_state_rds does not exist: ", stage2_state_rds)
  
  st2 <- readRDS(stage2_state_rds)
  if (is.null(st2$chains) || !length(st2$chains)) stop("Stage2 state missing 'chains'.")
  if (is.null(st2$unassigned_table) || !is.data.frame(st2$unassigned_table)) {
    stop("Stage2 state missing 'unassigned_table'.")
  }
  
  # number of chains + max length from Stage2
  n_chains0 <- suppressWarnings(as.integer(st2$n_chains))
  if (!is.finite(n_chains0) || n_chains0 < 1) n_chains0 <- max(1L, length(st2$chains))
  
  default_max_chain_AA <- suppressWarnings(as.integer(st2$max_chain_AA))
  if (!is.finite(default_max_chain_AA) || default_max_chain_AA < 1) default_max_chain_AA <- 200L
  
  # peptide -> source proteins map
  src_map <- NULL
  if (!is.null(st2$peptide_sources) && is.data.frame(st2$peptide_sources)) {
    ps <- st2$peptide_sources
    if (all(c("Peptide", "source_proteins") %in% names(ps))) {
      src_map <- setNames(as.character(ps$source_proteins), toupper(trimws(as.character(ps$Peptide))))
    }
  }
  
  init_unassigned <- .ensure_unassigned_df(st2$unassigned_table)
  
  pep_universe_vec <- if (!is.null(st2$pep_universe)) {
    u <- toupper(trimws(as.character(st2$pep_universe)))
    u <- u[!is.na(u) & nzchar(u)]
    sort(unique(u))
  } else {
    u <- unique(c(unlist(st2$chains), init_unassigned$Peptide, if (!is.null(src_map)) names(src_map) else character(0)))
    u <- toupper(trimws(as.character(u)))
    u <- u[!is.na(u) & nzchar(u)]
    sort(unique(u))
  }
  
  all_genes <- .all_genes_from_src_map(src_map)
  
  # Helpers ------------------------------------------------------------------
  
  .chain_summary <- function(chains) {
    rows <- list(); k <- 0L
    for (i in seq_along(chains)) {
      ch <- chains[[i]]
      ch <- ch[!is.na(ch) & nzchar(ch)]
      k <- k + 1L
      ch_src <- if (length(ch)) {
        vapply(ch, function(p) {
          p2 <- toupper(trimws(as.character(p)))
          s <- if (!is.null(src_map)) unname(src_map[[p2]]) else NA_character_
          if (is.null(s) || is.na(s) || !nzchar(s)) "NA" else s
        }, character(1))
      } else {
        character(0)
      }
      
      rows[[k]] <- data.frame(
        chain_id = i,
        n_peptides = length(ch),
        chain_AA = if (length(ch)) sum(nchar(ch)) else 0L,
        peptides = if (length(ch)) paste(ch, collapse = "|") else "",
        peptide_sources = if (length(ch_src)) paste(ch_src, collapse = ";") else "",
        stringsAsFactors = FALSE
      )
    }
    do.call(rbind, rows)
  }
  
  .edges_from_chains_na <- function(chains) {
    rows <- list(); k <- 0L
    for (cid in seq_along(chains)) {
      ch <- chains[[cid]]
      ch <- ch[!is.na(ch) & nzchar(ch)]
      if (length(ch) < 2) next
      for (step in 2:length(ch)) {
        k <- k + 1L
        rows[[k]] <- data.frame(
          chain_id = cid,
          step = step - 1L,
          A = ch[[step - 1L]],
          B = ch[[step]],
          netchop_score_boundary = NA_real_,
          stringsAsFactors = FALSE
        )
      }
    }
    if (!length(rows)) {
      return(data.frame(
        chain_id = integer(0),
        step = integer(0),
        A = character(0),
        B = character(0),
        netchop_score_boundary = numeric(0),
        stringsAsFactors = FALSE
      ))
    }
    do.call(rbind, rows)
  }
  
  .allowed_chains_for_peptide <- function(pep, cons) {
    pep <- toupper(trimws(as.character(pep)))
    if (is.na(pep) || !nzchar(pep)) return(NULL)
    if (is.null(cons) || !length(cons)) return(NULL)
    
    genes <- .split_genes(.gene_for_peptide(pep, src_map))
    hit <- intersect(genes, names(cons))
    if (!length(hit)) return(NULL)
    
    allowed <- NULL
    for (g in hit) {
      v <- suppressWarnings(as.integer(cons[[g]]))
      v <- v[is.finite(v) & v >= 1]
      if (is.null(allowed)) allowed <- v else allowed <- intersect(allowed, v)
    }
    if (is.null(allowed)) allowed <- integer(0)
    sort(unique(allowed))
  }
  
  .rebuild_under_constraints <- function(all_peps, cons, n_chains, max_chain_AA) {
    all_peps <- toupper(trimws(as.character(all_peps)))
    all_peps <- all_peps[!is.na(all_peps) & nzchar(all_peps)]
    all_peps <- sort(unique(all_peps))
    
    # Sort by length desc for packing
    o <- order(-nchar(all_peps), all_peps)
    peps <- all_peps[o]
    
    chains <- vector("list", n_chains)
    lens <- integer(n_chains)
    for (i in seq_len(n_chains)) chains[[i]] <- character(0)
    
    unassigned <- character(0)
    
    for (p in peps) {
      lp <- nchar(p)
      if (lp > max_chain_AA) {
        unassigned <- c(unassigned, p)
        next
      }
      
      allowed <- .allowed_chains_for_peptide(p, cons)
      if (is.null(allowed)) {
        allowed <- seq_len(n_chains)
      } else {
        allowed <- suppressWarnings(as.integer(allowed))
        allowed <- allowed[is.finite(allowed) & allowed >= 1 & allowed <= n_chains]
        if (!length(allowed)) {
          unassigned <- c(unassigned, p)
          next
        }
      }
      
      placed <- FALSE
      for (cid in allowed) {
        if ((lens[cid] + lp) <= max_chain_AA) {
          chains[[cid]] <- c(chains[[cid]], p)
          lens[cid] <- lens[cid] + lp
          placed <- TRUE
          break
        }
      }
      if (!placed) unassigned <- c(unassigned, p)
    }
    
    list(chains = chains, unassigned = unassigned)
  }
  
  # UI -----------------------------------------------------------------------
  
  ui <- shiny::fluidPage(
    shiny::titlePanel("Manual assembly: Class II (no NetChop)"),
    shiny::fluidRow(
      shiny::column(
        4,
        shiny::h4("Current chains"),
        DT::dataTableOutput("chains_tbl"),
        shiny::fluidRow(
          shiny::column(6, shiny::numericInput("detach_n", "Detach N peptides", value = 1, min = 1, step = 1)),
          shiny::column(6,
                        shiny::actionButton("detach_head_btn", "Detach head", class = "btn-warning"),
                        shiny::actionButton("detach_tail_btn", "Detach tail", class = "btn-warning"))
        ),
        shiny::hr(),
        shiny::h4("Gene highlight"),
        shiny::selectizeInput(
          "gene_filter",
          "Select a gene",
          choices = c("(none)" = "", stats::setNames(all_genes, all_genes)),
          selected = "",
          options = list(placeholder = "Type to search...")
        ),
        shiny::hr(),
        shiny::h4("Gene constraints"),
        shiny::helpText("Add constraints (gene -> allowed chain IDs), then rebuild chains under constraints."),
        shiny::selectizeInput(
          "restrict_gene",
          "Gene(s) for this rule",
          choices = c("(none)" = "", stats::setNames(all_genes, all_genes)),
          selected = character(0),
          multiple = TRUE,
          options = list(placeholder = "Type to search...")
        ),
        shiny::uiOutput("restrict_chains_ui"),
        shiny::numericInput("max_chain_AA", "Max chain AA length", value = default_max_chain_AA, min = 1, step = 1),
        shiny::fluidRow(
          shiny::column(6, shiny::actionButton("add_rule_btn", "Add / merge rule", class = "btn-info")),
          shiny::column(6, shiny::actionButton("clear_rules_btn", "Clear all rules", class = "btn-secondary"))
        ),
        shiny::actionButton("rebuild_btn", "Rebuild under constraints", class = "btn-danger"),
        shiny::h5("Active constraints"),
        DT::dataTableOutput("constraints_tbl"),
        shiny::hr(),
        shiny::h4("Unassigned peptides"),
        DT::dataTableOutput("unassigned_tbl"),
        shiny::uiOutput("current_pep_ui"),
        shiny::fluidRow(
          shiny::column(6, shiny::actionButton("prepend_btn", "Prepend to chain", class = "btn-primary")),
          shiny::column(6, shiny::actionButton("append_btn", "Append to chain", class = "btn-primary"))
        ),
        shiny::actionButton("new_chain_btn", "Start new empty chain", class = "btn-secondary"),
        shiny::hr(),
        shiny::downloadButton("download_zip", "Download manual assembly (zip)")
      ),
      shiny::column(
        8,
        shiny::h4("Chain detail"),
        DT::dataTableOutput("chain_detail_tbl"),
        shiny::hr(),
        shiny::h4("Gene distribution across chains"),
        DT::dataTableOutput("gene_dist_tbl")
      )
    )
  )
  
  server <- function(input, output, session) {
    rv <- shiny::reactiveValues(
      chains = {
        ch <- st2$chains
        if (length(ch) < n_chains0) {
          for (i in seq_len(n_chains0 - length(ch))) ch[[length(ch) + 1L]] <- character(0)
        }
        ch
      },
      unassigned = init_unassigned,
      current_pep = if (nrow(init_unassigned)) init_unassigned$Peptide[1] else NA_character_,
      selected_chain_id = if (length(st2$chains)) 1L else NA_integer_,
      gene_constraints = list()
    )
    
    max_chain_AA_val <- shiny::reactive({
      v <- suppressWarnings(as.integer(input$max_chain_AA))
      if (!is.finite(v) || v < 1) return(Inf)
      as.integer(v)
    })
    
    used_peptides_reactive <- shiny::reactive({
      u <- unique(unlist(rv$chains))
      u <- toupper(trimws(as.character(u)))
      u <- u[!is.na(u) & nzchar(u)]
      sort(unique(u))
    })
    
    output$restrict_chains_ui <- shiny::renderUI({
      ch_ids <- seq_len(max(1L, length(rv$chains)))
      shiny::selectizeInput(
        "restrict_chains",
        "Allowed chains (IDs)",
        choices = stats::setNames(as.character(ch_ids), as.character(ch_ids)),
        multiple = TRUE,
        options = list(placeholder = "e.g., select 1 and 2")
      )
    })
    
    output$constraints_tbl <- DT::renderDataTable({
      cons <- rv$gene_constraints
      if (is.null(cons) || !length(cons)) {
        df <- data.frame(message = "No active gene constraints.")
        return(DT::datatable(df, rownames = FALSE, options = list(dom = 't')))
      }
      genes <- names(cons)
      allowed <- vapply(cons, function(v) {
        v <- suppressWarnings(as.integer(v))
        v <- v[is.finite(v) & v >= 1]
        if (!length(v)) "" else paste(sort(unique(v)), collapse = ",")
      }, character(1))
      df <- data.frame(gene = genes, allowed_chains = allowed, stringsAsFactors = FALSE)
      DT::datatable(df, rownames = FALSE, selection = 'single', options = list(pageLength = 8, scrollX = TRUE))
    })
    
    output$chains_tbl <- DT::renderDataTable({
      df <- .chain_summary(rv$chains)
      DT::datatable(df, rownames = FALSE, selection = 'single', options = list(pageLength = 10, scrollX = TRUE))
    })
    
    shiny::observeEvent(input$chains_tbl_rows_selected, {
      sel <- input$chains_tbl_rows_selected
      if (length(sel) == 1) rv$selected_chain_id <- as.integer(sel)
    })
    
    output$unassigned_tbl <- DT::renderDataTable({
      df <- .ensure_unassigned_df(rv$unassigned)
      DT::datatable(df, rownames = FALSE, selection = 'single', options = list(pageLength = 12, scrollX = TRUE))
    })
    
    shiny::observeEvent(input$unassigned_tbl_rows_selected, {
      sel <- input$unassigned_tbl_rows_selected
      df <- .ensure_unassigned_df(rv$unassigned)
      if (length(sel) == 1 && nrow(df) >= sel) rv$current_pep <- df$Peptide[sel]
    })
    
    output$current_pep_ui <- shiny::renderUI({
      shiny::helpText(sprintf("Current peptide: %s", ifelse(is.na(rv$current_pep), "(none)", rv$current_pep)))
    })
    
    output$chain_detail_tbl <- DT::renderDataTable({
      df <- .chains_detail_df(rv$chains, src_map, selected_gene = input$gene_filter)
      # Keep highlight column but hide it from display (used by formatStyle)
      dt <- DT::datatable(
        df,
        rownames = FALSE,
        options = list(
          pageLength = 15,
          scrollX = TRUE,
          columnDefs = list(list(visible = FALSE, targets = which(names(df) == "highlight") - 1))
        )
      )
      DT::formatStyle(
        dt,
        "highlight",
        target = "row",
        backgroundColor = DT::styleEqual(c(TRUE), c("#FFF2CC"))
      )
    })
    
    output$gene_dist_tbl <- DT::renderDataTable({
      df <- .gene_distribution_df(rv$chains, rv$unassigned, src_map)
      if (!nrow(df)) {
        msg <- data.frame(message = "No gene annotations available to summarize.")
        return(DT::datatable(msg, rownames = FALSE, options = list(dom = 't')))
      }
      
      dt <- DT::datatable(
        df,
        rownames = FALSE,
        options = list(pageLength = 15, scrollX = TRUE)
      )
      
      sel <- as.character(input$gene_filter)
      if (!is.na(sel)) sel <- trimws(sel)
      if (!is.na(sel) && nzchar(sel)) {
        dt <- DT::formatStyle(
          dt,
          "gene",
          target = "row",
          backgroundColor = DT::styleEqual(c(sel), c("#FFF2CC"))
        )
      }
      dt
    })
    
    # Detach actions ----------------------------------------------------------
    
    .detach_n <- function(from_head = TRUE) {
      cid <- suppressWarnings(as.integer(rv$selected_chain_id))
      if (!is.finite(cid) || cid < 1 || cid > length(rv$chains)) return(invisible(NULL))
      n <- suppressWarnings(as.integer(input$detach_n))
      if (!is.finite(n) || n < 1) n <- 1L
      
      ch <- rv$chains[[cid]]
      ch <- ch[!is.na(ch) & nzchar(ch)]
      if (!length(ch)) return(invisible(NULL))
      
      n <- min(n, length(ch))
      if (from_head) {
        removed <- ch[seq_len(n)]
        kept <- if (n < length(ch)) ch[(n + 1L):length(ch)] else character(0)
      } else {
        removed <- ch[(length(ch) - n + 1L):length(ch)]
        kept <- if (n < length(ch)) ch[seq_len(length(ch) - n)] else character(0)
      }
      
      rv$chains[[cid]] <- kept
      rv$unassigned <- .add_peptides_to_unassigned(rv$unassigned, removed, src_map)
      invisible(NULL)
    }
    
    shiny::observeEvent(input$detach_head_btn, { .detach_n(from_head = TRUE) })
    shiny::observeEvent(input$detach_tail_btn, { .detach_n(from_head = FALSE) })
    
    # Manual add --------------------------------------------------------------
    
    .place_current <- function(prepend = FALSE) {
      p <- rv$current_pep
      if (is.na(p) || !nzchar(p)) return(invisible(NULL))
      p <- toupper(trimws(as.character(p)))
      
      if (!p %in% rv$unassigned$Peptide) return(invisible(NULL))
      
      cid <- suppressWarnings(as.integer(rv$selected_chain_id))
      if (!is.finite(cid) || cid < 1) cid <- 1L
      if (cid > length(rv$chains)) {
        for (i in seq_len(cid - length(rv$chains))) rv$chains[[length(rv$chains) + 1L]] <- character(0)
      }
      
      mx <- max_chain_AA_val()
      ch <- rv$chains[[cid]]
      ch <- ch[!is.na(ch) & nzchar(ch)]
      
      if (is.finite(mx) && (sum(nchar(ch)) + nchar(p)) > mx) {
        shiny::showNotification("Chain is full under current max_chain_AA.", type = "warning")
        return(invisible(NULL))
      }
      
      # constraint check
      cons <- rv$gene_constraints
      allowed <- .allowed_chains_for_peptide(p, cons)
      if (!is.null(allowed) && length(allowed) && !(cid %in% allowed)) {
        shiny::showNotification("This peptide is constrained to different chain(s).", type = "warning")
        return(invisible(NULL))
      }
      
      if (isTRUE(prepend)) {
        rv$chains[[cid]] <- c(p, ch)
      } else {
        rv$chains[[cid]] <- c(ch, p)
      }
      
      rv$unassigned <- rv$unassigned[rv$unassigned$Peptide != p, , drop = FALSE]
      rv$current_pep <- if (nrow(rv$unassigned)) rv$unassigned$Peptide[1] else NA_character_
      invisible(NULL)
    }
    
    shiny::observeEvent(input$prepend_btn, { .place_current(prepend = TRUE) })
    shiny::observeEvent(input$append_btn, { .place_current(prepend = FALSE) })
    
    shiny::observeEvent(input$new_chain_btn, {
      rv$chains[[length(rv$chains) + 1L]] <- character(0)
      shiny::showNotification(sprintf("Added empty chain %d", length(rv$chains)), type = "message")
    })
    
    # Constraints -------------------------------------------------------------
    
    shiny::observeEvent(input$add_rule_btn, {
      genes <- input$restrict_gene
      genes <- genes[!is.na(genes) & nzchar(genes) & genes != "(none)" ]
      if (!length(genes)) {
        shiny::showNotification("Select at least one gene.", type = "warning")
        return()
      }
      
      allowed <- input$restrict_chains
      allowed <- suppressWarnings(as.integer(allowed))
      allowed <- allowed[is.finite(allowed) & allowed >= 1]
      if (!length(allowed)) {
        shiny::showNotification("Select allowed chain IDs.", type = "warning")
        return()
      }
      
      cons <- rv$gene_constraints
      for (g in genes) {
        g <- as.character(g)
        if (!nzchar(g) || g == "(none)") next
        prev <- cons[[g]]
        if (is.null(prev)) {
          cons[[g]] <- sort(unique(allowed))
        } else {
          prev <- suppressWarnings(as.integer(prev))
          prev <- prev[is.finite(prev) & prev >= 1]
          cons[[g]] <- sort(unique(intersect(prev, allowed)))
        }
      }
      rv$gene_constraints <- cons
      shiny::showNotification(sprintf("Updated constraints for %d gene(s).", length(genes)), type = "message")
    })
    
    shiny::observeEvent(input$clear_rules_btn, {
      rv$gene_constraints <- list()
      shiny::showNotification("Cleared all constraints.", type = "message")
    })
    
    shiny::observeEvent(input$rebuild_btn, {
      cons <- rv$gene_constraints
      mx <- max_chain_AA_val()
      if (!is.finite(mx) || mx < 1) mx <- Inf
      
      # Ensure chain count accommodates any constraint specifying larger IDs
      mx_allowed <- 0L
      if (!is.null(cons) && length(cons)) {
        vv <- suppressWarnings(as.integer(unlist(cons, use.names = FALSE)))
        vv <- vv[is.finite(vv) & vv >= 1]
        if (length(vv)) mx_allowed <- max(vv)
      }
      n_ch <- max(1L, length(rv$chains), n_chains0, mx_allowed)
      
      rb <- .rebuild_under_constraints(pep_universe_vec, cons, n_chains = n_ch, max_chain_AA = mx)
      rv$chains <- rb$chains
      rv$unassigned <- .add_peptides_to_unassigned(data.frame(Peptide = character(0), stringsAsFactors = FALSE), rb$unassigned, src_map)
      rv$current_pep <- if (nrow(rv$unassigned)) rv$unassigned$Peptide[1] else NA_character_
      
      shiny::showNotification("Rebuilt chains under constraints.", type = "message")
    })
    
    # Download ---------------------------------------------------------------
    
    output$download_zip <- shiny::downloadHandler(
      filename = function() {
        paste0(out_base, ".zip")
      },
      content = function(file) {
        tmpdir <- tempfile("manual_asm_classII_")
        dir.create(tmpdir)
        
        chain_out <- .chain_summary(rv$chains)
        # include full concatenated chain sequence
        chain_out$chain_sequence <- vapply(rv$chains, function(ch) paste0(ch, collapse = ""), character(1))
        
        edge_out <- .edges_from_chains_na(rv$chains)
        unassigned_out <- .ensure_unassigned_df(rv$unassigned)
        
        chain_tsv <- file.path(tmpdir, paste0(out_base, "_chains.tsv"))
        edge_tsv  <- file.path(tmpdir, paste0(out_base, "_edges.tsv"))
        unassigned_tsv <- file.path(tmpdir, paste0(out_base, "_unassigned_peptides.tsv"))
        state_rds <- file.path(tmpdir, paste0(out_base, "_manual_state.rds"))
        
        readr::write_tsv(chain_out, chain_tsv)
        readr::write_tsv(edge_out, edge_tsv)
        readr::write_tsv(unassigned_out, unassigned_tsv)
        
        saveRDS(
          list(
            stage2_state_rds = stage2_state_rds,
            chains = rv$chains,
            chain_table = chain_out,
            edge_table = edge_out,
            unassigned_table = unassigned_out,
            gene_constraints = rv$gene_constraints
          ),
          state_rds
        )
        
        old <- setwd(tmpdir)
        on.exit(setwd(old), add = TRUE)
        utils::zip(zipfile = file, files = basename(c(chain_tsv, edge_tsv, unassigned_tsv, state_rds)))
      }
    )
  }
  
  app <- shiny::shinyApp(ui = ui, server = server)
  shiny::runApp(app, launch.browser = isTRUE(launch_browser))
  invisible(NULL)
}