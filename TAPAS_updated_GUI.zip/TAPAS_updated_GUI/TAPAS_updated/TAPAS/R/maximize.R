# Internal graph assembly / maximization utilities for stage2
#
# These helpers implement a greedy multi-chain assembler on a directed graph of
# peptide->peptide edges (A->B), where each edge has a NetChop boundary score.
#
# Objective (for maximization): maximize total AA length of UNIQUE peptides used
# across all chains.

# ---------------------------
# Core greedy assembler (index space)
# ---------------------------

.assemble_multi_chains_greedy_idx <- function(peptides,
                                             pep_len,
                                             edges_by_A,
                                             start_idx,
                                             n_chains,
                                             max_chain_AA) {
  stopifnot(is.character(peptides), length(peptides) >= 1)
  stopifnot(is.numeric(pep_len), length(pep_len) == length(peptides))
  stopifnot(is.list(edges_by_A))
  stopifnot(is.numeric(start_idx), length(start_idx) == 1)
  stopifnot(is.numeric(n_chains), length(n_chains) == 1, n_chains >= 1)
  stopifnot(is.numeric(max_chain_AA), length(max_chain_AA) == 1, max_chain_AA >= 1)

  start_idx <- as.integer(start_idx)
  n <- length(peptides)

  used <- rep(FALSE, n)
  chains <- vector("list", n_chains)
  edges_used <- data.table::data.table(
    chain_id = integer(0),
    step = integer(0),
    A_idx = integer(0),
    B_idx = integer(0),
    netchop_score_boundary = numeric(0)
  )

  # helper: pick the next start peptide for a new chain
  # preference: highest outgoing score among unused peptides
  pick_next_start <- function() {
    unused_idx <- which(!used)
    if (!length(unused_idx)) return(NA_integer_)

    best_idx <- NA_integer_
    best_score <- -Inf

    for (i in unused_idx) {
      ed <- edges_by_A[[as.character(i)]]
      if (is.null(ed) || !nrow(ed)) next
      # edges are already sorted by score desc
      s <- suppressWarnings(max(ed$netchop_score_boundary, na.rm = TRUE))
      if (is.finite(s) && s > best_score) {
        best_score <- s
        best_idx <- i
      }
    }

    if (is.na(best_idx)) unused_idx[1] else best_idx
  }

  curr_start <- start_idx

  for (c in seq_len(n_chains)) {
    if (!is.finite(curr_start) || is.na(curr_start) || curr_start < 1 || curr_start > n) {
      curr_start <- pick_next_start()
    }
    if (!length(which(!used)) || is.na(curr_start)) {
      chains[[c]] <- integer(0)
      next
    }

    chain <- integer(0)
    chain_AA <- 0

    # initialize chain
    if (!used[curr_start]) {
      chain <- c(chain, curr_start)
      used[curr_start] <- TRUE
      chain_AA <- chain_AA + pep_len[curr_start]
    }

    # extend chain greedily
    step <- 0L
    repeat {
      if (!length(chain)) break
      curr <- chain[length(chain)]

      ed <- edges_by_A[[as.character(curr)]]
      if (is.null(ed) || !nrow(ed)) break

      # candidate Bs not yet used and within max length
      cand <- ed[!used[ed$B_idx], , drop = FALSE]
      if (!nrow(cand)) break

      # pick best score first (already sorted), but enforce length
      picked <- NA_integer_
      picked_score <- NA_real_

      for (k in seq_len(nrow(cand))) {
        b <- cand$B_idx[k]
        if (chain_AA + pep_len[b] <= max_chain_AA) {
          picked <- b
          picked_score <- cand$netchop_score_boundary[k]
          break
        }
      }

      if (is.na(picked)) break

      # add edge + peptide
      step <- step + 1L
      edges_used <- data.table::rbindlist(list(
        edges_used,
        data.table::data.table(
          chain_id = c,
          step = step,
          A_idx = curr,
          B_idx = picked,
          netchop_score_boundary = picked_score
        )
      ), use.names = TRUE, fill = TRUE)

      chain <- c(chain, picked)
      used[picked] <- TRUE
      chain_AA <- chain_AA + pep_len[picked]

      # stop if full
      if (chain_AA >= max_chain_AA) break
    }

    chains[[c]] <- chain
    curr_start <- NA_integer_
  }

  list(
    chains_idx = chains,
    edges_used_idx = edges_used,
    used_idx = which(used)
  )
}

# ---------------------------
# Graph preparation
# ---------------------------

.prepare_stage2_graph <- function(peptides, pep_len, edges_dt) {
  if (!all(c("A", "B", "netchop_score_boundary") %in% names(edges_dt))) {
    stop("edges_dt must contain columns: A, B, netchop_score_boundary")
  }

  peptides <- as.character(peptides)
  pep_to_idx <- setNames(seq_along(peptides), peptides)

  ed <- data.table::as.data.table(edges_dt)
  ed$A <- as.character(ed$A)
  ed$B <- as.character(ed$B)

  # keep only edges that exist in peptide universe
  ed <- ed[ed$A %in% peptides & ed$B %in% peptides]
  if (!nrow(ed)) {
    edges_by_A <- vector("list", length(peptides))
    names(edges_by_A) <- as.character(seq_along(peptides))
    return(list(peptides = peptides, pep_len = pep_len, pep_to_idx = pep_to_idx,
                edges_by_A = edges_by_A, edges_idx = ed))
  }

  ed[, A_idx := pep_to_idx[A]]
  ed[, B_idx := pep_to_idx[B]]
  ed <- ed[is.finite(A_idx) & is.finite(B_idx)]

  # sort by score descending (greedy picks first feasible)
  data.table::setorder(ed, A_idx, -netchop_score_boundary)

  # build adjacency: list per A_idx (names are character indices)
  edges_by_A <- split(ed[, .(B_idx, netchop_score_boundary)], f = ed$A_idx)

  # ensure all indices exist
  for (i in seq_along(peptides)) {
    nm <- as.character(i)
    if (is.null(edges_by_A[[nm]])) {
      edges_by_A[[nm]] <- data.table::data.table(B_idx = integer(0), netchop_score_boundary = numeric(0))
    }
  }

  list(
    peptides = peptides,
    pep_len = pep_len,
    pep_to_idx = pep_to_idx,
    edges_by_A = edges_by_A,
    edges_idx = ed
  )
}

# ---------------------------
# Single-start assembly wrapper
# ---------------------------

.assemble_multi_chain_single_start <- function(peptides,
                                               pep_len,
                                               edges_dt,
                                               start_peptide,
                                               n_chains,
                                               max_chain_AA,
                                               verbose = TRUE,
                                               graph = NULL) {
  g <- graph
  if (is.null(g)) {
    g <- .prepare_stage2_graph(peptides = peptides, pep_len = pep_len, edges_dt = edges_dt)
  }

  start_peptide <- as.character(start_peptide)
  if (!(start_peptide %in% g$peptides)) {
    stop("start_peptide not in peptide universe")
  }
  start_idx <- as.integer(g$pep_to_idx[[start_peptide]])

  if (isTRUE(verbose)) {
    message(sprintf("Start peptide: %s", start_peptide))
  }

  out <- .assemble_multi_chains_greedy_idx(
    peptides = g$peptides,
    pep_len = g$pep_len,
    edges_by_A = g$edges_by_A,
    start_idx = start_idx,
    n_chains = n_chains,
    max_chain_AA = max_chain_AA
  )

  used_idx <- out$used_idx
  total_AA <- sum(g$pep_len[used_idx], na.rm = TRUE)

  # convert chains and edges to peptide strings
  chains <- lapply(out$chains_idx, function(idx) g$peptides[idx])

  ed <- out$edges_used_idx
  if (nrow(ed)) {
    ed_out <- data.table::data.table(
      chain_id = ed$chain_id,
      step = ed$step,
      A = g$peptides[ed$A_idx],
      B = g$peptides[ed$B_idx],
      netchop_score_boundary = ed$netchop_score_boundary
    )
  } else {
    ed_out <- data.table::data.table(
      chain_id = integer(0),
      step = integer(0),
      A = character(0),
      B = character(0),
      netchop_score_boundary = numeric(0)
    )
  }

  list(
    chains = chains,
    edges = ed_out,
    start_peptide = start_peptide,
    total_AA_used = total_AA,
    total_peptides_used = length(unique(unlist(chains)))
  )
}

# ---------------------------
# Maximization over all possible starts
# ---------------------------

.maximize_multi_chain_all_starts <- function(peptides,
                                            pep_len = nchar(peptides),
                                            edges_dt,
                                            n_chains,
                                            max_chain_AA,
                                            verbose = TRUE,
                                            progress_every = 1L) {
  peptides <- as.character(peptides)
  stopifnot(length(peptides) >= 1)
  stopifnot(is.numeric(pep_len), length(pep_len) == length(peptides))

  g <- .prepare_stage2_graph(peptides = peptides, pep_len = pep_len, edges_dt = edges_dt)

  best <- NULL
  best_AA <- -Inf

  N <- length(g$peptides)
  progress_every <- as.integer(progress_every)
  if (!is.finite(progress_every) || is.na(progress_every) || progress_every < 1) progress_every <- 1L

  for (i in seq_len(N)) {
    start_pep <- g$peptides[i]
    res <- .assemble_multi_chain_single_start(
      peptides = g$peptides,
      pep_len = g$pep_len,
      edges_dt = edges_dt,
      start_peptide = start_pep,
      n_chains = n_chains,
      max_chain_AA = max_chain_AA,
	    verbose = FALSE,
	    graph = g
    )

    if (isTRUE(verbose) && (i %% progress_every == 0L || i == 1L || i == N)) {
      message(sprintf(
        "[%d/%d] start=%s | AA_used=%d | peptides_used=%d | chains=%d",
        i, N, start_pep,
        as.integer(res$total_AA_used),
        as.integer(res$total_peptides_used),
        length(res$chains)
      ))
    }

    if (is.finite(res$total_AA_used) && res$total_AA_used > best_AA) {
      best_AA <- res$total_AA_used
      best <- res
    }
  }

  if (isTRUE(verbose) && !is.null(best)) {
    message(sprintf(
      "Best start=%s | AA_used=%d | peptides_used=%d | chains=%d",
      best$start_peptide,
      as.integer(best$total_AA_used),
      as.integer(best$total_peptides_used),
      length(best$chains)
    ))
  }

  best
}
