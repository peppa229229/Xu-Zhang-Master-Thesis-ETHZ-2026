# classI_stage1.R
# Stage 1 for Class I (fixed winner_allele)
# - Prefer allele-coded rank columns (HLA-A*02:01_EL_Rank etc)
# - If only generic Rank/EL_Rank exists, use Allele column or infer from SourceFile
# - Never output plain "HLA" as winner_allele
# - Output merged provenance: merged_peptides | merged_peptides_rank | merged_winner_alleles
# - Add winner_rank_avg = mean rank of merged peptides (unique peptides)

classI_stage1 <- function(in_dir,
                          fasta_file,
                          out_dir,
                          out_base = "classI_stage1",
                          rank_thr = 0.1,
                          use_athena = FALSE,
                          athena_file = NULL,
                          athena_thr = NA_real_,
                          want_supertypes = FALSE,
                          recursive = FALSE,
                          exclude_last = 2,
                          overwrite = TRUE) {
  
  stopifnot(is.character(in_dir), length(in_dir) == 1, nzchar(in_dir))
  stopifnot(is.character(fasta_file), length(fasta_file) == 1, nzchar(fasta_file))
  stopifnot(is.character(out_dir), length(out_dir) == 1, nzchar(out_dir))
  if (!dir.exists(in_dir)) stop("in_dir does not exist: ", in_dir)
  if (!file.exists(fasta_file)) stop("fasta_file does not exist: ", fasta_file)
  
  for (pkg in c("data.table", "readr", "Biostrings")) {
    if (!requireNamespace(pkg, quietly = TRUE)) stop("Package not installed: ", pkg)
  }
  if (!exists("process_netmhc_dir", mode = "function")) {
    stop("Missing dependency function: process_netmhc_dir(). Source netmhc_classI_cleaning.R first.")
  }
  if (!exists(".infer_hla_allele_from_path", mode = "function")) {
    stop("Missing dependency function: .infer_hla_allele_from_path(). Source netmhc_classI_cleaning.R first.")
  }
  
  .ensure_dir_local <- function(d) {
    if (!dir.exists(d)) dir.create(d, recursive = TRUE, showWarnings = FALSE)
    normalizePath(d, winslash = "/", mustWork = FALSE)
  }
  
  .try_set_utf8_locale <- function() {
    try(Sys.setenv(LANG = "C.UTF-8", LC_ALL = "C.UTF-8"), silent = TRUE)
    try(Sys.setlocale("LC_CTYPE", "C.UTF-8"), silent = TRUE)
    invisible(TRUE)
  }
  
  .is_probably_binary <- function(path) {
    if (!file.exists(path)) return(FALSE)
    raw4 <- tryCatch(readBin(path, "raw", 4), error = function(e) raw(0))
    if (length(raw4) < 2) return(FALSE)
    if (length(raw4) >= 2 && identical(raw4[1:2], as.raw(c(0x50, 0x4B)))) return(TRUE) # xlsx zip "PK"
    if (length(raw4) >= 4 && identical(raw4[1:4], as.raw(c(0xD0, 0xCF, 0x11, 0xE0)))) return(TRUE) # xls OLE
    FALSE
  }
  
  .rewrite_as_utf8 <- function(path) {
    x <- tryCatch(readLines(path, warn = FALSE), error = function(e) NULL)
    if (is.null(x)) return(FALSE)
    x2 <- iconv(x, from = "", to = "UTF-8", sub = "")
    if (is.null(x2)) return(FALSE)
    writeLines(x2, path, useBytes = TRUE)
    TRUE
  }
  
  .safe_fread <- function(f) {
    if (.is_probably_binary(f)) {
      stop("File looks like binary but has _cleaned.txt suffix: ", f)
    }
    warned_translate <- FALSE
    dt <- withCallingHandlers(
      data.table::fread(f, sep = "\t", header = TRUE, na.strings = c("", "NA")),
      warning = function(w) {
        msg <- conditionMessage(w)
        if (grepl("unable to translate", msg, fixed = TRUE)) {
          warned_translate <<- TRUE
          message("\n[WARNING] fread translation issue: ", f, "\n", msg,
                  "\nAttempt UTF-8 rewrite and retry...")
          invokeRestart("muffleWarning")
        }
      }
    )
    if (isTRUE(warned_translate)) {
      ok <- .rewrite_as_utf8(f)
      if (!ok) stop("Failed to rewrite file as UTF-8: ", f)
      dt <- data.table::fread(f, sep = "\t", header = TRUE, na.strings = c("", "NA"))
    }
    dt
  }
  
  # Normalize allele label into canonical HLA-A*02:01, and prevent "HLA" alone
  .normalize_hla_allele <- function(x) {
    x <- as.character(x)
    x <- trimws(x)
    x <- gsub("\\s+", "", x)
    
    # remove suffix _Rank / _EL_Rank etc
    x <- sub("(?i)(?:[._\\s]?EL)?[._\\s]?Rank$", "", x, perl = TRUE)
    
    # unify prefix
    x <- sub("(?i)^HLA[_\\.]", "HLA-", x, perl = TRUE)
    x <- sub("(?i)^HLA(?=[A-Za-z0-9])", "HLA-", x, perl = TRUE)
    
    # Convert HLA-A0201 / HLA-A_02_01 / A0201 etc to HLA-A*02:01
    m <- regexec("(?i)^(?:HLA-)?([A-Z]{1,3})[-_.]?\\*?([0-9]{2})[-_:_.]?([0-9]{2})$", x, perl = TRUE)
    r <- regmatches(x, m)
    x2 <- vapply(seq_along(r), function(i) {
      rr <- r[[i]]
      if (length(rr) >= 4) {
        sprintf("HLA-%s*%s:%s", toupper(rr[2]), rr[3], rr[4])
      } else {
        x[i]
      }
    }, character(1))
    
    # kill plain HLA
    x2[grepl("(?i)^HLA-?$", x2, perl = TRUE)] <- NA_character_
    x2[nzchar(x2) == FALSE] <- NA_character_
    x2
  }
  
  .infer_from_sourcefile_vec <- function(src) {
    src <- as.character(src)
    vapply(src, function(s) .infer_hla_allele_from_path(s), character(1))
  }
  
  # Compute winner allele/rank (fixed)
  .compute_winner <- function(dt) {
    nms <- names(dt)
    
    # More tolerant allele core regex (allows separators)
    allele_core_pat <- "(?i)(?:HLA[-_.])?[A-Z]{1,3}[-_.]?\\*?\\d{2}[-_:_.]?\\d{2}"
    rank_suffix_pat <- "(?i)(?:[._\\s]?EL)?[._\\s]?Rank$"
    
    cand <- nms[grepl(paste0("^", allele_core_pat, ".*", rank_suffix_pat), nms, perl = TRUE)]
    if (!length(cand)) {
      cand <- nms[grepl("(?i)Rank$", nms, perl = TRUE) & grepl(allele_core_pat, nms, perl = TRUE)]
    }
    
    if (length(cand)) {
      el_cols <- cand[grepl("(?i)EL[._\\s]?Rank$", cand, perl = TRUE)]
      use_cols <- if (length(el_cols)) el_cols else cand
      
      rank_mat <- suppressWarnings(sapply(use_cols, function(col) as.numeric(dt[[col]])))
      if (is.vector(rank_mat)) {
        rank_mat <- matrix(rank_mat, ncol = 1)
        colnames(rank_mat) <- use_cols
      }
      
      all_na <- apply(is.na(rank_mat), 1, all)
      tmp <- rank_mat
      tmp[is.na(tmp)] <- Inf
      winner_idx <- max.col(-tmp, ties.method = "first")
      
      winner_rank <- rank_mat[cbind(seq_len(nrow(rank_mat)), winner_idx)]
      winner_allele_raw <- colnames(rank_mat)[winner_idx]
      winner_allele <- .normalize_hla_allele(winner_allele_raw)
      
      # If normalize returns NA (e.g. "HLA" only), fallback to Allele or SourceFile
      need_fill <- is.na(winner_allele)
      if (any(need_fill)) {
        if ("Allele" %in% nms) {
          fill <- .normalize_hla_allele(dt$Allele)
        } else if ("SourceFile" %in% nms) {
          fill <- .normalize_hla_allele(.infer_from_sourcefile_vec(dt$SourceFile))
        } else {
          fill <- rep(NA_character_, nrow(dt))
        }
        winner_allele[need_fill] <- fill[need_fill]
      }
      
      winner_rank[all_na] <- NA_real_
      winner_allele[all_na] <- NA_character_
      
      return(list(
        winner_allele = winner_allele,
        winner_rank   = as.numeric(winner_rank),
        used_rank_cols = use_cols
      ))
    }
    
    # fallback: generic rank only
    generic_cols <- nms[grepl("(?i)^(?:HLA[_\\.-]?)?(?:EL[_\\.-]?)?Rank$", nms, perl = TRUE)]
    if (!length(generic_cols)) stop("No rank columns found in cleaned data.")
    
    # prefer EL_Rank if exists
    pick <- generic_cols[1]
    if (any(tolower(generic_cols) %in% c("el_rank", "elrank", "hla_el_rank"))) {
      pick <- generic_cols[which(tolower(generic_cols) %in% c("el_rank", "elrank", "hla_el_rank"))[1]]
    } else if (any(tolower(generic_cols) %in% c("rank", "hla_rank"))) {
      pick <- generic_cols[which(tolower(generic_cols) %in% c("rank", "hla_rank"))[1]]
    }
    
    winner_rank <- suppressWarnings(as.numeric(dt[[pick]]))
    
    if ("Allele" %in% nms) {
      winner_allele <- .normalize_hla_allele(dt$Allele)
    } else if ("SourceFile" %in% nms) {
      winner_allele <- .normalize_hla_allele(.infer_from_sourcefile_vec(dt$SourceFile))
    } else {
      winner_allele <- rep(NA_character_, nrow(dt))
    }
    
    # never output plain "HLA"
    winner_allele[grepl("(?i)^HLA-?$", winner_allele, perl = TRUE)] <- NA_character_
    
    all_na <- is.na(winner_rank)
    winner_allele[all_na] <- NA_character_
    
    list(
      winner_allele = winner_allele,
      winner_rank   = as.numeric(winner_rank),
      used_rank_cols = pick
    )
  }
  
  # helper: format numeric ranks into stable strings
  .fmt_rank <- function(x) {
    x <- suppressWarnings(as.numeric(x))
    out <- ifelse(is.na(x), "NA", format(x, scientific = FALSE, trim = TRUE, digits = 15))
    as.character(out)
  }
  
  # merge overlapping intervals per protein (simple standalone)
  # + output provenance columns:
  #   merged_peptides (|), merged_peptides_rank (|), merged_winner_alleles (|)
  # + winner_rank_avg = mean rank across merged peptides (unique peptides)
  merge_intervals_one <- function(df_one) {
    if (!nrow(df_one)) return(df_one)
    df_one <- df_one[order(df_one$Pos_start, df_one$Pos_end), , drop = FALSE]
    if (!("full_seq" %in% names(df_one))) stop("merge_intervals_one() requires full_seq column.")
    full_seq <- as.character(df_one$full_seq[1])
    
    starts <- as.integer(df_one$Pos_start)
    ends   <- as.integer(df_one$Pos_end)
    
    grp <- integer(length(starts))
    g <- 1L
    cur_e <- ends[1]
    grp[1] <- g
    
    if (length(starts) > 1) {
      for (i in 2:length(starts)) {
        if (is.na(starts[i]) || is.na(ends[i])) {
          g <- g + 1L
          grp[i] <- g
          cur_e <- ends[i]
          next
        }
        if (starts[i] <= (cur_e + 1L)) {
          cur_e <- max(cur_e, ends[i], na.rm = TRUE)
          grp[i] <- g
        } else {
          g <- g + 1L
          grp[i] <- g
          cur_e <- ends[i]
        }
      }
    }
    
    df_one$._grp <- grp
    has_wr <- "winner_rank" %in% names(df_one)
    has_wa <- "winner_allele" %in% names(df_one)
    
    out <- do.call(rbind, lapply(split(df_one, df_one$._grp), function(z) {
      s <- min(z$Pos_start, na.rm = TRUE)
      e <- max(z$Pos_end, na.rm = TRUE)
      pep_merged <- substr(full_seq, s, e)
      
      # choose representative row (best rank if available)
      best_idx <- 1L
      if (has_wr && any(!is.na(z$winner_rank))) {
        best_idx <- which.min(ifelse(is.na(z$winner_rank), Inf, z$winner_rank))
      }
      
      row <- z[best_idx, , drop = FALSE]
      row$Pos_start <- s
      row$Pos_end   <- e
      row$Peptide   <- pep_merged
      
      # ---- provenance: unique peptides in this group (keep order by position) ----
      src_pep <- toupper(as.character(z$Peptide))
      src_pep[!nzchar(src_pep)] <- NA_character_
      
      # keep first occurrence order
      keep_u <- !is.na(src_pep) & !duplicated(src_pep)
      src_pep_u <- src_pep[keep_u]
      
      src_rank_u <- if (has_wr) suppressWarnings(as.numeric(z$winner_rank[keep_u])) else rep(NA_real_, length(src_pep_u))
      src_allele_u <- if (has_wa) as.character(z$winner_allele[keep_u]) else rep(NA_character_, length(src_pep_u))
      src_allele_u[!nzchar(src_allele_u)] <- NA_character_
      
      row$merged_peptides <- if (length(src_pep_u)) paste(src_pep_u, collapse = "|") else NA_character_
      row$merged_peptides_rank <- if (length(src_pep_u)) paste(.fmt_rank(src_rank_u), collapse = "|") else NA_character_
      row$merged_winner_alleles <- if (length(src_pep_u)) paste(ifelse(is.na(src_allele_u), "NA", src_allele_u), collapse = "|") else NA_character_
      
      # counts
      row$n_merged <- as.integer(length(src_pep_u))   # number of unique peptides merged
      row$n_hits   <- as.integer(nrow(z))            # number of rows/hits in this merged interval
      
      # avg rank across merged peptides
      row$winner_rank_avg <- if (length(src_rank_u) && !all(is.na(src_rank_u))) mean(src_rank_u, na.rm = TRUE) else NA_real_
      
      row$._grp <- NULL
      row
    }))
    rownames(out) <- NULL
    out
  }
  
  .try_set_utf8_locale()
  out_dir <- .ensure_dir_local(out_dir)
  
  # 1) Flatten/clean NetMHCpan outputs
  cleaned_dir <- process_netmhc_dir(
    dir = in_dir,
    recursive = recursive,
    outdir = file.path(in_dir, "cleaned"),
    exclude_last = exclude_last,
    overwrite = overwrite
  )
  
  cleaned_files <- list.files(cleaned_dir, pattern = "(?i)_cleaned\\.txt$", full.names = TRUE)
  if (!length(cleaned_files)) stop("No *_cleaned.txt found under: ", cleaned_dir)
  
  # 2) Read all cleaned tables
  dts <- lapply(cleaned_files, function(f) {
    dt1 <- tryCatch(.safe_fread(f), error = function(e) {
      message("\n[ERROR] Failed to read cleaned file: ", f, "\n", conditionMessage(e))
      NULL
    })
    if (is.null(dt1)) return(NULL)
    dt1$SourceFile <- basename(f)
    dt1
  })
  dts <- dts[!vapply(dts, is.null, logical(1))]
  if (!length(dts)) stop("Failed to read any cleaned files.")
  dt <- data.table::rbindlist(dts, fill = TRUE, use.names = TRUE)
  if (!"Peptide" %in% names(dt)) stop("No 'Peptide' column after merging.")
  
  # 3) Winner allele/rank (FIXED)
  w <- .compute_winner(dt)
  dt$winner_allele <- w$winner_allele
  dt$winner_rank   <- w$winner_rank
  
  # 4) Filter by rank
  keep_idx <- !is.na(dt$winner_rank) & (dt$winner_rank < rank_thr)
  res <- dt[keep_idx, , drop = FALSE]
  if (nrow(res) == 0L) stop("No peptides passed rank_thr = ", rank_thr)
  res <- res[!duplicated(res$Peptide), , drop = FALSE]
  
  # 5) Map peptides to FASTA proteins and positions
  aa <- Biostrings::readAAStringSet(fasta_file)
  prot_names <- names(aa)
  seq_lookup <- data.table::data.table(ProteinID = prot_names, full_seq = as.character(aa))
  
  peps <- unique(toupper(as.character(res$Peptide)))
  peps <- peps[!is.na(peps) & nzchar(peps)]
  if (!length(peps)) stop("No peptides after filtering / cleaning.")
  
  match_list <- lapply(peps, function(p) {
    mi <- Biostrings::vmatchPattern(Biostrings::AAString(p), aa, max.mismatch = 0, fixed = TRUE)
    hits <- lapply(seq_along(mi), function(i) {
      if (length(mi[[i]]) > 0) {
        data.table::data.table(
          Peptide   = p,
          ProteinID = prot_names[i],
          Pos_start = Biostrings::start(mi[[i]]),
          Pos_end   = Biostrings::end(mi[[i]])
        )
      } else NULL
    })
    data.table::rbindlist(hits, use.names = TRUE, fill = TRUE)
  })
  peptide_hits <- data.table::rbindlist(match_list, use.names = TRUE, fill = TRUE)
  
  res_pep2 <- merge(res, peptide_hits, by = "Peptide", all.x = TRUE)
  res_pep2 <- merge(res_pep2, seq_lookup, by = "ProteinID", all.x = TRUE)
  
  # final normalize
  res_pep2$winner_allele <- .normalize_hla_allele(res_pep2$winner_allele)
  
  # 6) Merge overlapping intervals per ProteinID
  res_pep2_df <- as.data.frame(res_pep2, stringsAsFactors = FALSE)
  split_list <- split(res_pep2_df, res_pep2_df$ProteinID)
  merged_list <- lapply(split_list, merge_intervals_one)
  res_pep2_merged <- do.call(rbind, merged_list)
  if (is.null(res_pep2_merged) || nrow(res_pep2_merged) == 0) stop("No merged intervals produced. Check FASTA mapping.")
  
  # 7) Write peptide table
  tsv_path <- file.path(out_dir, paste0(out_base, "_res_pep2_merged.tsv"))
  readr::write_tsv(res_pep2_merged, tsv_path)
  
  # 8) Build AB pairs and NetChop FASTA
  peps_u <- unique(toupper(as.character(res_pep2_merged$Peptide)))
  peps_u <- peps_u[!is.na(peps_u) & nzchar(peps_u)]
  if (length(peps_u) < 2L) stop("Not enough peptides to form ordered pairs for NetChop.")
  
  idx <- data.table::CJ(i = seq_along(peps_u), j = seq_along(peps_u), unique = TRUE)
  idx <- idx[idx$i != idx$j, , drop = FALSE]
  
  map_dt <- data.table::data.table(
    row_idx       = seq_len(nrow(idx)),
    A             = peps_u[idx$i],
    B             = peps_u[idx$j]
  )
  map_dt$A_len         <- nchar(map_dt$A)
  map_dt$combo_peptide <- paste0(map_dt$A, map_dt$B)
  map_dt$pep_id        <- sprintf("pep%06d", map_dt$row_idx)
  
  map_csv <- file.path(out_dir, paste0(out_base, "_AB_pairs_map.csv"))
  readr::write_csv(map_dt[, c("row_idx","A","B","A_len","combo_peptide","pep_id")], map_csv)
  
  netchop_fasta <- file.path(out_dir, paste0(out_base, "_AB_pairs_for_NetChop.fasta"))
  con <- file(netchop_fasta, "w")
  on.exit(try(close(con), silent = TRUE), add = TRUE)
  for (k in seq_len(nrow(map_dt))) {
    writeLines(paste0(">", map_dt$pep_id[k]), con)
    writeLines(map_dt$combo_peptide[k], con)
  }
  close(con)
  
  stage1_state_rds <- file.path(out_dir, paste0(out_base, "_stage1_state.rds"))
  saveRDS(
    list(
      res_pep2_merged = res_pep2_merged,
      map_dt          = as.data.frame(map_dt, stringsAsFactors = FALSE),
      tsv_path        = tsv_path,
      fasta_file      = fasta_file,
      cleaned_dir     = cleaned_dir,
      netchop_fasta   = netchop_fasta,
      map_csv         = map_csv,
      rank_thr        = rank_thr,
      used_rank_cols  = w$used_rank_cols
    ),
    stage1_state_rds
  )
  
  invisible(list(
    cleaned_dir      = cleaned_dir,
    peptide_tsv      = tsv_path,
    map_csv          = map_csv,
    netchop_fasta    = netchop_fasta,
    stage1_state_rds = stage1_state_rds,
    res_pep2_merged  = res_pep2_merged,
    map_dt           = map_dt
  ))
}
