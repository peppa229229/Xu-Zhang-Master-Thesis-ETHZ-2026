# netmhc_classI_cleaning.R
# NetMHCpan Class I cleaning/flatten (stable)
# Only accepts ".xls" files where ".xls" is NetMHCpan raw TEXT table output (NOT real binary Excel).

# ---- helper: ensure directory ------------------------------------------------
.ensure_dir <- function(d) {
  if (!dir.exists(d)) dir.create(d, recursive = TRUE, showWarnings = FALSE)
  normalizePath(d, winslash = "/", mustWork = FALSE)
}

# ---- helper: detect binary Excel masquerading as .xls ------------------------
# Real Excel .xls (OLE) begins with D0 CF 11 E0 A1 B1 1A E1. Zipped formats begin with "PK".
.is_probably_binary_excel <- function(path, n = 16L) {
  con <- file(path, "rb")
  on.exit(close(con), add = TRUE)
  b <- readBin(con, what = "raw", n = n)
  if (length(b) < 4) return(FALSE)
  
  ole_sig <- as.raw(c(0xD0, 0xCF, 0x11, 0xE0, 0xA1, 0xB1, 0x1A, 0xE1))
  if (length(b) >= 8 && identical(b[1:8], ole_sig)) return(TRUE)
  if (length(b) >= 2 && rawToChar(b[1:2]) == "PK") return(TRUE)
  if (any(b == as.raw(0x00))) return(TRUE)
  FALSE
}

# ---- helper: filename-based skip ---------------------------------------------
.should_skip_by_name_I <- function(bn) {
  if (grepl("(?i)final_peptide_list", bn, perl = TRUE)) return(TRUE)
  if (grepl("(?i)\\bfinal\\b", bn, perl = TRUE)) return(TRUE)
  if (grepl("(?i)_cleaned\\.txt$", bn, perl = TRUE)) return(TRUE)
  FALSE
}

# ---- helper: strip spaces only (keep * : - _ .) -------------------------------
.strip_spaces <- function(x) {
  x <- as.character(x)
  gsub("\\s+", "", x)
}

# ---- helper: allele detection ------------------------------------------------
# matches: HLA-A*02:01, HLA-A02:01, A*02:01, A02:01, A0201, A_02_01, HLA-A_02_01
.is_allele_like <- function(x) {
  x <- .strip_spaces(x)
  grepl("(?i)^(?:HLA[-_.])?[A-Z]{1,3}[-_.]?\\*?(?:\\d{2})[-_:_.]?(?:\\d{2})$", x, perl = TRUE) |
    grepl("(?i)^(?:HLA[-_.])?[ABC](?:\\d{4})$", x, perl = TRUE)
}

# ---- helper: metric detection ------------------------------------------------
.is_metric_like <- function(x) {
  x <- tolower(trimws(as.character(x)))
  x <- gsub("\\s+", "", x)
  x %in% c("rank", "el_rank", "elrank", "aff", "affinity", "score", "ic50", "nm", "nM", "core", "icore") |
    grepl("(^|_)(?:el)?rank$", x, perl = TRUE)
}

# ---- helper: normalize allele string into HLA-A*02:01 -------------------------
.normalize_one_allele <- function(x) {
  x <- .strip_spaces(x)
  if (is.na(x) || !nzchar(x)) return(NA_character_)
  
  x <- sub("(?i)^HLA[_\\.]", "HLA-", x, perl = TRUE)
  x <- sub("(?i)^HLA(?=[A-Za-z0-9])", "HLA-", x, perl = TRUE)
  
  m <- regexec("(?i)^(?:HLA-)?([A-Z]{1,3})[-_.]?\\*?([0-9]{2})[-_:_.]?([0-9]{2})$", x, perl = TRUE)
  r <- regmatches(x, m)[[1]]
  if (length(r) >= 4) return(sprintf("HLA-%s*%s:%s", toupper(r[2]), r[3], r[4]))
  
  m2 <- regexec("(?i)^(?:HLA-)?([ABC])([0-9]{2})([0-9]{2})$", x, perl = TRUE)
  r2 <- regmatches(x, m2)[[1]]
  if (length(r2) >= 4) return(sprintf("HLA-%s*%s:%s", toupper(r2[2]), r2[3], r2[4]))
  
  x
}

# ---- helper: infer allele from filename/path ---------------------------------
.infer_hla_allele_from_path <- function(path) {
  bn <- tools::file_path_sans_ext(basename(path))
  bn <- .strip_spaces(bn)
  
  m <- regexec("(?i)HLA[-_\\.]?([A-Z]{1,3})[-_\\.]?\\*?([0-9]{2})[-_:_.]?([0-9]{2})", bn, perl = TRUE)
  r <- regmatches(bn, m)[[1]]
  if (length(r) >= 4) return(sprintf("HLA-%s*%s:%s", toupper(r[2]), r[3], r[4]))
  
  m2 <- regexec("(?i)(?:^|[^A-Z0-9])([ABC])[-_\\.]?([0-9]{2})[-_\\.]?([0-9]{2})(?:$|[^0-9])", bn, perl = TRUE)
  r2 <- regmatches(bn, m2)[[1]]
  if (length(r2) >= 4) return(sprintf("HLA-%s*%s:%s", toupper(r2[2]), r2[3], r2[4]))
  
  NA_character_
}

# ---- helper: read NetMHCpan ".xls" (TEXT) ------------------------------------
# KEY FIX: we do NOT drop the allele row above the "Peptide" header.
# We keep a window of lines before the detected header line.
.read_netmhc_xls_raw <- function(path, keep_lines_before_header = 10L) {
  ext <- tolower(tools::file_ext(path))
  if (ext != "xls") return(NULL)
  
  if (.is_probably_binary_excel(path)) {
    stop("Detected a real binary Excel file. NetMHCpan .xls should be plain TEXT raw output: ", path)
  }
  
  lines <- tryCatch(readLines(path, warn = FALSE), error = function(e) NULL)
  if (is.null(lines) || !length(lines)) return(NULL)
  
  # find likely header line index (prefer: Pos + Peptide + ID)
  idx_pospep <- grep("(?i)\\bPos\\b.*\\bPeptide\\b.*\\bID\\b", lines, perl = TRUE)
  idx_pep <- grep("(?i)\\bPeptide\\b", lines, perl = TRUE)
  
  header_idx <- NA_integer_
  if (length(idx_pospep)) header_idx <- idx_pospep[1]
  if (is.na(header_idx) && length(idx_pep)) header_idx <- idx_pep[1]
  
  if (!is.na(header_idx)) {
    start <- max(1L, header_idx - as.integer(keep_lines_before_header))
    lines <- lines[start:length(lines)]
  }
  
  # try tab first if tabs exist early
  has_tabs <- any(grepl("\t", lines[seq_len(min(30, length(lines)))], fixed = TRUE))
  raw <- NULL
  
  if (isTRUE(has_tabs)) {
    raw <- tryCatch({
      con <- textConnection(lines)
      on.exit(close(con), add = TRUE)
      read.delim(
        con, header = FALSE, sep = "\t", quote = "",
        check.names = FALSE, stringsAsFactors = FALSE,
        comment.char = "", fill = TRUE
      )
    }, error = function(e) NULL)
  }
  
  # whitespace fallback
  if (is.null(raw) || ncol(raw) <= 1) {
    raw <- tryCatch({
      con <- textConnection(lines)
      on.exit(close(con), add = TRUE)
      read.table(
        con, header = FALSE, sep = "", quote = "",
        check.names = FALSE, stringsAsFactors = FALSE,
        comment.char = "", fill = TRUE
      )
    }, error = function(e) NULL)
  }
  
  if (is.null(raw)) return(NULL)
  
  # drop fully empty rows
  raw_chr <- as.data.frame(lapply(raw, as.character), stringsAsFactors = FALSE)
  keep <- apply(raw_chr, 1, function(r) any(!is.na(r) & nzchar(trimws(r))))
  raw[keep, , drop = FALSE]
}

# ---- helper: find header rows robustly ---------------------------------------
.find_header_rows_I <- function(raw) {
  nr <- nrow(raw); nc <- ncol(raw)
  if (nr < 2 || nc < 3) stop("Input too small to contain a NetMHCpan table.")
  
  mat <- apply(raw, c(1, 2), function(z) if (is.na(z)) "" else as.character(z))
  
  # score each row for being the metric/header row
  row_has_peptide <- vapply(seq_len(nr), function(r) any(tolower(trimws(mat[r, ])) == "peptide"), logical(1))
  row_has_pos <- vapply(seq_len(nr), function(r) any(tolower(trimws(mat[r, ])) == "pos"), logical(1))
  row_has_id <- vapply(seq_len(nr), function(r) any(tolower(trimws(mat[r, ])) == "id"), logical(1))
  
  # prefer a row that has peptide + (pos or id)
  cand <- which(row_has_peptide & (row_has_pos | row_has_id))
  if (!length(cand)) cand <- which(row_has_peptide)
  if (!length(cand)) stop("Cannot find a header row containing 'Peptide'.")
  
  peptide_row <- cand[1]
  
  allele_counts <- vapply(seq_len(nr), function(r) sum(.is_allele_like(mat[r, ]), na.rm = TRUE), integer(1))
  metric_counts <- vapply(seq_len(nr), function(r) sum(.is_metric_like(mat[r, ]), na.rm = TRUE), integer(1))
  
  # metric row usually equals peptide_row; sometimes it is the next line
  metric_row <- peptide_row
  if (metric_counts[metric_row] == 0L && metric_row < nr && metric_counts[metric_row + 1L] > 0L) {
    metric_row <- metric_row + 1L
  }
  
  # allele row is best allele-like row above metric_row
  allele_row <- metric_row
  if (metric_row > 1L) {
    cand2 <- seq_len(metric_row - 1L)
    best <- cand2[which.max(allele_counts[cand2])]
    if (length(best) && allele_counts[best] > 0L) allele_row <- best
  }
  
  data_start <- max(allele_row, metric_row) + 1L
  while (data_start <= nr) {
    if (any(nzchar(trimws(mat[data_start, ])))) break
    data_start <- data_start + 1L
  }
  
  list(allele_row = allele_row, metric_row = metric_row, data_start = data_start)
}

# ---- flatten one NetMHCpan Class I xls(TEXT) file -----------------------------
flatten_netmhc_file <- function(infile,
                                outfile = sub("(?i)\\.xls$", "_cleaned.txt", infile, perl = TRUE),
                                exclude_last = 2,
                                keep_lines_before_header = 10) {
  
  ext <- tolower(tools::file_ext(infile))
  if (ext != "xls") stop("Only .xls (NetMHCpan raw TEXT output) is accepted: ", infile)
  
  raw <- .read_netmhc_xls_raw(infile, keep_lines_before_header = keep_lines_before_header)
  if (is.null(raw)) stop("Cannot read .xls as NetMHCpan raw text table: ", infile)
  
  n <- ncol(raw)
  if (n < 3) stop("Input has too few columns: ", infile)
  if (exclude_last < 0 || exclude_last >= n) stop("exclude_last is invalid")
  
  hr <- .find_header_rows_I(raw)
  allele_row <- hr$allele_row
  metric_row <- hr$metric_row
  data_start <- hr$data_start
  if (data_start > nrow(raw)) stop("No data rows found after header in: ", infile)
  
  hdr_allele <- as.character(raw[allele_row, ])
  hdr_metric <- as.character(raw[metric_row, ])
  
  # fill-down allele row across columns (merged-like)
  hdr_allele[is.na(hdr_allele) | grepl("^\\s*$", hdr_allele)] <- NA_character_
  for (i in seq_len(n)) if (i > 1 && is.na(hdr_allele[i])) hdr_allele[i] <- hdr_allele[i - 1]
  
  base_names <- .strip_spaces(hdr_allele)
  leaf_names <- .strip_spaces(hdr_metric)
  
  base_names_norm <- vapply(base_names, function(z) {
    if (.is_allele_like(z)) .normalize_one_allele(z) else z
  }, character(1))
  
  rename_until <- n - exclude_last
  new_names <- leaf_names
  
  # only these are truly global (do NOT include Score/Rank here!)
  global_keep <- c("pos", "peptide", "id", "protein", "source", "length", "len")
  
  for (i in seq_len(n)) {
    b <- base_names_norm[i]
    l <- leaf_names[i]
    
    # keep last exclude_last columns as-is (Ave/NB etc.)
    if (i > rename_until) {
      if (!is.na(l) && nzchar(l)) new_names[i] <- l else new_names[i] <- b
      next
    }
    
    # keep global columns unprefixed
    if (!is.na(l) && nzchar(l) && tolower(l) %in% global_keep) {
      new_names[i] <- l
      next
    }
    
    # allele columns: ALWAYS prefix allele_
    if (!is.na(b) && nzchar(b) && .is_allele_like(b)) {
      if (!is.na(l) && nzchar(l)) new_names[i] <- paste0(b, "_", l) else new_names[i] <- b
      next
    }
    
    # fallback
    if (!is.na(l) && nzchar(l)) new_names[i] <- l else new_names[i] <- b
  }
  
  new_names <- gsub("\\s+", "", new_names)
  new_names <- make.unique(new_names, sep = ".")
  
  dat <- raw[seq(from = data_start, to = nrow(raw)), , drop = FALSE]
  colnames(dat) <- new_names
  
  dat[] <- lapply(dat, function(x) {
    if (is.character(x)) type.convert(x, as.is = TRUE) else x
  })
  
  # drop non-data rows by Pos
  if ("Pos" %in% names(dat)) {
    pos_num <- suppressWarnings(as.integer(as.character(dat$Pos)))
    dat <- dat[!is.na(pos_num), , drop = FALSE]
  }
  
  # optional metadata allele from filename
  allele_from_fn <- .infer_hla_allele_from_path(infile)
  if (!("Allele" %in% names(dat)) && !is.na(allele_from_fn) && nzchar(allele_from_fn)) {
    dat$Allele <- allele_from_fn
  }
  
  utils::write.table(dat, file = outfile, sep = "\t", quote = FALSE, row.names = FALSE)
  invisible(dat)
}

# ---- batch: process folder (ONLY .xls) ---------------------------------------
process_netmhc_dir <- function(dir,
                               pattern = "(?i)\\.xls$",
                               recursive = FALSE,
                               outdir = file.path(dir, "cleaned"),
                               exclude_last = 2,
                               overwrite = TRUE,
                               keep_lines_before_header = 10) {
  if (!dir.exists(dir)) stop("Directory not found: ", dir)
  outdir <- .ensure_dir(outdir)
  
  files_all <- list.files(dir, pattern = pattern, recursive = recursive, full.names = TRUE)
  if (!length(files_all)) stop("No NetMHCpan .xls raw-output files found in: ", dir)
  
  files_all <- files_all[!vapply(basename(files_all), .should_skip_by_name_I, logical(1))]
  if (!length(files_all)) stop("No eligible .xls files after filename-based filtering in: ", dir)
  
  wrote_any <- FALSE
  for (f in files_all) {
    outname <- paste0(tools::file_path_sans_ext(basename(f)), "_cleaned.txt")
    outfile <- file.path(outdir, outname)
    if (file.exists(outfile) && !isTRUE(overwrite)) next
    
    ok <- tryCatch(
      {
        flatten_netmhc_file(
          f,
          outfile = outfile,
          exclude_last = exclude_last,
          keep_lines_before_header = keep_lines_before_header
        )
        TRUE
      },
      error = function(e) {
        message(sprintf("Failed to flatten %s (%s)", basename(f), conditionMessage(e)))
        FALSE
      }
    )
    
    if (isTRUE(ok) && file.exists(outfile)) {
      wrote_any <- TRUE
      message("Flattened: ", basename(f), " -> ", outfile)
    }
  }
  
  if (!wrote_any) stop("No cleaned outputs produced under: ", outdir)
  outdir
}
