# Interval merging ------------------------------------------------------------

#' @keywords internal
merge_intervals_one <- function(df) {
  if (is.null(df) || nrow(df) == 0) return(df)

  # Ensure basic columns
  if (!all(c("ProteinID","Pos_start","Pos_end") %in% names(df))) return(df)

  df <- as.data.frame(df, stringsAsFactors = FALSE)
  df$Pos_start <- suppressWarnings(as.integer(df$Pos_start))
  df$Pos_end   <- suppressWarnings(as.integer(df$Pos_end))

  df <- df[!is.na(df$Pos_start) & !is.na(df$Pos_end) & df$Pos_start <= df$Pos_end, , drop = FALSE]
  if (nrow(df) == 0) return(df)

  # full_seq: first non-NA
  if (!("full_seq" %in% names(df))) df$full_seq <- NA_character_
  full_seq <- df$full_seq[which(!is.na(df$full_seq) & nzchar(df$full_seq))[1]]
  if (is.na(full_seq)) full_seq <- df$full_seq[1]

  # sort
  ord <- order(df$Pos_start, df$Pos_end)
  df <- df[ord, , drop = FALSE]

  # grouping
  grp <- integer(nrow(df))
  g <- 1L
  cur_end <- df$Pos_end[1]
  grp[1] <- g
  if (nrow(df) > 1) {
    for (i in 2:nrow(df)) {
      if (!is.na(df$Pos_start[i]) && df$Pos_start[i] <= (cur_end + 1L)) {
        grp[i] <- g
        cur_end <- max(cur_end, df$Pos_end[i], na.rm = TRUE)
      } else {
        g <- g + 1L
        grp[i] <- g
        cur_end <- df$Pos_end[i]
      }
    }
  }
  df$.grp <- grp

  # Aggregate per group
  out <- lapply(split(df, df$.grp), function(block) {
    pid <- block$ProteinID[1]
    st <- min(block$Pos_start, na.rm = TRUE)
    en <- max(block$Pos_end, na.rm = TRUE)
    pep_new <- safe_substr(full_seq, st, en)
    pep_new <- ifelse(length(pep_new) > 0, pep_new[[1]], NA_character_)    # rank: keep parts + min + avg
    rank_min <- NA_real_
    rank_avg <- NA_real_
    rank_parts <- NA_character_
    if ("winner_rank" %in% names(block)) {
      rv <- suppressWarnings(as.numeric(block$winner_rank))
      rv <- rv[is.finite(rv)]
      if (length(rv)) {
        rank_min <- min(rv)
        rank_avg <- mean(rv)
        # keep pre-merge ranks similar to merged peptides display
        rank_parts <- paste(unique(format(rv, scientific = FALSE, trim = TRUE)), collapse = " | ")
      }
    }

    allele_val <- NA_character_
    if ("winner_allele" %in% names(block)) {
      allele_val <- .collapse_unique(block$winner_allele)
    }

    pep_orig <- NA_character_
    if ("Peptide" %in% names(block)) pep_orig <- .collapse_unique(block$Peptide)

    data.frame(
      ProteinID = pid,
      full_seq = full_seq,
      Pos_start = st,
      Pos_end = en,
      Peptide = pep_new,
      merged_n = nrow(block),
      merged_from_peptides = pep_orig,
      winner_rank = rank_parts,
      winner_rank_min = rank_min,
      winner_rank_avg = rank_avg,
      winner_allele = allele_val,
      stringsAsFactors = FALSE
    )
  })
  do.call(rbind, out)
}
