#' Stage2: assemble peptides into chains using NetChop boundary scores (optional)
#'
#' use_netchop=TRUE:
#'   - use NetChop boundary score at A|B junction; keep edges >= netchop_thr
#'
#' use_netchop=FALSE:
#'   - DO NOT read/require netchop_txt
#'   - build edges directly from Stage1 map_dt (A->B), weight = occurrence count
#'   - assembly is deterministic (no random stitching)
#'
#' @param stage1_state_rds Filtered Stage1 state RDS (contains peptides + AB pair map)
#' @param netchop_txt NetChop output text file path (only used if use_netchop=TRUE)
#' @param use_netchop If TRUE, require netchop_txt and use NetChop boundary scores.
#' @param out_dir Output directory
#' @param out_base Output base name
#' @param netchop_thr Boundary score threshold (>=) (only used if use_netchop=TRUE)
#' @param n_chains Maximum number of chains to build.
#' @param max_chain_AA Maximum AA length per chain.
#' @param use_maximize If TRUE, try all start peptides (recommended).
#' @param maximize_progress_every progress message frequency
#' @param verbose verbose
#' @param overwrite overwrite outputs
#' @param seed optional RNG seed (only used if use_maximize=FALSE random start, or if your helpers use RNG)
#' @export
classI_stage2 <- function(stage1_state_rds,
                          netchop_txt = NULL,
                          use_netchop = TRUE,
                          out_dir,
                          out_base = "s2",
                          netchop_thr = 0.5,
                          n_chains = 10,
                          max_chain_AA = 250,
                          use_maximize = TRUE,
                          maximize_progress_every = 1L,
                          verbose = TRUE,
                          overwrite = TRUE,
                          seed = NULL) {
  
  if (!requireNamespace("data.table", quietly = TRUE)) stop("Package 'data.table' is required.")
  if (!requireNamespace("readr", quietly = TRUE)) stop("Package 'readr' is required.")
  
  stopifnot(is.character(stage1_state_rds), length(stage1_state_rds) == 1, nzchar(stage1_state_rds))
  if (!file.exists(stage1_state_rds)) stop("stage1_state_rds does not exist: ", stage1_state_rds)
  
  stopifnot(is.character(out_dir), length(out_dir) == 1, nzchar(out_dir))
  out_dir <- .ensure_dir(out_dir)
  
  if (!is.null(seed)) {
    seed <- suppressWarnings(as.integer(seed))
    if (is.finite(seed)) set.seed(seed)
  }
  
  use_netchop <- isTRUE(use_netchop)
  
  # ---- load Stage1 state ----
  st1 <- readRDS(stage1_state_rds)
  pep <- st1$res_pep2_merged
  map_dt <- st1$map_dt
  if (is.null(pep) || !is.data.frame(pep) || !nrow(pep)) stop("Stage1 state missing res_pep2_merged.")
  if (is.null(map_dt) || !is.data.frame(map_dt) || !nrow(map_dt)) stop("Stage1 state missing map_dt (AB pair map).")
  
  pep <- as.data.frame(pep, stringsAsFactors = FALSE)
  map_dt <- as.data.frame(map_dt, stringsAsFactors = FALSE)
  
  if (!("Peptide" %in% names(pep))) stop("Stage1 peptides missing 'Peptide' column.")
  if (!(all(c("A", "B") %in% names(map_dt)))) stop("map_dt must contain columns: A, B")
  
  # ---- gene / protein column detection for peptide source annotation ----
  gene_candidates <- c("ProteinID.x", "ProteinID", "ID", "Gene", "HUGO")
  gene_col <- gene_candidates[gene_candidates %in% names(pep)][1]
  if (is.na(gene_col) || is.null(gene_col)) gene_col <- NULL
  
  pep$Peptide <- toupper(trimws(as.character(pep$Peptide)))
  if (!is.null(gene_col)) pep[[gene_col]] <- trimws(as.character(pep[[gene_col]]))
  
  # peptide -> source proteins (concatenated)
  pep_sources <- data.table::as.data.table(pep)
  pep_sources <- pep_sources[!is.na(Peptide) & nchar(Peptide) > 0]
  if (!is.null(gene_col)) {
    pep_sources[, GeneSrc := get(gene_col)]
  } else {
    pep_sources[, GeneSrc := NA_character_]
  }
  src_dt <- pep_sources[, .(
    source_proteins = {
      v <- unique(GeneSrc)
      v <- v[!is.na(v) & nzchar(v)]
      if (!length(v)) NA_character_ else paste(sort(v), collapse = ",")
    }
  ), by = "Peptide"]
  src_map <- setNames(src_dt$source_proteins, src_dt$Peptide)
  
  # ---- peptides universe (unique sequences) ----
  map_dt$A <- toupper(trimws(as.character(map_dt$A)))
  map_dt$B <- toupper(trimws(as.character(map_dt$B)))
  pep_universe <- sort(unique(c(map_dt$A, map_dt$B)))
  pep_universe <- pep_universe[!is.na(pep_universe) & nzchar(pep_universe)]
  if (!length(pep_universe)) stop("No peptides found in map_dt.")
  
  pep_len_map <- setNames(nchar(pep_universe), pep_universe)
  
  # ---- build edges (NetChop or not) ----
  found_n <- NA_integer_
  total_n <- NA_integer_
  netchop_txt_norm <- NA_character_
  edge_score_type <- NA_character_
  
  if (use_netchop) {
    if (is.null(netchop_txt) || !nzchar(netchop_txt)) {
      stop("use_netchop=TRUE requires netchop_txt (existing file path).")
    }
    netchop_txt_norm <- normalizePath(netchop_txt, winslash = "/", mustWork = FALSE)
    if (!file.exists(netchop_txt_norm)) {
      stop("use_netchop=TRUE requires netchop_txt (existing file path). Not found: ", netchop_txt_norm)
    }
    
    # ---- NetChop parsing + boundary scores ----
    nc_dt <- parse_netchop_txt(netchop_txt_norm)
    score_dt <- netchop_boundary_scores(map_dt, nc_dt)
    if (!("netchop_score_boundary" %in% names(score_dt))) {
      stop("netchop_boundary_scores() did not return netchop_score_boundary column.")
    }
    
    found_n <- sum(is.finite(score_dt$netchop_score_boundary))
    total_n <- nrow(score_dt)
    message(sprintf("NetChop boundary scores: %d/%d AB pairs found in NetChop txt.", found_n, total_n))
    if (found_n == 0) stop("No NetChop boundary scores found. Please check netchop_txt format and pep_id mapping.")
    
    # Edges passing threshold
    edges_dt <- data.table::as.data.table(score_dt)
    edges_dt <- edges_dt[is.finite(netchop_score_boundary) & netchop_score_boundary >= netchop_thr, ]
    edges_dt <- edges_dt[!is.na(A) & nzchar(A) & !is.na(B) & nzchar(B) & A != B]
    edges_dt <- edges_dt[, .(
      A = toupper(trimws(A)),
      B = toupper(trimws(B)),
      netchop_score_boundary = as.numeric(netchop_score_boundary)
    )]
    edges_dt <- unique(edges_dt)
    
    edge_score_type <- "netchop_score_boundary"
    message(sprintf("Edges passing netchop_thr=%.3f: %d", netchop_thr, nrow(edges_dt)))
    if (!nrow(edges_dt)) stop("No AB edges pass netchop_thr.")
    
    edges_use <- edges_dt[, c("A", "B", "netchop_score_boundary"), with = FALSE]
    
  } else {
    # ---- NO NetChop mode ----
    if (!is.null(netchop_txt) && nzchar(netchop_txt)) {
      message("use_netchop=FALSE: netchop_txt is provided but will be ignored.")
    }
    message("use_netchop=FALSE: NetChop disabled. Using AB pairs in map_dt as directed edges (weight = AB occurrence count).")
    message("This mode is deterministic (no random stitching).")
    
    dt0 <- data.table::as.data.table(map_dt)
    dt0 <- dt0[!is.na(A) & nzchar(A) & !is.na(B) & nzchar(B)]
    dt0[, A := toupper(trimws(as.character(A)))]
    dt0[, B := toupper(trimws(as.character(B)))]
    dt0 <- dt0[A != B]
    
    # weight = count of same A->B occurrences
    edges_dt <- dt0[, .N, by = .(A, B)]
    data.table::setnames(edges_dt, "N", "edge_support")
    edges_dt[, netchop_score_boundary := as.numeric(edge_support)]
    edges_dt <- edges_dt[, .(A, B, netchop_score_boundary, edge_support)]
    edges_dt <- unique(edges_dt)
    
    edge_score_type <- "edge_support_count"
    found_n <- NA_integer_
    total_n <- nrow(edges_dt)
    
    message(sprintf("Edges (unique A->B) from map_dt: %d", nrow(edges_dt)))
    if (!nrow(edges_dt)) stop("No AB edges available from map_dt (after cleaning).")
    
    edges_use <- edges_dt[, c("A", "B", "netchop_score_boundary"), with = FALSE]
  }
  
  # ---- maximize multi-chain assembly ----
  if (isTRUE(use_maximize)) {
    if (isTRUE(verbose)) {
      message(sprintf(
        "Maximize enabled: trying %d start peptides (objective = most peptides used; tie-break by total AA).",
        length(pep_universe)
      ))
    }
    asm <- .maximize_multi_chain_all_starts(
      peptides = pep_universe,
      pep_len = pep_len_map,
      edges_dt = edges_use,
      n_chains = as.integer(n_chains),
      max_chain_AA = as.integer(max_chain_AA),
      verbose = isTRUE(verbose),
      progress_every = as.integer(maximize_progress_every)
    )
  } else {
    # deterministic start (not random) if you want: pick lexicographically smallest peptide
    # but keep your previous behavior if you prefer randomness; here we keep deterministic.
    start_pep <- pep_universe[[1]]
    if (isTRUE(verbose)) message(sprintf("Maximize disabled: start peptide = %s", start_pep))
    asm <- .assemble_multi_chain_single_start(
      peptides = pep_universe,
      pep_len = pep_len_map,
      edges_dt = edges_use,
      start_peptide = start_pep,
      n_chains = as.integer(n_chains),
      max_chain_AA = as.integer(max_chain_AA),
      verbose = isTRUE(verbose)
    )
  }
  if (is.null(asm) || !length(asm$chains)) stop("Assembly failed to produce any chains.")
  
  chains <- asm$chains
  edge_used <- asm$edges
  
  # ---- build chain + edge outputs ----
  chain_rows <- list()
  for (i in seq_along(chains)) {
    ch <- chains[[i]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    if (!length(ch)) next
    ch_len <- sum(nchar(ch))
    ch_seq <- paste0(ch, collapse = "")
    ch_peps <- paste(ch, collapse = "|")
    # per-peptide sources aligned to peptide order; per-peptide sources separated by ';'
    ch_src <- vapply(ch, function(p) {
      s <- unname(src_map[[p]])
      if (is.null(s) || is.na(s) || !nzchar(s)) "NA" else s
    }, character(1))
    ch_src_str <- paste(ch_src, collapse = ";")
    chain_rows[[length(chain_rows) + 1]] <- data.frame(
      chain_id = i,
      n_peptides = length(ch),
      chain_AA = ch_len,
      chain_sequence = ch_seq,
      peptides = ch_peps,
      peptide_sources = ch_src_str,
      stringsAsFactors = FALSE
    )
  }
  if (length(chain_rows)) {
    chain_df <- do.call(rbind, chain_rows)
  } else {
    chain_df <- data.frame(
      chain_id = integer(0),
      n_peptides = integer(0),
      chain_AA = integer(0),
      chain_sequence = character(0),
      peptides = character(0),
      peptide_sources = character(0),
      stringsAsFactors = FALSE
    )
  }
  
  used_peptides <- sort(unique(unlist(chains)))
  total_chains_built <- nrow(chain_df)
  total_peptides_used <- if (nrow(chain_df)) sum(chain_df$n_peptides) else 0L
  total_AA_used <- if (nrow(chain_df)) sum(chain_df$chain_AA) else 0L
  unused_peptides <- setdiff(pep_universe, used_peptides)
  
  unassigned_tsv <- file.path(out_dir, paste0(out_base, "_unassigned_peptides.tsv"))
  unassigned_dt <- data.frame(
    Peptide = unused_peptides,
    pep_len = nchar(unused_peptides),
    source_proteins = unname(src_map[unused_peptides]),
    stringsAsFactors = FALSE
  )
  
  peptides_all_str <- if (length(used_peptides)) paste(used_peptides, collapse = ";") else ""
  src_all <- unname(src_map[used_peptides])
  if (length(src_all)) src_all[is.na(src_all) | !nzchar(src_all)] <- "NA"
  src_all_str <- if (length(src_all)) paste(src_all, collapse = ";") else ""
  
  summary_row <- data.frame(
    chain_id = "SUMMARY",
    n_peptides = total_peptides_used,
    chain_AA = total_AA_used,
    chain_sequence = NA_character_,
    peptides = peptides_all_str,
    peptide_sources = src_all_str,
    stringsAsFactors = FALSE
  )
  summary_row$total_chains_built <- total_chains_built
  summary_row$total_chains_requested <- as.integer(n_chains)
  summary_row$max_chain_AA <- as.integer(max_chain_AA)
  summary_row$total_unique_peptides_universe <- length(pep_universe)
  summary_row$unused_unique_peptides <- length(unused_peptides)
  summary_row$start_peptide_best <- asm$start_peptide
  summary_row$use_maximize <- isTRUE(use_maximize)
  summary_row$use_netchop <- isTRUE(use_netchop)
  summary_row$edge_score_type <- edge_score_type
  summary_row$netchop_thr <- if (isTRUE(use_netchop)) as.numeric(netchop_thr) else NA_real_
  
  for (cn in names(summary_row)) {
    if (!(cn %in% names(chain_df))) chain_df[[cn]] <- NA
  }
  chain_df <- chain_df[, names(summary_row), drop = FALSE]
  chain_out <- rbind(summary_row, chain_df)
  
  edge_out <- edge_used
  if (nrow(edge_out)) {
    edge_out$A_len <- unname(pep_len_map[edge_out$A])
    edge_out$B_len <- unname(pep_len_map[edge_out$B])
    edge_out$use_netchop <- isTRUE(use_netchop)
    edge_out$edge_score_type <- edge_score_type
  }
  
  chain_tsv <- file.path(out_dir, paste0(out_base, "_chains.tsv"))
  edge_tsv  <- file.path(out_dir, paste0(out_base, "_edges.tsv"))
  state_rds <- file.path(out_dir, paste0(out_base, "_stage2_state.rds"))
  
  if (!overwrite) {
    for (p in c(chain_tsv, edge_tsv, unassigned_tsv, state_rds)) {
      if (file.exists(p)) stop("Output already exists (overwrite=FALSE): ", p)
    }
  }
  
  readr::write_tsv(chain_out, chain_tsv)
  readr::write_tsv(edge_out, edge_tsv)
  readr::write_tsv(unassigned_dt, unassigned_tsv)
  
  saveRDS(
    list(
      stage1_state_rds = stage1_state_rds,
      use_netchop = isTRUE(use_netchop),
      netchop_txt = if (isTRUE(use_netchop)) netchop_txt_norm else NA_character_,
      netchop_thr = if (isTRUE(use_netchop)) as.numeric(netchop_thr) else NA_real_,
      edge_score_type = edge_score_type,
      netchop_pairs_found = found_n,
      netchop_pairs_total = total_n,
      pep_universe = pep_universe,
      peptide_sources = src_dt,
      edges_passing = if (exists("edges_dt")) as.data.frame(edges_dt) else NULL,
      chains = chains,
      chain_table = chain_out,
      edge_table = edge_out,
      unassigned_table = unassigned_dt,
      unassigned_tsv = unassigned_tsv,
      start_peptide_best = asm$start_peptide,
      objective = asm$objective
    ),
    state_rds
  )
  
  invisible(list(
    chain_tsv = chain_tsv,
    edge_tsv = edge_tsv,
    unassigned_tsv = unassigned_tsv,
    stage2_state_rds = state_rds
  ))
}

#' Stage2 assembly with maximize search over all start peptides
#'
#' Convenience wrapper around [classI_stage2()] that always enables `use_maximize = TRUE`.
#'
#' @inheritParams classI_stage2
#' @export
classI_stage2_maximize_assembly <- function(stage1_state_rds,
                                            netchop_txt = NULL,
                                            use_netchop = TRUE,
                                            out_dir,
                                            out_base = "stage2",
                                            netchop_thr = 0.5,
                                            n_chains = 5,
                                            max_chain_AA = 100,
                                            seed = 1,
                                            verbose = TRUE,
                                            overwrite = TRUE) {
  classI_stage2(
    stage1_state_rds = stage1_state_rds,
    netchop_txt = netchop_txt,
    use_netchop = use_netchop,
    out_dir = out_dir,
    out_base = out_base,
    netchop_thr = netchop_thr,
    n_chains = n_chains,
    max_chain_AA = max_chain_AA,
    use_maximize = TRUE,
    maximize_progress_every = 1L,
    seed = seed,
    verbose = verbose,
    overwrite = overwrite
  )
}
