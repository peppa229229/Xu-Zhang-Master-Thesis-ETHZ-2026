# Winner allele/rank ----------------------------------------------------------

#' @keywords internal
compute_winner <- function(dt) {
  # dt may be data.frame or data.table
  cn <- names(dt)
  # rank columns
  rank_cols <- grep("(?i)_Rank$", cn, value = TRUE, perl = TRUE)
  # exclude obvious non-rank columns
  rank_cols <- rank_cols[!grepl("(?i)BA_Rank$", rank_cols, perl = TRUE)]
  if (!length(rank_cols)) {
    stop("No '*_Rank' columns found. After cleaning, the table must contain allele rank columns like 'HLA-A02:01_Rank' or 'HLA-A02:01_EL_Rank'.")
  }

  # parse numeric ranks per column
  rank_mat <- lapply(rank_cols, function(col) vapply(dt[[col]], .parse_numeric_min, numeric(1)))
  rank_mat <- do.call(cbind, rank_mat)
  colnames(rank_mat) <- rank_cols

  # winner per row
  winner_idx <- apply(rank_mat, 1, function(r) {
    if (all(is.na(r))) return(NA_integer_)
    which.min(ifelse(is.na(r), Inf, r))
  })

  winner_rank <- vapply(seq_along(winner_idx), function(i) {
    j <- winner_idx[[i]]
    if (is.na(j)) return(NA_real_)
    rank_mat[i, j]
  }, numeric(1))

  winner_allele <- vapply(seq_along(winner_idx), function(i) {
    j <- winner_idx[[i]]
    if (is.na(j)) return(NA_character_)
    # remove suffix
    gsub("(?i)_Rank$", "", rank_cols[[j]], perl = TRUE)
  }, character(1))

  list(winner_allele = winner_allele, winner_rank = winner_rank)
}
