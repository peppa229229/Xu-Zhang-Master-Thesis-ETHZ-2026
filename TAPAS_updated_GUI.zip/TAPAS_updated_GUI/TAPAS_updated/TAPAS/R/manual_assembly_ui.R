# classI_manual_assembly_ui.R
# Updated:
# - Fix NA/length-0 logical checks that could trigger:
#     "missing value where TRUE/FALSE needed"
# - classI_manual_assembly_ui(..., use_netchop = TRUE/FALSE/NULL)
#   * TRUE  -> original NetChop UI (threshold + insertion suggestions + boost)
#   * FALSE -> no-NetChop UI (like Class II manual): manual prepend/append/new chain + constraints + rebuild
#   * NULL  -> infer from Stage2 state (st2$use_netchop if present; else edges_passing availability)
# - NEW: Add-ons tab
#   * Insert custom sequence(s) to chain(s): head / tail / between each junction (each has checkbox + input box)
#   * Apply to one chain OR all chains
#   * Custom chain names (stored, shown in chain table, included in exports/state)
#
# Note: This file assumes helper functions .ensure_unassigned_df, .chains_detail_df, .gene_distribution_df etc
# are defined here (they are included below).

# Manual insertion UI ---------------------------------------------------------

.clean_pep <- function(x) {
  stringr::str_to_upper(stringr::str_replace_all(as.character(x), "[^A-Z]", ""))
}

# ---- Robust scalar helpers (fix NA/length-0 in if conditions) ---------------

.safe_int1 <- function(x, default = NA_integer_) {
  v <- suppressWarnings(as.integer(x))
  if (length(v) != 1L || is.na(v)) return(default)
  v
}

.safe_num1 <- function(x, default = NA_real_) {
  v <- suppressWarnings(as.numeric(x))
  if (length(v) != 1L || is.na(v)) return(default)
  v
}

# ---- Chain-name helpers -----------------------------------------------------

.ensure_chain_names <- function(chain_names, n) {
  if (is.null(chain_names)) chain_names <- character(0)
  chain_names <- as.character(chain_names)
  chain_names[is.na(chain_names)] <- ""
  if (length(chain_names) < n) {
    chain_names <- c(chain_names, rep("", n - length(chain_names)))
  } else if (length(chain_names) > n) {
    chain_names <- chain_names[seq_len(n)]
  }
  chain_names
}

.chain_label <- function(chain_id, chain_names) {
  cid <- suppressWarnings(as.integer(chain_id))
  if (length(cid) != 1L || is.na(cid) || !is.finite(cid) || cid < 1) return(as.character(chain_id))
  nm <- ""
  if (!is.null(chain_names) && length(chain_names) >= cid) {
    nm <- as.character(chain_names[[cid]])
    if (is.na(nm)) nm <- ""
    nm <- trimws(nm)
  }
  if (nzchar(nm)) sprintf("%d (%s)", cid, nm) else sprintf("%d", cid)
}

# ---- Edge helpers -----------------------------------------------------------

.edge_lookup_max <- function(edges_dt) {
  # Expect columns: A, B, netchop_score_boundary
  dt <- data.table::as.data.table(edges_dt)
  if (!all(c("A", "B", "netchop_score_boundary") %in% names(dt))) {
    stop("edges_dt must have columns: A, B, netchop_score_boundary")
  }
  dt[, A := toupper(trimws(as.character(A)))]
  dt[, B := toupper(trimws(as.character(B)))]
  dt[, netchop_score_boundary := as.numeric(netchop_score_boundary)]
  dt <- dt[!is.na(netchop_score_boundary) & is.finite(netchop_score_boundary) & nzchar(A) & nzchar(B) & A != B]
  dt2 <- dt[, .(netchop_score_boundary = max(netchop_score_boundary, na.rm = TRUE)), by = .(A, B)]
  data.table::setkey(dt2, A, B)
  dt2
}

.edge_score <- function(edges_lu, A, B) {
  if (length(A) != length(B)) stop("A and B must have same length")
  A <- toupper(trimws(as.character(A)))
  B <- toupper(trimws(as.character(B)))
  out <- rep(NA_real_, length(A))
  # fast join
  q <- data.table::data.table(A = A, B = B, idx = seq_along(A))
  data.table::setkey(q, A, B)
  hit <- edges_lu[q, nomatch = 0L]
  if (nrow(hit)) out[hit$idx] <- hit$netchop_score_boundary
  out
}

.chain_score_sum <- function(chain, edges_lu) {
  if (length(chain) < 2) return(0)
  A <- chain[-length(chain)]
  B <- chain[-1]
  s <- .edge_score(edges_lu, A, B)
  s[is.na(s) | !is.finite(s)] <- 0
  sum(s)
}

.chain_AA_len <- function(chain) {
  if (!length(chain)) return(0L)
  sum(nchar(chain))
}

.chains_summary_df <- function(chains, edges_lu, chain_names = NULL) {
  chain_names <- .ensure_chain_names(chain_names, length(chains))
  out <- data.frame(
    chain_id = integer(0),
    chain_name = character(0),
    n_peptides = integer(0),
    chain_AA = integer(0),
    peptides = character(0),
    stringsAsFactors = FALSE
  )
  if (!length(chains)) return(out)
  for (i in seq_along(chains)) {
    ch <- chains[[i]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    out <- rbind(out, data.frame(
      chain_id = i,
      chain_name = chain_names[[i]],
      n_peptides = length(ch),
      chain_AA = .chain_AA_len(ch),
      peptides = paste(ch, collapse = "|"),
      stringsAsFactors = FALSE
    ))
  }
  out
}

# ---- Gene/source helpers ----------------------------------------------------
# ---- Gene/source helpers ----------------------------------------------------

.split_genes <- function(x) {
  # Normalize a gene/protein annotation string into a vector of tokens.
  # Accepts comma or semicolon separated lists.
  x <- as.character(x)
  if (is.na(x) || !nzchar(x) || identical(x, "NA")) return(character(0))
  x <- gsub("\\s+", "", x)
  # split on comma/semicolon
  toks <- unlist(strsplit(x, "[,;]", fixed = FALSE), use.names = FALSE)
  toks <- toks[!is.na(toks) & nzchar(toks) & toks != "NA"]
  unique(toks)
}

.all_genes_from_src_map <- function(src_map) {
  if (is.null(src_map) || !length(src_map)) return(character(0))
  v <- unname(src_map)
  genes <- unique(unlist(lapply(v, .split_genes), use.names = FALSE))
  genes <- genes[!is.na(genes) & nzchar(genes)]
  sort(unique(genes))
}

# ---- NEW: safe src_map getter (fix "subscript out of bounds") ---------------

.src_map_get1 <- function(src_map, pep) {
  # Return a single character annotation or NA_character_ if not found/invalid.
  if (is.null(src_map) || !length(src_map)) return(NA_character_)
  pep <- toupper(trimws(as.character(pep)))
  if (length(pep) != 1L || is.na(pep) || !nzchar(pep)) return(NA_character_)
  nm <- names(src_map)
  if (is.null(nm) || !length(nm) || !(pep %in% nm)) return(NA_character_)
  
  v <- NA_character_
  if (is.list(src_map)) {
    v <- src_map[[pep]]
  } else {
    v <- unname(src_map[pep])
    if (length(v) >= 1L) v <- v[[1L]]
  }
  v <- as.character(v)
  if (length(v) != 1L || is.na(v) || !nzchar(v)) return(NA_character_)
  v
}

.gene_for_peptide <- function(p, src_map) {
  p <- toupper(trimws(as.character(p)))
  s <- .src_map_get1(src_map, p)
  if (is.na(s) || !nzchar(s)) "NA" else as.character(s)
}

# ---- Unassigned table helpers ----------------------------------------------

.ensure_unassigned_df <- function(df) {
  if (is.null(df) || !is.data.frame(df) || !nrow(df)) {
    return(data.frame(
      Peptide = character(0),
      pep_len = integer(0),
      source_proteins = character(0),
      stringsAsFactors = FALSE
    ))
  }
  if (!("Peptide" %in% names(df))) stop("unassigned_table must contain column 'Peptide'.")
  if (!("pep_len" %in% names(df))) df$pep_len <- nchar(toupper(trimws(as.character(df$Peptide))))
  if (!("source_proteins" %in% names(df))) df$source_proteins <- NA_character_
  df$Peptide <- toupper(trimws(as.character(df$Peptide)))
  df <- df[!is.na(df$Peptide) & nzchar(df$Peptide), , drop = FALSE]
  df
}

.add_peptides_to_unassigned <- function(unassigned_df, peptides, src_map) {
  unassigned_df <- .ensure_unassigned_df(unassigned_df)
  peptides <- toupper(trimws(as.character(peptides)))
  peptides <- peptides[!is.na(peptides) & nzchar(peptides)]
  if (!length(peptides)) return(unassigned_df)
  
  existing <- toupper(trimws(as.character(unassigned_df$Peptide)))
  to_add <- setdiff(unique(peptides), unique(existing))
  if (!length(to_add)) return(unassigned_df)
  
  add_df <- data.frame(
    Peptide = to_add,
    pep_len = nchar(to_add),
    source_proteins = vapply(to_add, .gene_for_peptide, character(1), src_map = src_map),
    stringsAsFactors = FALSE
  )
  out <- rbind(unassigned_df, add_df)
  out <- out[order(out$Peptide), , drop = FALSE]
  rownames(out) <- NULL
  out
}

# ---- Chain detail + gene distribution --------------------------------------

.chains_detail_df <- function(chains, src_map, selected_gene = "") {
  rows <- list()
  k <- 0L
  sel <- as.character(selected_gene)
  if (is.na(sel)) sel <- ""
  sel <- trimws(sel)
  for (cid in seq_along(chains)) {
    ch <- chains[[cid]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    if (!length(ch)) next
    for (i in seq_along(ch)) {
      pep <- ch[[i]]
      gene <- .gene_for_peptide(pep, src_map)
      is_hit <- FALSE
      if (nzchar(sel)) {
        is_hit <- sel %in% .split_genes(gene)
      }
      k <- k + 1L
      rows[[k]] <- data.frame(
        chain_id = cid,
        position = i,
        peptide = pep,
        gene = gene,
        highlight = is_hit,
        stringsAsFactors = FALSE
      )
    }
  }
  if (!length(rows)) {
    return(data.frame(
      chain_id = integer(0), position = integer(0), peptide = character(0), gene = character(0), highlight = logical(0),
      stringsAsFactors = FALSE
    ))
  }
  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}

.gene_distribution_df <- function(chains, unassigned_df, src_map) {
  # Gene-level summary of where peptides are currently located.
  # - A peptide can map to multiple genes (comma/semicolon separated); it will count toward each.
  # - "NA" is used when a peptide lacks a gene annotation.
  unassigned_df <- .ensure_unassigned_df(unassigned_df)
  
  # Total amino-acid length for each gene across the *full peptide universe we know about*.
  peps_all <- unique(c(
    unlist(chains),
    unassigned_df$Peptide,
    if (!is.null(src_map)) names(src_map) else character(0)
  ))
  peps_all <- toupper(trimws(as.character(peps_all)))
  peps_all <- peps_all[!is.na(peps_all) & nzchar(peps_all)]
  gene_total_len <- integer(0)
  if (length(peps_all)) {
    for (p in peps_all) {
      genes <- .split_genes(.gene_for_peptide(p, src_map))
      if (!length(genes)) genes <- "NA"
      lp <- nchar(p)
      for (g in genes) {
        if (!nzchar(g)) next
        if (is.na(g)) g <- "NA"
        if (!(g %in% names(gene_total_len))) gene_total_len[g] <- 0L
        gene_total_len[g] <- as.integer(gene_total_len[g]) + lp
      }
    }
  }
  
  rows <- list()
  k <- 0L
  
  # in chains
  for (cid in seq_along(chains)) {
    ch <- chains[[cid]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    if (!length(ch)) next
    for (pep in ch) {
      genes <- .split_genes(.gene_for_peptide(pep, src_map))
      if (!length(genes)) genes <- "NA"
      for (g in genes) {
        k <- k + 1L
        rows[[k]] <- data.frame(
          gene = g,
          chain_id = cid,
          in_chain = 1L,
          in_unassigned = 0L,
          stringsAsFactors = FALSE
        )
      }
    }
  }
  
  # in unassigned
  if (nrow(unassigned_df)) {
    for (pep in unassigned_df$Peptide) {
      genes <- .split_genes(.gene_for_peptide(pep, src_map))
      if (!length(genes)) genes <- "NA"
      for (g in genes) {
        k <- k + 1L
        rows[[k]] <- data.frame(
          gene = g,
          chain_id = NA_integer_,
          in_chain = 0L,
          in_unassigned = 1L,
          stringsAsFactors = FALSE
        )
      }
    }
  }
  
  long <- if (length(rows)) do.call(rbind, rows) else data.frame(
    gene = character(0), chain_id = integer(0), in_chain = integer(0), in_unassigned = integer(0),
    stringsAsFactors = FALSE
  )
  
  # Ensure we list all genes we know about
  genes_all <- sort(unique(c(long$gene, .all_genes_from_src_map(src_map))))
  if (!length(genes_all)) {
    return(data.frame(
      gene = character(0),
      chains = character(0),
      chain_counts = character(0),
      n_chains = integer(0),
      n_peptides_in_chains = integer(0),
      n_peptides_unassigned = integer(0),
      total_pep_AA = integer(0),
      stringsAsFactors = FALSE
    ))
  }
  
  out_rows <- lapply(genes_all, function(g) {
    sub <- long[long$gene == g, , drop = FALSE]
    ch_ids <- sub$chain_id[!is.na(sub$chain_id) & is.finite(sub$chain_id)]
    ch_ids <- suppressWarnings(as.integer(ch_ids))
    ch_ids <- ch_ids[!is.na(ch_ids) & is.finite(ch_ids) & ch_ids >= 1]
    ch_uniq <- sort(unique(ch_ids))
    chains_str <- if (length(ch_uniq)) paste(ch_uniq, collapse = ",") else ""
    
    if (length(ch_ids)) {
      tab <- table(ch_ids)
      cc <- paste0(names(tab), ":", as.integer(tab))
      cc <- paste(cc, collapse = ";")
    } else {
      cc <- ""
    }
    
    data.frame(
      gene = g,
      chains = chains_str,
      chain_counts = cc,
      n_chains = length(ch_uniq),
      n_peptides_in_chains = sum(sub$in_chain, na.rm = TRUE),
      n_peptides_unassigned = sum(sub$in_unassigned, na.rm = TRUE),
      total_pep_AA = if (g %in% names(gene_total_len)) as.integer(gene_total_len[g]) else 0L,
      stringsAsFactors = FALSE
    )
  })
  
  out <- do.call(rbind, out_rows)
  out <- out[order(-out$n_chains, -out$n_peptides_in_chains, -out$n_peptides_unassigned, out$gene), , drop = FALSE]
  rownames(out) <- NULL
  out
}

# ---- Add-ons helpers (NEW) --------------------------------------------------

.init_chain_names <- function(n, chain_names = NULL) {
  n <- suppressWarnings(as.integer(n))
  if (!is.finite(n) || n < 1) n <- 1L
  if (!is.null(chain_names) && length(chain_names) >= n) {
    x <- as.character(chain_names)[seq_len(n)]
    x[is.na(x) | !nzchar(x)] <- paste0("Chain ", which(is.na(x) | !nzchar(x)))
    return(x)
  }
  paste0("Chain ", seq_len(n))
}

.init_addons <- function(n, addons = NULL) {
  n <- suppressWarnings(as.integer(n))
  if (!is.finite(n) || n < 1) n <- 1L
  
  mk1 <- function() list(head = "", tail = "", junction = "")
  out <- vector("list", n)
  for (i in seq_len(n)) out[[i]] <- mk1()
  
  if (!is.null(addons) && length(addons)) {
    m <- min(length(addons), n)
    for (i in seq_len(m)) {
      a <- addons[[i]]
      if (is.list(a)) {
        out[[i]]$head <- if (!is.null(a$head)) as.character(a$head) else ""
        out[[i]]$tail <- if (!is.null(a$tail)) as.character(a$tail) else ""
        out[[i]]$junction <- if (!is.null(a$junction)) as.character(a$junction) else ""
      }
    }
  }
  out
}

.chain_sequence_with_addons <- function(chain_peps, addon_head = "", addon_junction = "", addon_tail = "") {
  ch <- toupper(trimws(as.character(chain_peps)))
  ch <- ch[!is.na(ch) & nzchar(ch)]
  
  h <- .clean_pep(addon_head)
  j <- .clean_pep(addon_junction)
  t <- .clean_pep(addon_tail)
  
  seq_out <- ""
  if (nzchar(h)) seq_out <- paste0(seq_out, h)
  
  if (length(ch)) {
    seq_out <- paste0(seq_out, ch[[1]])
    if (length(ch) >= 2) {
      for (i in 2:length(ch)) {
        if (nzchar(j)) seq_out <- paste0(seq_out, j)
        seq_out <- paste0(seq_out, ch[[i]])
      }
    }
  }
  
  if (nzchar(t)) seq_out <- paste0(seq_out, t)
  seq_out
}

# ---- Insertion helpers ------------------------------------------------------

.insert_options_for_peptide <- function(X, chains, edges_lu, netchop_thr, max_chain_AA = Inf) {
  X <- toupper(trimws(as.character(X)))
  if (is.na(X) || !nzchar(X)) return(data.frame())
  
  lenX <- nchar(X)
  
  maxv <- .safe_num1(max_chain_AA, default = Inf)
  if (!is.finite(maxv) || maxv < 1) maxv <- Inf
  
  rows <- list()
  k <- 0L
  for (cid in seq_along(chains)) {
    ch <- chains[[cid]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    if (!length(ch)) next
    
    ch_len <- .chain_AA_len(ch)
    if (is.finite(maxv) && (ch_len + lenX > maxv)) next
    
    # head: X -> first
    s_x1 <- .edge_score(edges_lu, X, ch[1])
    if (!is.na(s_x1) && is.finite(s_x1) && s_x1 >= netchop_thr) {
      k <- k + 1L
      rows[[k]] <- data.frame(
        insert_peptide = X,
        chain_id = cid,
        insert_type = "head",
        position = "before_1",
        A = NA_character_,
        B = ch[1],
        score_AX = NA_real_,
        score_XB = s_x1,
        score_AB = NA_real_,
        score_min = s_x1,
        score_mean = s_x1,
        score_sum = s_x1,
        stringsAsFactors = FALSE
      )
    }
    
    # tail: last -> X
    s_lx <- .edge_score(edges_lu, ch[length(ch)], X)
    if (!is.na(s_lx) && is.finite(s_lx) && s_lx >= netchop_thr) {
      k <- k + 1L
      rows[[k]] <- data.frame(
        insert_peptide = X,
        chain_id = cid,
        insert_type = "tail",
        position = paste0("after_", length(ch)),
        A = ch[length(ch)],
        B = NA_character_,
        score_AX = s_lx,
        score_XB = NA_real_,
        score_AB = NA_real_,
        score_min = s_lx,
        score_mean = s_lx,
        score_sum = s_lx,
        stringsAsFactors = FALSE
      )
    }
    
    # between adjacent peptides: A->X and X->B
    if (length(ch) >= 2) {
      for (i in seq_len(length(ch) - 1)) {
        A <- ch[i]
        B <- ch[i + 1]
        s_ax <- .edge_score(edges_lu, A, X)
        s_xb <- .edge_score(edges_lu, X, B)
        if (!is.na(s_ax) && !is.na(s_xb) && is.finite(s_ax) && is.finite(s_xb) && s_ax >= netchop_thr && s_xb >= netchop_thr) {
          s_ab <- .edge_score(edges_lu, A, B)
          if (is.na(s_ab) || !is.finite(s_ab)) s_ab <- NA_real_
          k <- k + 1L
          rows[[k]] <- data.frame(
            insert_peptide = X,
            chain_id = cid,
            insert_type = "between",
            position = paste0("between_", i, "_", i + 1),
            A = A,
            B = B,
            score_AX = s_ax,
            score_XB = s_xb,
            score_AB = s_ab,
            score_min = min(s_ax, s_xb),
            score_mean = mean(c(s_ax, s_xb)),
            score_sum = s_ax + s_xb,
            stringsAsFactors = FALSE
          )
        }
      }
    }
  }
  
  if (!length(rows)) return(data.frame())
  out <- do.call(rbind, rows)
  out <- out[order(-out$score_min, -out$score_mean, -out$score_sum), , drop = FALSE]
  rownames(out) <- NULL
  out
}

.apply_insertion <- function(chains, opt_row) {
  cid <- suppressWarnings(as.integer(opt_row$chain_id))
  if (length(cid) != 1L || is.na(cid) || !is.finite(cid) || cid < 1 || cid > length(chains)) stop("Invalid chain_id")
  X <- as.character(opt_row$insert_peptide)
  typ <- as.character(opt_row$insert_type)
  pos <- as.character(opt_row$position)
  
  ch <- chains[[cid]]
  ch <- ch[!is.na(ch) & nzchar(ch)]
  if (!length(ch)) stop("Target chain is empty")
  
  if (typ == "head") {
    ch2 <- c(X, ch)
  } else if (typ == "tail") {
    ch2 <- c(ch, X)
  } else if (typ == "between") {
    m <- regmatches(pos, regexec("between_(\\d+)_(\\d+)", pos))[[1]]
    if (length(m) != 3) stop("Cannot parse position: ", pos)
    i <- suppressWarnings(as.integer(m[2]))
    if (length(i) != 1L || is.na(i) || !is.finite(i) || i < 1 || i >= length(ch)) stop("Invalid between position")
    ch2 <- append(ch, X, after = i)
  } else {
    stop("Unknown insert_type: ", typ)
  }
  
  chains[[cid]] <- ch2
  chains
}

.edges_from_chains <- function(chains, edges_lu) {
  rows <- list()
  k <- 0L
  for (cid in seq_along(chains)) {
    ch <- chains[[cid]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    if (length(ch) < 2) next
    for (i in seq_len(length(ch) - 1)) {
      A <- ch[i]
      B <- ch[i + 1]
      s <- .edge_score(edges_lu, A, B)
      k <- k + 1L
      rows[[k]] <- data.frame(
        chain_id = cid,
        step = i,
        A = A,
        B = B,
        netchop_score_boundary = s,
        stringsAsFactors = FALSE
      )
    }
  }
  if (!length(rows)) return(data.frame(chain_id = integer(0), step = integer(0), A = character(0), B = character(0), netchop_score_boundary = numeric(0)))
  out <- do.call(rbind, rows)
  rownames(out) <- NULL
  out
}

.build_chain_table <- function(chains, edges_lu, src_map = NULL,
                               chain_names = NULL, addons = NULL) {
  chain_names <- .init_chain_names(length(chains), chain_names)
  addons <- .init_addons(length(chains), addons)
  
  chain_rows <- list()
  for (i in seq_along(chains)) {
    ch <- chains[[i]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    if (!length(ch)) next
    
    ch_len <- .chain_AA_len(ch)
    ch_seq_base <- paste0(ch, collapse = "")
    ch_peps <- paste(ch, collapse = "|")
    
    ch_src <- if (is.null(src_map)) {
      rep("NA", length(ch))
    } else {
      vapply(ch, function(p) {
        s <- .src_map_get1(src_map, p)
        if (is.na(s) || !nzchar(s)) "NA" else s
      }, character(1))
    }
    
    ad <- addons[[i]]
    final_seq <- .chain_sequence_with_addons(
      ch,
      addon_head = ad$head,
      addon_junction = ad$junction,
      addon_tail = ad$tail
    )
    
    chain_rows[[length(chain_rows) + 1]] <- data.frame(
      chain_id = i,
      chain_name = chain_names[[i]],
      n_peptides = length(ch),
      chain_AA = ch_len,
      chain_sequence = ch_seq_base,
      addon_head = .clean_pep(ad$head),
      addon_junction = .clean_pep(ad$junction),
      addon_tail = .clean_pep(ad$tail),
      final_sequence = final_seq,
      final_AA = nchar(final_seq),
      peptides = ch_peps,
      peptide_sources = paste(ch_src, collapse = ";"),
      stringsAsFactors = FALSE
    )
  }
  
  if (length(chain_rows)) {
    chain_df <- do.call(rbind, chain_rows)
  } else {
    chain_df <- data.frame(
      chain_id = integer(0),
      chain_name = character(0),
      n_peptides = integer(0),
      chain_AA = integer(0),
      chain_sequence = character(0),
      addon_head = character(0),
      addon_junction = character(0),
      addon_tail = character(0),
      final_sequence = character(0),
      final_AA = integer(0),
      peptides = character(0),
      peptide_sources = character(0),
      stringsAsFactors = FALSE
    )
  }
  
  used_peptides <- sort(unique(unlist(chains)))
  total_peptides_used <- if (nrow(chain_df)) sum(chain_df$n_peptides) else 0L
  total_AA_used <- if (nrow(chain_df)) sum(chain_df$chain_AA) else 0L
  
  src_all <- if (is.null(src_map)) character(0) else unname(src_map[used_peptides])
  if (length(src_all)) src_all[is.na(src_all) | !nzchar(src_all)] <- "NA"
  
  summary_row <- data.frame(
    chain_id = "SUMMARY",
    chain_name = "",
    n_peptides = total_peptides_used,
    chain_AA = total_AA_used,
    chain_sequence = NA_character_,
    addon_head = NA_character_,
    addon_junction = NA_character_,
    addon_tail = NA_character_,
    final_sequence = NA_character_,
    final_AA = NA_integer_,
    peptides = if (length(used_peptides)) paste(used_peptides, collapse = ";") else "",
    peptide_sources = if (length(src_all)) paste(src_all, collapse = ";") else "",
    stringsAsFactors = FALSE
  )
  
  out <- rbind(summary_row, chain_df)
  rownames(out) <- NULL
  out
}

# ---- No-NetChop helper(s) ---------------------------------------------------

.edges_from_chains_na <- function(chains) {
  rows <- list(); k <- 0L
  for (cid in seq_along(chains)) {
    ch <- chains[[cid]]
    ch <- ch[!is.na(ch) & nzchar(ch)]
    if (length(ch) < 2) next
    for (step in 2:length(ch)) {
      k <- k + 1L
      rows[[k]] <- data.frame(
        chain_id = cid,
        step = step - 1L,
        A = ch[[step - 1L]],
        B = ch[[step]],
        netchop_score_boundary = NA_real_,
        stringsAsFactors = FALSE
      )
    }
  }
  if (!length(rows)) {
    return(data.frame(
      chain_id = integer(0),
      step = integer(0),
      A = character(0),
      B = character(0),
      netchop_score_boundary = numeric(0),
      stringsAsFactors = FALSE
    ))
  }
  do.call(rbind, rows)
}

# ---- Internal: Class I manual UI without NetChop ----------------------------
.classI_manual_assembly_ui_no_netchop <- function(stage2_state_rds,
                                                  st2,
                                                  pep_universe_vec,
                                                  src_map,
                                                  out_base = "manual_assembly",
                                                  launch_browser = TRUE) {
  if (!requireNamespace("shiny", quietly = TRUE)) stop("Package 'shiny' is required.")
  if (!requireNamespace("DT", quietly = TRUE)) stop("Package 'DT' is required.")
  if (!requireNamespace("readr", quietly = TRUE)) stop("Package 'readr' is required.")
  
  # number of chains + max length from Stage2 (robust to NA/NULL)
  n_chains0 <- suppressWarnings(as.integer(st2$n_chains))
  if (length(n_chains0) != 1L || is.na(n_chains0) || !is.finite(n_chains0) || n_chains0 < 1) {
    n_chains0 <- max(1L, length(st2$chains))
  }
  
  default_max_chain_AA <- suppressWarnings(as.numeric(st2$max_chain_AA))
  if (length(default_max_chain_AA) != 1L || is.na(default_max_chain_AA) || !is.finite(default_max_chain_AA) || default_max_chain_AA < 1) {
    default_max_chain_AA <- 200
  }
  
  init_unassigned <- .ensure_unassigned_df(st2$unassigned_table)
  all_genes <- .all_genes_from_src_map(src_map)
  
  # chain summary for display/export (includes names + add-ons preview)
  .chain_summary <- function(chains, chain_names, addons) {
    chain_names <- .init_chain_names(length(chains), chain_names)
    addons <- .init_addons(length(chains), addons)
    
    rows <- list()
    k <- 0L
    for (i in seq_along(chains)) {
      ch <- chains[[i]]
      ch <- ch[!is.na(ch) & nzchar(ch)]
      k <- k + 1L
      
      ch_src <- if (length(ch)) {
        vapply(ch, function(p) {
          s <- .src_map_get1(src_map, p)
          if (is.na(s) || !nzchar(s)) "NA" else s
        }, character(1))
      } else {
        character(0)
      }
      
      ad <- addons[[i]]
      if (!is.list(ad)) ad <- list(head = "", tail = "", junction = "")
      
      final_seq <- .chain_sequence_with_addons(
        ch,
        addon_head = ad$head,
        addon_junction = ad$junction,
        addon_tail = ad$tail
      )
      
      rows[[k]] <- data.frame(
        chain_id = i,
        chain_name = chain_names[[i]],
        n_peptides = length(ch),
        chain_AA = if (length(ch)) sum(nchar(ch)) else 0L,
        addon_head = .clean_pep(ad$head),
        addon_junction = .clean_pep(ad$junction),
        addon_tail = .clean_pep(ad$tail),
        final_AA = nchar(final_seq),
        peptides = if (length(ch)) paste(ch, collapse = "|") else "",
        peptide_sources = if (length(ch_src)) paste(ch_src, collapse = ";") else "",
        stringsAsFactors = FALSE
      )
    }
    do.call(rbind, rows)
  }
  
  .allowed_chains_for_peptide <- function(pep, cons) {
    pep <- toupper(trimws(as.character(pep)))
    if (is.na(pep) || !nzchar(pep)) return(NULL)
    if (is.null(cons) || !length(cons)) return(NULL)
    
    genes <- .split_genes(.gene_for_peptide(pep, src_map))
    hit <- intersect(genes, names(cons))
    if (!length(hit)) return(NULL)
    
    allowed <- NULL
    for (g in hit) {
      v <- suppressWarnings(as.integer(cons[[g]]))
      v <- v[!is.na(v) & is.finite(v) & v >= 1]
      if (is.null(allowed)) allowed <- v else allowed <- intersect(allowed, v)
    }
    if (is.null(allowed)) allowed <- integer(0)
    sort(unique(allowed))
  }
  
  .rebuild_under_constraints <- function(all_peps, cons, n_chains, max_chain_AA) {
    n_chains <- suppressWarnings(as.integer(n_chains))
    if (length(n_chains) != 1L || is.na(n_chains) || !is.finite(n_chains) || n_chains < 1) n_chains <- 1L
    
    max_chain_AA <- suppressWarnings(as.numeric(max_chain_AA))
    if (length(max_chain_AA) != 1L || is.na(max_chain_AA) || !is.finite(max_chain_AA) || max_chain_AA < 1) max_chain_AA <- Inf
    
    all_peps <- toupper(trimws(as.character(all_peps)))
    all_peps <- all_peps[!is.na(all_peps) & nzchar(all_peps)]
    all_peps <- sort(unique(all_peps))
    
    o <- order(-nchar(all_peps), all_peps)
    peps <- all_peps[o]
    
    chains <- vector("list", n_chains)
    lens <- numeric(n_chains)
    for (i in seq_len(n_chains)) chains[[i]] <- character(0)
    
    unassigned <- character(0)
    
    for (p in peps) {
      lp <- nchar(p)
      if (lp > max_chain_AA) {
        unassigned <- c(unassigned, p)
        next
      }
      
      allowed <- .allowed_chains_for_peptide(p, cons)
      if (is.null(allowed)) {
        allowed <- seq_len(n_chains)
      } else {
        allowed <- suppressWarnings(as.integer(allowed))
        allowed <- allowed[!is.na(allowed) & is.finite(allowed) & allowed >= 1 & allowed <= n_chains]
        if (!length(allowed)) {
          unassigned <- c(unassigned, p)
          next
        }
      }
      
      placed <- FALSE
      for (cid in allowed) {
        if ((lens[cid] + lp) <= max_chain_AA) {
          chains[[cid]] <- c(chains[[cid]], p)
          lens[cid] <- lens[cid] + lp
          placed <- TRUE
          break
        }
      }
      if (!placed) unassigned <- c(unassigned, p)
    }
    
    list(chains = chains, unassigned = unassigned)
  }
  
  ui <- shiny::fluidPage(
    shiny::titlePanel("Manual assembly: Class I (no NetChop)"),
    shiny::tabsetPanel(
      shiny::tabPanel(
        "Assembly",
        shiny::fluidRow(
          shiny::column(
            4,
            shiny::h4("Current chains"),
            DT::dataTableOutput("chains_tbl"),
            shiny::fluidRow(
              shiny::column(6, shiny::numericInput("detach_n", "Detach N peptides", value = 1, min = 1, step = 1)),
              shiny::column(6,
                            shiny::actionButton("detach_head_btn", "Detach head", class = "btn-warning"),
                            shiny::actionButton("detach_tail_btn", "Detach tail", class = "btn-warning"))
            ),
            shiny::hr(),
            shiny::h4("Gene highlight"),
            shiny::selectizeInput(
              "gene_filter",
              "Select a gene",
              choices = c("(none)" = "", stats::setNames(all_genes, all_genes)),
              selected = "",
              options = list(placeholder = "Type to search...")
            ),
            shiny::hr(),
            shiny::h4("Gene constraints"),
            shiny::helpText("Add constraints (gene -> allowed chain IDs), then rebuild chains under constraints."),
            shiny::selectizeInput(
              "restrict_gene",
              "Gene(s) for this rule",
              choices = c("(none)" = "", stats::setNames(all_genes, all_genes)),
              selected = character(0),
              multiple = TRUE,
              options = list(placeholder = "Type to search...")
            ),
            shiny::uiOutput("restrict_chains_ui"),
            shiny::numericInput("max_chain_AA", "Max chain AA length", value = default_max_chain_AA, min = 1, step = 1),
            shiny::fluidRow(
              shiny::column(6, shiny::actionButton("add_rule_btn", "Add / merge rule", class = "btn-info")),
              shiny::column(6, shiny::actionButton("clear_rules_btn", "Clear all rules", class = "btn-secondary"))
            ),
            shiny::actionButton("rebuild_btn", "Rebuild under constraints", class = "btn-danger"),
            shiny::h5("Active constraints"),
            DT::dataTableOutput("constraints_tbl"),
            shiny::hr(),
            shiny::h4("Unassigned peptides"),
            DT::dataTableOutput("unassigned_tbl"),
            shiny::uiOutput("current_pep_ui"),
            shiny::fluidRow(
              shiny::column(6, shiny::actionButton("prepend_btn", "Prepend to chain", class = "btn-primary")),
              shiny::column(6, shiny::actionButton("append_btn", "Append to chain", class = "btn-primary"))
            ),
            shiny::actionButton("new_chain_btn", "Start new empty chain", class = "btn-secondary"),
            shiny::hr(),
            shiny::downloadButton("download_zip", "Download manual assembly (zip)")
          ),
          shiny::column(
            8,
            shiny::h4("Chain detail"),
            DT::dataTableOutput("chain_detail_tbl"),
            shiny::hr(),
            shiny::h4("Gene distribution across chains"),
            DT::dataTableOutput("gene_dist_tbl")
          )
        )
      ),
      shiny::tabPanel(
        "Add-ons",
        shiny::fluidRow(
          shiny::column(
            4,
            shiny::h4("Target chain + naming"),
            shiny::uiOutput("addon_chain_ui"),
            shiny::textInput("chain_custom_name", "Customized chain name", value = ""),
            shiny::actionButton("apply_chain_name_btn", "Apply name to chain", class = "btn-info"),
            shiny::hr(),
            shiny::h4("Insert add-on sequences"),
            shiny::helpText("You can tick any combination of head / tail / between junctions. Each has its own sequence input."),
            shiny::fluidRow(
              shiny::column(4, shiny::checkboxInput("addon_head_on", "Head", value = FALSE)),
              shiny::column(8, shiny::textInput("addon_head_seq", "Head sequence", value = ""))
            ),
            shiny::fluidRow(
              shiny::column(4, shiny::checkboxInput("addon_tail_on", "Tail", value = FALSE)),
              shiny::column(8, shiny::textInput("addon_tail_seq", "Tail sequence", value = ""))
            ),
            shiny::fluidRow(
              shiny::column(4, shiny::checkboxInput("addon_junc_on", "Between junctions", value = FALSE)),
              shiny::column(8, shiny::textInput("addon_junc_seq", "Junction sequence", value = ""))
            ),
            shiny::fluidRow(
              shiny::column(6, shiny::actionButton("apply_addon_chain_btn", "Apply to chain", class = "btn-primary")),
              shiny::column(6, shiny::actionButton("apply_addon_all_btn", "Apply all", class = "btn-warning"))
            ),
            shiny::hr(),
            shiny::helpText("Notes: sequences will be cleaned to A–Z uppercase. Add-ons do not modify peptide chains; only final exported sequences.")
          ),
          shiny::column(
            8,
            shiny::h4("Final sequence preview (with add-ons)"),
            DT::dataTableOutput("addon_preview_tbl")
          )
        )
      )
    )
  )
  
  server <- function(input, output, session) {
    rv <- shiny::reactiveValues(
      chains = {
        ch <- st2$chains
        if (length(ch) < n_chains0) {
          for (i in seq_len(n_chains0 - length(ch))) ch[[length(ch) + 1L]] <- character(0)
        }
        ch
      },
      chain_names = NULL,
      addons = NULL,
      unassigned = init_unassigned,
      current_pep = if (nrow(init_unassigned)) init_unassigned$Peptide[1] else NA_character_,
      selected_chain_id = if (length(st2$chains)) 1L else NA_integer_,
      gene_constraints = list()
    )
    
    # IMPORTANT: in Shiny >= 1.8, reading rv$... must happen inside reactive consumer
    .ensure_chain_meta <- function() {
      n <- length(rv$chains)
      
      cn_old <- rv$chain_names
      cn_new <- .init_chain_names(n, cn_old)
      if (!identical(cn_old, cn_new)) rv$chain_names <- cn_new
      
      ad_old <- rv$addons
      ad_new <- .init_addons(n, ad_old)
      if (!identical(ad_old, ad_new)) rv$addons <- ad_new
      
      invisible(NULL)
    }
    
    # ✅ run meta-sync inside observe (reactive consumer)
    shiny::observe({
      .ensure_chain_meta()
    })
    
    max_chain_AA_val <- shiny::reactive({
      v <- suppressWarnings(as.numeric(input$max_chain_AA))
      if (length(v) != 1L || is.na(v) || !is.finite(v) || v < 1) return(Inf)
      v
    })
    
    output$restrict_chains_ui <- shiny::renderUI({
      ch_ids <- seq_len(max(1L, length(rv$chains)))
      shiny::selectizeInput(
        "restrict_chains",
        "Allowed chains (IDs)",
        choices = stats::setNames(as.character(ch_ids), as.character(ch_ids)),
        multiple = TRUE,
        options = list(placeholder = "e.g., select 1 and 2")
      )
    })
    
    output$constraints_tbl <- DT::renderDataTable({
      cons <- rv$gene_constraints
      if (is.null(cons) || !length(cons)) {
        df <- data.frame(message = "No active gene constraints.")
        return(DT::datatable(df, rownames = FALSE, options = list(dom = "t")))
      }
      genes <- names(cons)
      allowed <- vapply(cons, function(v) {
        v <- suppressWarnings(as.integer(v))
        v <- v[!is.na(v) & is.finite(v) & v >= 1]
        if (!length(v)) "" else paste(sort(unique(v)), collapse = ",")
      }, character(1))
      df <- data.frame(gene = genes, allowed_chains = allowed, stringsAsFactors = FALSE)
      DT::datatable(df, rownames = FALSE, selection = "single", options = list(pageLength = 8, scrollX = TRUE))
    })
    
    output$chains_tbl <- DT::renderDataTable({
      df <- .chain_summary(rv$chains, rv$chain_names, rv$addons)
      DT::datatable(df, rownames = FALSE, selection = "single", options = list(pageLength = 10, scrollX = TRUE))
    })
    
    shiny::observeEvent(input$chains_tbl_rows_selected, {
      sel <- input$chains_tbl_rows_selected
      if (length(sel) == 1) rv$selected_chain_id <- as.integer(sel)
    })
    
    output$unassigned_tbl <- DT::renderDataTable({
      df <- .ensure_unassigned_df(rv$unassigned)
      if ("source_proteins" %in% names(df)) names(df)[names(df) == "source_proteins"] <- "gene"
      DT::datatable(df, rownames = FALSE, selection = "single", options = list(pageLength = 12, scrollX = TRUE))
    })
    
    shiny::observeEvent(input$unassigned_tbl_rows_selected, {
      sel <- input$unassigned_tbl_rows_selected
      df <- .ensure_unassigned_df(rv$unassigned)
      if (length(sel) == 1 && nrow(df) >= sel) rv$current_pep <- df$Peptide[sel]
    })
    
    output$current_pep_ui <- shiny::renderUI({
      shiny::helpText(sprintf("Current peptide: %s", ifelse(is.na(rv$current_pep), "(none)", rv$current_pep)))
    })
    
    output$chain_detail_tbl <- DT::renderDataTable({
      df <- .chains_detail_df(rv$chains, src_map, selected_gene = input$gene_filter)
      dt <- DT::datatable(
        df,
        rownames = FALSE,
        options = list(
          pageLength = 15,
          scrollX = TRUE,
          columnDefs = list(list(visible = FALSE, targets = which(names(df) == "highlight") - 1))
        )
      )
      DT::formatStyle(
        dt,
        "highlight",
        target = "row",
        backgroundColor = DT::styleEqual(c(TRUE), c("#FFF2CC"))
      )
    })
    
    output$gene_dist_tbl <- DT::renderDataTable({
      df <- .gene_distribution_df(rv$chains, rv$unassigned, src_map)
      if (!nrow(df)) {
        msg <- data.frame(message = "No gene annotations available to summarize.")
        return(DT::datatable(msg, rownames = FALSE, options = list(dom = "t")))
      }
      dt <- DT::datatable(df, rownames = FALSE, options = list(pageLength = 15, scrollX = TRUE))
      sel <- as.character(input$gene_filter)
      if (!is.na(sel)) sel <- trimws(sel)
      if (!is.na(sel) && nzchar(sel)) {
        dt <- DT::formatStyle(
          dt,
          "gene",
          target = "row",
          backgroundColor = DT::styleEqual(c(sel), c("#FFF2CC"))
        )
      }
      dt
    })
    
    # ---- Add-ons tab outputs + actions --------------------------------------
    
    output$addon_chain_ui <- shiny::renderUI({
      n <- length(rv$chains)
      choices <- stats::setNames(
        as.character(seq_len(n)),
        paste0(seq_len(n), ": ", rv$chain_names)
      )
      shiny::selectizeInput(
        "addon_chain_id",
        "Target chain",
        choices = choices,
        selected = if (is.finite(rv$selected_chain_id)) as.character(rv$selected_chain_id) else if (n) "1" else "",
        options = list(placeholder = "Select chain...")
      )
    })
    
    .apply_addons_to_ids <- function(cids) {
      cids <- suppressWarnings(as.integer(cids))
      cids <- cids[is.finite(cids) & cids >= 1 & cids <= length(rv$chains)]
      if (!length(cids)) {
        shiny::showNotification("No valid target chain ID.", type = "warning")
        return(invisible(NULL))
      }
      
      any_on <- isTRUE(input$addon_head_on) || isTRUE(input$addon_tail_on) || isTRUE(input$addon_junc_on)
      if (!isTRUE(any_on)) {
        shiny::showNotification("Please tick at least one of: Head / Tail / Between junctions.", type = "warning")
        return(invisible(NULL))
      }
      
      head_seq <- .clean_pep(input$addon_head_seq)
      tail_seq <- .clean_pep(input$addon_tail_seq)
      junc_seq <- .clean_pep(input$addon_junc_seq)
      
      for (cid in cids) {
        ad <- rv$addons[[cid]]
        if (!is.list(ad)) ad <- list(head = "", tail = "", junction = "")
        
        if (isTRUE(input$addon_head_on)) ad$head <- head_seq
        if (isTRUE(input$addon_tail_on)) ad$tail <- tail_seq
        if (isTRUE(input$addon_junc_on)) ad$junction <- junc_seq
        
        rv$addons[[cid]] <- ad
      }
      
      shiny::showNotification(
        sprintf("Add-ons updated for %d chain(s).", length(cids)),
        type = "message"
      )
      invisible(NULL)
    }
    
    shiny::observeEvent(input$apply_addon_chain_btn, {
      cid <- suppressWarnings(as.integer(input$addon_chain_id))
      if (!is.finite(cid)) cid <- suppressWarnings(as.integer(rv$selected_chain_id))
      .apply_addons_to_ids(cid)
    })
    
    shiny::observeEvent(input$apply_addon_all_btn, {
      .apply_addons_to_ids(seq_along(rv$chains))
    })
    
    shiny::observeEvent(input$apply_chain_name_btn, {
      cid <- suppressWarnings(as.integer(input$addon_chain_id))
      if (!is.finite(cid)) cid <- suppressWarnings(as.integer(rv$selected_chain_id))
      if (!is.finite(cid) || cid < 1 || cid > length(rv$chains)) {
        shiny::showNotification("No valid target chain to rename.", type = "warning")
        return()
      }
      nm <- trimws(as.character(input$chain_custom_name))
      if (is.na(nm) || !nzchar(nm)) {
        shiny::showNotification("Please input a non-empty chain name.", type = "warning")
        return()
      }
      rv$chain_names[[cid]] <- nm
      shiny::showNotification(sprintf("Renamed chain %d to: %s", cid, nm), type = "message")
    })
    
    output$addon_preview_tbl <- DT::renderDataTable({
      rows <- lapply(seq_along(rv$chains), function(i) {
        ch <- rv$chains[[i]]
        ch <- ch[!is.na(ch) & nzchar(ch)]
        ad <- rv$addons[[i]]
        if (!is.list(ad)) ad <- list(head = "", tail = "", junction = "")
        
        final_seq <- .chain_sequence_with_addons(
          ch,
          addon_head = ad$head,
          addon_junction = ad$junction,
          addon_tail = ad$tail
        )
        data.frame(
          chain_id = i,
          chain_name = rv$chain_names[[i]],
          n_peptides = length(ch),
          addon_head = .clean_pep(ad$head),
          addon_junction = .clean_pep(ad$junction),
          addon_tail = .clean_pep(ad$tail),
          final_AA = nchar(final_seq),
          final_sequence = final_seq,
          stringsAsFactors = FALSE
        )
      })
      df <- if (length(rows)) do.call(rbind, rows) else data.frame()
      DT::datatable(df, rownames = FALSE, options = list(pageLength = 12, scrollX = TRUE))
    })
    
    # ---- Detach actions ------------------------------------------------------
    
    .detach_n <- function(from_head = TRUE) {
      cid <- suppressWarnings(as.integer(rv$selected_chain_id))
      if (length(cid) != 1L || is.na(cid) || !is.finite(cid) || cid < 1 || cid > length(rv$chains)) return(invisible(NULL))
      n <- suppressWarnings(as.integer(input$detach_n))
      if (length(n) != 1L || is.na(n) || !is.finite(n) || n < 1) n <- 1L
      
      ch <- rv$chains[[cid]]
      ch <- ch[!is.na(ch) & nzchar(ch)]
      if (!length(ch)) return(invisible(NULL))
      
      n <- min(n, length(ch))
      if (from_head) {
        removed <- ch[seq_len(n)]
        kept <- if (n < length(ch)) ch[(n + 1L):length(ch)] else character(0)
      } else {
        removed <- ch[(length(ch) - n + 1L):length(ch)]
        kept <- if (n < length(ch)) ch[seq_len(length(ch) - n)] else character(0)
      }
      
      rv$chains[[cid]] <- kept
      
      # only add peptides that are not used elsewhere AND are from the peptide universe
      used_now <- unique(unlist(rv$chains))
      used_now <- used_now[!is.na(used_now) & nzchar(used_now)]
      to_add <- setdiff(unique(removed), unique(used_now))
      to_add <- intersect(to_add, pep_universe_vec)
      if (length(to_add)) rv$unassigned <- .add_peptides_to_unassigned(rv$unassigned, to_add, src_map)
      
      invisible(NULL)
    }
    
    shiny::observeEvent(input$detach_head_btn, { .detach_n(from_head = TRUE) })
    shiny::observeEvent(input$detach_tail_btn, { .detach_n(from_head = FALSE) })
    
    # ---- Manual add ----------------------------------------------------------
    
    .place_current <- function(prepend = FALSE) {
      p <- rv$current_pep
      if (is.na(p) || !nzchar(p)) return(invisible(NULL))
      p <- toupper(trimws(as.character(p)))
      
      dfu <- .ensure_unassigned_df(rv$unassigned)
      if (!nrow(dfu) || !(p %in% dfu$Peptide)) return(invisible(NULL))
      
      cid <- suppressWarnings(as.integer(rv$selected_chain_id))
      if (length(cid) != 1L || is.na(cid) || !is.finite(cid) || cid < 1) cid <- 1L
      if (cid > length(rv$chains)) {
        for (i in seq_len(cid - length(rv$chains))) {
          rv$chains[[length(rv$chains) + 1L]] <- character(0)
        }
      }
      
      mx <- max_chain_AA_val()
      ch <- rv$chains[[cid]]
      ch <- ch[!is.na(ch) & nzchar(ch)]
      
      if (is.finite(mx) && (sum(nchar(ch)) + nchar(p)) > mx) {
        shiny::showNotification("Chain is full under current max_chain_AA.", type = "warning")
        return(invisible(NULL))
      }
      
      # constraint check
      cons <- rv$gene_constraints
      allowed <- .allowed_chains_for_peptide(p, cons)
      if (!is.null(allowed) && length(allowed) && !(cid %in% allowed)) {
        shiny::showNotification("This peptide is constrained to different chain(s).", type = "warning")
        return(invisible(NULL))
      }
      
      rv$chains[[cid]] <- if (isTRUE(prepend)) c(p, ch) else c(ch, p)
      rv$unassigned <- dfu[dfu$Peptide != p, , drop = FALSE]
      rv$current_pep <- if (nrow(rv$unassigned)) rv$unassigned$Peptide[1] else NA_character_
      invisible(NULL)
    }
    
    shiny::observeEvent(input$prepend_btn, { .place_current(prepend = TRUE) })
    shiny::observeEvent(input$append_btn, { .place_current(prepend = FALSE) })
    
    shiny::observeEvent(input$new_chain_btn, {
      rv$chains[[length(rv$chains) + 1L]] <- character(0)
      shiny::showNotification(sprintf("Added empty chain %d", length(rv$chains)), type = "message")
    })
    
    # ---- Constraints ---------------------------------------------------------
    
    shiny::observeEvent(input$add_rule_btn, {
      genes <- input$restrict_gene
      genes <- genes[!is.na(genes) & nzchar(genes) & genes != "(none)"]
      if (!length(genes)) {
        shiny::showNotification("Select at least one gene.", type = "warning")
        return()
      }
      
      allowed <- input$restrict_chains
      allowed <- suppressWarnings(as.integer(allowed))
      allowed <- allowed[!is.na(allowed) & is.finite(allowed) & allowed >= 1]
      if (!length(allowed)) {
        shiny::showNotification("Select allowed chain IDs.", type = "warning")
        return()
      }
      
      cons <- rv$gene_constraints
      for (g in genes) {
        g <- as.character(g)
        if (!nzchar(g) || g == "(none)") next
        prev <- cons[[g]]
        if (is.null(prev)) {
          cons[[g]] <- sort(unique(allowed))
        } else {
          prev <- suppressWarnings(as.integer(prev))
          prev <- prev[!is.na(prev) & is.finite(prev) & prev >= 1]
          cons[[g]] <- sort(unique(intersect(prev, allowed)))
        }
      }
      rv$gene_constraints <- cons
      shiny::showNotification(sprintf("Updated constraints for %d gene(s).", length(genes)), type = "message")
    })
    
    shiny::observeEvent(input$clear_rules_btn, {
      rv$gene_constraints <- list()
      shiny::showNotification("Cleared all constraints.", type = "message")
    })
    
    shiny::observeEvent(input$rebuild_btn, {
      cons <- rv$gene_constraints
      mx <- max_chain_AA_val()
      if (!is.finite(mx) || mx < 1) mx <- Inf
      
      mx_allowed <- 0L
      if (!is.null(cons) && length(cons)) {
        vv <- suppressWarnings(as.integer(unlist(cons, use.names = FALSE)))
        vv <- vv[!is.na(vv) & is.finite(vv) & vv >= 1]
        if (length(vv)) mx_allowed <- max(vv)
      }
      n_ch <- max(1L, length(rv$chains), n_chains0, mx_allowed)
      
      rb <- .rebuild_under_constraints(pep_universe_vec, cons, n_chains = n_ch, max_chain_AA = mx)
      rv$chains <- rb$chains
      rv$unassigned <- .add_peptides_to_unassigned(data.frame(Peptide = character(0), stringsAsFactors = FALSE), rb$unassigned, src_map)
      rv$current_pep <- if (nrow(rv$unassigned)) rv$unassigned$Peptide[1] else NA_character_
      
      shiny::showNotification("Rebuilt chains under constraints.", type = "message")
    })
    
    # ---- Download ------------------------------------------------------------
    
    output$download_zip <- shiny::downloadHandler(
      filename = function() {
        paste0(out_base, ".zip")
      },
      content = function(file) {
        tmpdir <- tempfile("manual_asm_classI_nonetchop_")
        dir.create(tmpdir)
        
        chain_out <- .chain_summary(rv$chains, rv$chain_names, rv$addons)
        
        chain_out$chain_sequence <- vapply(seq_along(rv$chains), function(i) {
          ch <- rv$chains[[i]]
          ch <- ch[!is.na(ch) & nzchar(ch)]
          paste0(ch, collapse = "")
        }, character(1))
        
        chain_out$final_sequence <- vapply(seq_along(rv$chains), function(i) {
          ch <- rv$chains[[i]]
          ch <- ch[!is.na(ch) & nzchar(ch)]
          ad <- rv$addons[[i]]
          if (!is.list(ad)) ad <- list(head = "", tail = "", junction = "")
          .chain_sequence_with_addons(ch, ad$head, ad$junction, ad$tail)
        }, character(1))
        
        edge_out <- .edges_from_chains_na(rv$chains)
        unassigned_out <- .ensure_unassigned_df(rv$unassigned)
        
        chain_tsv <- file.path(tmpdir, paste0(out_base, "_chains.tsv"))
        edge_tsv  <- file.path(tmpdir, paste0(out_base, "_edges.tsv"))
        unassigned_tsv <- file.path(tmpdir, paste0(out_base, "_unassigned_peptides.tsv"))
        state_rds <- file.path(tmpdir, paste0(out_base, "_manual_state.rds"))
        
        readr::write_tsv(chain_out, chain_tsv)
        readr::write_tsv(edge_out, edge_tsv)
        readr::write_tsv(unassigned_out, unassigned_tsv)
        
        saveRDS(
          list(
            stage2_state_rds = stage2_state_rds,
            use_netchop = FALSE,
            chains = rv$chains,
            chain_names = rv$chain_names,
            addons = rv$addons,
            chain_table = chain_out,
            edge_table = edge_out,
            unassigned_table = unassigned_out,
            gene_constraints = rv$gene_constraints
          ),
          state_rds
        )
        
        old <- setwd(tmpdir)
        on.exit(setwd(old), add = TRUE)
        utils::zip(zipfile = file, files = basename(c(chain_tsv, edge_tsv, unassigned_tsv, state_rds)))
      }
    )
  }
  
  app <- shiny::shinyApp(ui = ui, server = server)
  shiny::runApp(app, launch.browser = isTRUE(launch_browser))
  invisible(NULL)
}

#' Launch the manual assembly Shiny UI (Class I; NetChop optional)
#'
#' @param stage2_state_rds Path returned by `res2$stage2_state_rds` from [classI_stage2()].
#' @param netchop_thr Override NetChop threshold; default uses the value stored in stage2 state.
#' @param out_base Output base name inside the downloaded zip.
#' @param launch_browser If TRUE, open in browser.
#' @param use_netchop If TRUE, run NetChop UI; if FALSE run no-NetChop UI; if NULL infer from Stage2 state.
#' @return Invisibly returns the final manual state as a list (also downloadable from the UI).
#' @export
classI_manual_assembly_ui <- function(stage2_state_rds,
                                      netchop_thr = NULL,
                                      out_base = "manual_assembly",
                                      launch_browser = TRUE,
                                      use_netchop = NULL) {
  if (!requireNamespace("shiny", quietly = TRUE)) stop("Package 'shiny' is required.")
  if (!requireNamespace("DT", quietly = TRUE)) stop("Package 'DT' is required.")
  if (!requireNamespace("readr", quietly = TRUE)) stop("Package 'readr' is required.")
  if (!requireNamespace("data.table", quietly = TRUE)) stop("Package 'data.table' is required.")
  if (!requireNamespace("stringr", quietly = TRUE)) stop("Package 'stringr' is required.")
  
  stopifnot(is.character(stage2_state_rds), length(stage2_state_rds) == 1, nzchar(stage2_state_rds))
  if (!file.exists(stage2_state_rds)) stop("stage2_state_rds does not exist: ", stage2_state_rds)
  
  st2 <- readRDS(stage2_state_rds)
  if (is.null(st2$chains) || !length(st2$chains)) stop("Stage2 state missing 'chains'.")
  if (is.null(st2$unassigned_table) || !is.data.frame(st2$unassigned_table)) {
    stop("Stage2 state missing 'unassigned_table'.")
  }
  
  # peptide -> source proteins map (upper-cased peptide key)
  src_map <- NULL
  if (!is.null(st2$peptide_sources) && is.data.frame(st2$peptide_sources)) {
    ps <- st2$peptide_sources
    if (all(c("Peptide", "source_proteins") %in% names(ps))) {
      src_map <- setNames(as.character(ps$source_proteins),
                          toupper(trimws(as.character(ps$Peptide))))
    }
  }
  
  init_unassigned <- .ensure_unassigned_df(st2$unassigned_table)
  
  pep_universe_vec <- if (!is.null(st2$pep_universe)) {
    u <- toupper(trimws(as.character(st2$pep_universe)))
    u <- u[!is.na(u) & nzchar(u)]
    sort(unique(u))
  } else {
    u <- unique(c(unlist(st2$chains),
                  init_unassigned$Peptide,
                  if (!is.null(src_map)) names(src_map) else character(0)))
    u <- toupper(trimws(as.character(u)))
    u <- u[!is.na(u) & nzchar(u)]
    sort(unique(u))
  }
  
  # infer mode if NULL
  if (is.null(use_netchop)) {
    if (!is.null(st2$use_netchop)) {
      use_netchop <- isTRUE(st2$use_netchop)
    } else {
      use_netchop <- is.data.frame(st2$edges_passing) &&
        ("netchop_score_boundary" %in% names(st2$edges_passing))
    }
  } else {
    use_netchop <- isTRUE(use_netchop)
  }
  
  # If no NetChop -> run simplified UI (defined elsewhere in this package)
  if (!isTRUE(use_netchop)) {
    return(.classI_manual_assembly_ui_no_netchop(
      stage2_state_rds = stage2_state_rds,
      st2 = st2,
      pep_universe_vec = pep_universe_vec,
      src_map = src_map,
      out_base = out_base,
      launch_browser = launch_browser
    ))
  }
  
  # ---- NetChop mode UI ----
  if (!requireNamespace("later", quietly = TRUE)) stop("Package 'later' is required for Boost in NetChop UI.")
  if (is.null(st2$edges_passing) || !is.data.frame(st2$edges_passing)) {
    stop("Stage2 state missing 'edges_passing' (required for NetChop UI).")
  }
  
  thr <- if (!is.null(netchop_thr)) suppressWarnings(as.numeric(netchop_thr)) else suppressWarnings(as.numeric(st2$netchop_thr))
  if (length(thr) != 1L || is.na(thr) || !is.finite(thr)) thr <- 0.5
  
  # Max total amino-acid length per chain
  default_max_chain_AA <- NA_real_
  for (nm in c("max_chain_AA", "max_chain_aa", "max_chain_AA_len", "max_chain_len", "max_total_AA", "max_total_aa")) {
    if (!is.null(st2[[nm]])) {
      v <- suppressWarnings(as.numeric(st2[[nm]]))
      if (length(v) == 1L && !is.na(v) && is.finite(v) && v >= 1) {
        default_max_chain_AA <- v
        break
      }
    }
  }
  if (length(default_max_chain_AA) != 1L || is.na(default_max_chain_AA) ||
      !is.finite(default_max_chain_AA) || default_max_chain_AA < 1) {
    default_max_chain_AA <- 100
  }
  
  total_universe <- if (!is.null(st2$pep_universe)) {
    u <- toupper(trimws(as.character(st2$pep_universe)))
    u <- u[!is.na(u) & nzchar(u)]
    length(unique(u))
  } else {
    NA_integer_
  }
  
  all_genes <- .all_genes_from_src_map(src_map)
  edges_lu <- .edge_lookup_max(st2$edges_passing)
  
  ui <- shiny::fluidPage(
    shiny::titlePanel("Manual assembly: edit chains + insert peptides (Class I, NetChop)"),
    shiny::tags$p(
      sprintf(
        "Threshold: netchop_score_boundary >= %.3f. You can (1) insert unassigned peptides into chains, (2) detach peptides from chain head/tail (they return to unassigned), (3) start a new chain, and (4) highlight peptides by gene.",
        thr
      )
    ),
    shiny::fluidRow(
      shiny::column(
        4,
        shiny::h4("Incorporation status"),
        shiny::uiOutput("inc_stats_ui"),
        shiny::hr(),
        shiny::h4("Current chains"),
        shiny::helpText("Tip: click a chain row to select it for editing (detach from head/tail)."),
        DT::dataTableOutput("chains_tbl"),
        shiny::fluidRow(
          shiny::column(6, shiny::numericInput("detach_n", "Detach N peptides", value = 1, min = 1, step = 1)),
          shiny::column(
            6,
            shiny::actionButton("detach_head_btn", "Detach from head", class = "btn-warning"),
            shiny::actionButton("detach_tail_btn", "Detach from tail", class = "btn-warning")
          )
        ),
        shiny::hr(),
        shiny::h4("Gene highlight"),
        shiny::selectizeInput(
          "gene_filter",
          "Select a gene (highlights chain positions)",
          choices = c("(none)" = "", stats::setNames(all_genes, all_genes)),
          selected = "",
          options = list(placeholder = "Type to search...")
        ),
        shiny::h4("Gene constraints"),
        shiny::helpText("Build one or more constraint rules (gene set → allowed chain IDs). Add multiple rules, then apply once. If Boost is enabled, the system will rebuild from scratch while respecting all active constraints and keep the solution with the most incorporated peptides."),
        shiny::selectizeInput(
          "restrict_gene",
          "Gene(s) for this rule",
          choices = c("(none)" = "", stats::setNames(all_genes, all_genes)),
          selected = character(0),
          multiple = TRUE,
          options = list(placeholder = "Type to search...")
        ),
        shiny::uiOutput("restrict_chains_ui"),
        shiny::fluidRow(
          shiny::column(6, shiny::actionButton("add_rule_btn", "Add rule to batch", class = "btn-info")),
          shiny::column(6, shiny::actionButton("remove_rule_btn", "Remove selected batch rule", class = "btn-secondary"))
        ),
        shiny::numericInput(
          "max_chain_AA",
          "Max chain AA length per chain (AA)",
          value = default_max_chain_AA,
          min = 1,
          step = 1
        ),
        shiny::helpText("Used for Boost rebuild and insertion suggestions; Stage2 often uses 100."),
        shiny::checkboxInput(
          "boost_after_apply",
          "Boost rebuild from scratch after applying batch constraints (maximize incorporated peptides)",
          value = FALSE
        ),
        shiny::fluidRow(
          shiny::column(6, shiny::actionButton("clear_batch_btn", "Clear batch", class = "btn-secondary")),
          shiny::column(6, shiny::actionButton("apply_batch_btn", "Apply batch constraints", class = "btn-danger"))
        ),
        shiny::fluidRow(
          shiny::column(6, shiny::actionButton("boost_rebuild_btn", "Boost rebuild now", class = "btn-primary")),
          shiny::column(6, shiny::actionButton("stop_boost_btn", "Stop boost", class = "btn-danger"))
        ),
        shiny::uiOutput("boost_status_ui"),
        shiny::h5("Pending batch rules"),
        DT::dataTableOutput("batch_tbl"),
        shiny::h5("Active constraints"),
        DT::dataTableOutput("constraints_tbl"),
        shiny::actionButton("clear_restrict_btn", "Clear active constraint(s) for selected gene(s)", class = "btn-secondary"),
        shiny::hr(),
        shiny::h4("Unassigned peptides"),
        shiny::helpText("Tip: click a row to set the current peptide."),
        DT::dataTableOutput("unassigned_tbl"),
        shiny::hr(),
        shiny::actionButton("skip_btn", "Skip current peptide"),
        shiny::actionButton("reset_skip_btn", "Show skipped again")
      ),
      shiny::column(
        8,
        shiny::tabsetPanel(
          id = "right_tabs_netchop",
          shiny::tabPanel(
            "Assembly",
            shiny::h4("Chain detail (peptide positions + gene)"),
            DT::dataTableOutput("chain_detail_tbl"),
            shiny::hr(),
            shiny::h4("Gene distribution across chains"),
            shiny::helpText("Lists each gene and which chain(s) currently contain its peptides (counts + total AA length across all peptides for that gene)."),
            DT::dataTableOutput("gene_dist_tbl"),
            shiny::hr(),
            shiny::h4("Insertion candidates for current peptide"),
            shiny::fluidRow(
              shiny::column(6, shiny::uiOutput("current_pep_ui")),
              shiny::column(6, shiny::actionButton("apply_btn", "Apply selected insertion", class = "btn-primary"))
            ),
            DT::dataTableOutput("ins_tbl"),
            shiny::hr(),
            shiny::downloadButton("download_zip", "Download manual assembly (zip)")
          ),
          shiny::tabPanel(
            "Add-ons",
            shiny::fluidRow(
              shiny::column(
                4,
                shiny::h4("Target chain + naming"),
                shiny::uiOutput("addon_chain_ui"),
                shiny::textInput("chain_custom_name", "Customized chain name", value = ""),
                shiny::actionButton("apply_chain_name_btn", "Apply name to chain", class = "btn-info"),
                shiny::hr(),
                shiny::h4("Insert add-on sequences"),
                shiny::helpText("Tick any combination of head / tail / between junctions."),
                shiny::fluidRow(
                  shiny::column(4, shiny::checkboxInput("addon_head_on", "Head", value = FALSE)),
                  shiny::column(8, shiny::textInput("addon_head_seq", "Head sequence", value = ""))
                ),
                shiny::fluidRow(
                  shiny::column(4, shiny::checkboxInput("addon_tail_on", "Tail", value = FALSE)),
                  shiny::column(8, shiny::textInput("addon_tail_seq", "Tail sequence", value = ""))
                ),
                shiny::fluidRow(
                  shiny::column(4, shiny::checkboxInput("addon_junc_on", "Between junctions", value = FALSE)),
                  shiny::column(8, shiny::textInput("addon_junc_seq", "Junction sequence", value = ""))
                ),
                shiny::fluidRow(
                  shiny::column(6, shiny::actionButton("apply_addon_chain_btn", "Apply to chain", class = "btn-primary")),
                  shiny::column(6, shiny::actionButton("apply_addon_all_btn", "Apply all", class = "btn-warning"))
                )
              ),
              shiny::column(
                8,
                shiny::h4("Final sequence preview (with add-ons)"),
                DT::dataTableOutput("addon_preview_tbl")
              )
            )
          )
        )
      )
    )
  )
  
  server <- function(input, output, session) {
    
    # ---- 兼容式 do.call：只传函数 formals 里存在的命名参数 -------------------
    .safe_do_call <- function(fn, args) {
      if (!is.function(fn)) stop("Target is not a function.")
      fml <- names(formals(fn))
      # 保留未命名参数（位置参数）以及在 formals 中出现的命名参数
      nm <- names(args)
      if (is.null(nm)) return(do.call(fn, args))
      keep <- vapply(nm, function(x) is.na(x) || x == "" || x %in% fml, logical(1))
      do.call(fn, args[keep])
    }
    
    rv <- shiny::reactiveValues(
      chains = st2$chains,
      chain_names = .init_chain_names(length(st2$chains), NULL),
      addons = .init_addons(length(st2$chains), NULL),
      unassigned = init_unassigned,
      skipped = character(0),
      current_pep = if (nrow(init_unassigned)) init_unassigned$Peptide[1] else NA_character_,
      selected_chain_id = if (!is.null(st2$chains) && length(st2$chains)) 1L else NA_integer_,
      gene_constraints = list(),
      pending_constraints = list()
    )
    
    .ensure_chain_meta <- function() {
      n <- length(rv$chains)
      
      cn_old <- rv$chain_names
      cn_new <- .ensure_chain_names(cn_old, n)
      if (!identical(cn_old, cn_new)) rv$chain_names <- cn_new
      
      ad_old <- rv$addons
      ad_new <- .init_addons(n, ad_old)
      if (!identical(ad_old, ad_new)) rv$addons <- ad_new
      
      invisible(NULL)
    }
    
    shiny::observe({
      .ensure_chain_meta()
    })
    
    
    # Boost state outside reactiveValues
    boost <- new.env(parent = emptyenv())
    boost$running <- FALSE
    boost$stop <- FALSE
    boost$session_ended <- FALSE
    boost$all_peps <- character(0)
    boost$idx <- 1L
    boost$n <- 0L
    boost$best <- NULL
    boost$progress <- NULL
    boost$cons_snapshot <- list()
    boost$seed_state <- NULL
    boost$seed_steps <- 0L
    boost$seed_chunk <- 1L
    boost$max_chain_AA <- Inf
    
    used_peptides_reactive <- shiny::reactive({
      u <- unique(unlist(rv$chains))
      u <- toupper(trimws(as.character(u)))
      u <- u[!is.na(u) & nzchar(u)]
      u <- intersect(u, pep_universe_vec) # avoid counting add-ons
      sort(unique(u))
    })
    
    max_chain_AA_val <- shiny::reactive({
      v <- suppressWarnings(as.numeric(input$max_chain_AA))
      if (length(v) != 1L || is.na(v) || !is.finite(v) || v < 1) return(Inf)
      v
    })
    
    session$onSessionEnded(function() {
      boost$session_ended <- TRUE
      boost$stop <- TRUE
      boost$running <- FALSE
      if (!is.null(boost$progress)) {
        try(boost$progress$close(), silent = TRUE)
        boost$progress <- NULL
      }
    })
    
    # --- Add-ons tab outputs + actions ----------------------------------------
    output$addon_chain_ui <- shiny::renderUI({
      .ensure_chain_meta()
      n <- length(rv$chains)
      if (!n) n <- 1L
      choices <- stats::setNames(
        as.character(seq_len(n)),
        paste0(seq_len(n), ": ", rv$chain_names[seq_len(n)])
      )
      shiny::selectizeInput(
        "addon_chain_id",
        "Target chain",
        choices = choices,
        selected = if (is.finite(rv$selected_chain_id)) as.character(rv$selected_chain_id) else if (n) "1" else "",
        options = list(placeholder = "Select chain...")
      )
    })
    
    .apply_addons_to_ids <- function(cids) {
      .ensure_chain_meta()
      cids <- suppressWarnings(as.integer(cids))
      cids <- cids[is.finite(cids) & cids >= 1 & cids <= length(rv$chains)]
      if (!length(cids)) {
        shiny::showNotification("No valid target chain ID.", type = "warning")
        return(invisible(NULL))
      }
      
      any_on <- isTRUE(input$addon_head_on) || isTRUE(input$addon_tail_on) || isTRUE(input$addon_junc_on)
      if (!isTRUE(any_on)) {
        shiny::showNotification("Please tick at least one of: Head / Tail / Between junctions.", type = "warning")
        return(invisible(NULL))
      }
      
      head_seq <- .clean_pep(input$addon_head_seq)
      tail_seq <- .clean_pep(input$addon_tail_seq)
      junc_seq <- .clean_pep(input$addon_junc_seq)
      
      for (cid in cids) {
        ad <- rv$addons[[cid]]
        if (!is.list(ad)) ad <- list(head = "", tail = "", junction = "")
        
        if (isTRUE(input$addon_head_on)) ad$head <- head_seq
        if (isTRUE(input$addon_tail_on)) ad$tail <- tail_seq
        if (isTRUE(input$addon_junc_on)) ad$junction <- junc_seq
        
        rv$addons[[cid]] <- ad
      }
      
      shiny::showNotification(sprintf("Add-ons updated for %d chain(s).", length(cids)), type = "message")
      invisible(NULL)
    }
    
    shiny::observeEvent(input$apply_addon_chain_btn, {
      cid <- suppressWarnings(as.integer(input$addon_chain_id))
      if (!is.finite(cid)) cid <- suppressWarnings(as.integer(rv$selected_chain_id))
      .apply_addons_to_ids(cid)
    })
    
    shiny::observeEvent(input$apply_addon_all_btn, {
      .apply_addons_to_ids(seq_along(rv$chains))
    })
    
    shiny::observeEvent(input$apply_chain_name_btn, {
      .ensure_chain_meta()
      cid <- suppressWarnings(as.integer(input$addon_chain_id))
      if (!is.finite(cid)) cid <- suppressWarnings(as.integer(rv$selected_chain_id))
      if (!is.finite(cid) || cid < 1 || cid > length(rv$chains)) {
        shiny::showNotification("No valid target chain to rename.", type = "warning")
        return()
      }
      nm <- trimws(as.character(input$chain_custom_name))
      if (is.na(nm) || !nzchar(nm)) {
        shiny::showNotification("Please input a non-empty chain name.", type = "warning")
        return()
      }
      rv$chain_names[[cid]] <- nm
      shiny::showNotification(sprintf("Renamed chain %d to: %s", cid, nm), type = "message")
    })
    
    output$addon_preview_tbl <- DT::renderDataTable({
      .ensure_chain_meta()
      rows <- lapply(seq_along(rv$chains), function(i) {
        ch <- rv$chains[[i]]
        ch <- ch[!is.na(ch) & nzchar(ch)]
        ad <- rv$addons[[i]]
        if (!is.list(ad)) ad <- list(head = "", tail = "", junction = "")
        final_seq <- .chain_sequence_with_addons(
          ch,
          addon_head = ad$head,
          addon_junction = ad$junction,
          addon_tail = ad$tail
        )
        data.frame(
          chain_id = i,
          chain_name = rv$chain_names[[i]],
          n_peptides = length(ch),
          addon_head = .clean_pep(ad$head),
          addon_junction = .clean_pep(ad$junction),
          addon_tail = .clean_pep(ad$tail),
          final_AA = nchar(final_seq),
          final_sequence = final_seq,
          stringsAsFactors = FALSE
        )
      })
      df <- if (length(rows)) do.call(rbind, rows) else data.frame()
      DT::datatable(df, rownames = FALSE, options = list(pageLength = 12, scrollX = TRUE))
    })
    
    # --- Gene constraints: force gene peptides into specific chains ------------
    output$restrict_chains_ui <- shiny::renderUI({
      ch_ids <- seq_len(max(1L, length(rv$chains)))
      shiny::selectizeInput(
        "restrict_chains",
        "Allowed chains (IDs)",
        choices = stats::setNames(as.character(ch_ids), as.character(ch_ids)),
        multiple = TRUE,
        options = list(placeholder = "e.g., select 1 and 2")
      )
    })
    
    output$constraints_tbl <- DT::renderDataTable({
      cons <- rv$gene_constraints
      if (is.null(cons) || !length(cons)) {
        df <- data.frame(message = "No active gene constraints.")
        return(DT::datatable(df, rownames = FALSE, options = list(dom = "t")))
      }
      genes <- names(cons)
      allowed <- vapply(cons, function(v) {
        v <- suppressWarnings(as.integer(v))
        v <- v[!is.na(v) & is.finite(v) & v >= 1]
        if (!length(v)) "" else paste(sort(unique(v)), collapse = ",")
      }, character(1))
      df <- data.frame(gene = genes, allowed_chains = allowed, stringsAsFactors = FALSE)
      DT::datatable(df, rownames = FALSE, selection = "single", options = list(pageLength = 8, scrollX = TRUE))
    })
    
    output$batch_tbl <- DT::renderDataTable({
      pc <- rv$pending_constraints
      if (is.null(pc) || !length(pc)) {
        df <- data.frame(message = "No pending batch rules. Add one or more rules above, then click Apply batch constraints.")
        return(DT::datatable(df, rownames = FALSE, options = list(dom = "t")))
      }
      df <- data.frame(
        rule_id = seq_along(pc),
        genes = vapply(pc, function(r) paste(r$genes, collapse = ","), character(1)),
        allowed_chains = vapply(pc, function(r) paste(r$allowed, collapse = ","), character(1)),
        stringsAsFactors = FALSE
      )
      DT::datatable(df, rownames = FALSE, selection = "single", options = list(pageLength = 8, scrollX = TRUE))
    })
    
    .allowed_chains_for_peptide <- function(pep) {
      pep <- toupper(trimws(as.character(pep)))
      if (is.na(pep) || !nzchar(pep)) return(NULL)
      cons <- rv$gene_constraints
      if (is.null(cons) || !length(cons)) return(NULL)
      
      genes <- .split_genes(.gene_for_peptide(pep, src_map))
      hit <- intersect(genes, names(cons))
      if (!length(hit)) return(NULL)
      
      allowed <- NULL
      for (g in hit) {
        v <- cons[[g]]
        v <- suppressWarnings(as.integer(v))
        v <- v[!is.na(v) & is.finite(v) & v >= 1]
        if (is.null(allowed)) allowed <- v else allowed <- intersect(allowed, v)
      }
      if (is.null(allowed)) allowed <- integer(0)
      sort(unique(allowed))
    }
    
    .enforce_gene_constraints <- function() {
      cons <- rv$gene_constraints
      if (is.null(cons) || !length(cons)) return(invisible(NULL))
      
      chains <- rv$chains
      unassigned <- .ensure_unassigned_df(rv$unassigned)
      
      # full peptide set (universe only)
      all_peps <- unique(c(unlist(chains), unassigned$Peptide))
      all_peps <- toupper(trimws(as.character(all_peps)))
      all_peps <- all_peps[!is.na(all_peps) & nzchar(all_peps)]
      all_peps <- intersect(all_peps, pep_universe_vec)
      if (!length(all_peps)) return(invisible(NULL))
      
      pep_allowed <- list()
      for (p in all_peps) {
        genes <- .split_genes(.gene_for_peptide(p, src_map))
        hit <- intersect(genes, names(cons))
        if (!length(hit)) next
        allowed <- NULL
        for (g in hit) {
          v <- cons[[g]]
          v <- suppressWarnings(as.integer(v))
          v <- v[is.finite(v) & v >= 1]
          if (is.null(allowed)) allowed <- v else allowed <- intersect(allowed, v)
        }
        if (is.null(allowed)) allowed <- integer(0)
        pep_allowed[[p]] <- sort(unique(allowed))
      }
      
      constrained <- names(pep_allowed)
      if (!length(constrained)) return(invisible(NULL))
      
      # ensure chains list long enough for max allowed id
      all_allowed_vals <- unlist(pep_allowed, use.names = FALSE)
      all_allowed_vals <- suppressWarnings(as.integer(all_allowed_vals))
      all_allowed_vals <- all_allowed_vals[is.finite(all_allowed_vals) & all_allowed_vals >= 1]
      if (length(all_allowed_vals)) {
        mx <- max(all_allowed_vals)
        if (mx > length(chains)) {
          for (k in seq_len(mx - length(chains))) chains[[length(chains) + 1L]] <- character(0)
        }
      }
      
      # remove constrained peptides from all chains -> back to unassigned
      removed <- character(0)
      for (cid in seq_along(chains)) {
        ch <- chains[[cid]]
        ch <- ch[!is.na(ch) & nzchar(ch)]
        if (!length(ch)) next
        rem <- ch[ch %in% constrained]
        if (length(rem)) removed <- c(removed, rem)
        chains[[cid]] <- ch[!(ch %in% constrained)]
      }
      
      if (length(removed)) {
        removed2 <- intersect(unique(removed), pep_universe_vec)
        if (length(removed2)) {
          unassigned <- .add_peptides_to_unassigned(unassigned, removed2, src_map)
          rv$skipped <- setdiff(rv$skipped, removed2)
        }
      }
      
      # place constrained peptides greedily using insertion options within allowed chains
      to_place <- constrained[vapply(pep_allowed, function(v) length(v) > 0, logical(1))]
      if (length(to_place)) {
        n_allowed <- vapply(pep_allowed[to_place], length, integer(1))
        lens <- nchar(to_place)
        to_place <- to_place[order(n_allowed, -lens)]
      }
      
      mx_chain <- max_chain_AA_val()
      
      for (p in to_place) {
        allowed <- pep_allowed[[p]]
        allowed <- suppressWarnings(as.integer(allowed))
        allowed <- allowed[is.finite(allowed) & allowed >= 1]
        if (!length(allowed)) next
        
        mx <- max(allowed)
        if (mx > length(chains)) {
          for (k in seq_len(mx - length(chains))) chains[[length(chains) + 1L]] <- character(0)
        }
        
        opts <- .insert_options_for_peptide(p, chains, edges_lu, thr, max_chain_AA = mx_chain)
        if (nrow(opts)) opts <- opts[opts$chain_id %in% allowed, , drop = FALSE]
        if (nrow(opts)) {
          chains <- .apply_insertion(chains, opts[1, , drop = FALSE])
          unassigned <- unassigned[unassigned$Peptide != p, , drop = FALSE]
          next
        }
        
        empty_allowed <- allowed[vapply(allowed, function(cid) {
          ch <- chains[[cid]]
          ch <- ch[!is.na(ch) & nzchar(ch)]
          length(ch) == 0
        }, logical(1))]
        
        if (length(empty_allowed)) {
          cid <- min(empty_allowed)
          if (!is.finite(mx_chain) || nchar(p) <= mx_chain) {
            chains[[cid]] <- p
            unassigned <- unassigned[unassigned$Peptide != p, , drop = FALSE]
          }
        }
      }
      
      rv$chains <- chains
      rv$unassigned <- unassigned
      .ensure_chain_meta()
      
      cp <- rv$current_pep
      if (!is.na(cp) && nzchar(cp)) {
        if (!cp %in% rv$unassigned$Peptide) {
          rv$current_pep <- if (nrow(rv$unassigned)) rv$unassigned$Peptide[1] else NA_character_
        }
      } else {
        rv$current_pep <- if (nrow(rv$unassigned)) rv$unassigned$Peptide[1] else NA_character_
      }
      
      invisible(NULL)
    }
    
    # --------------------- Boost rebuild (keeps original logic) ----------------
    .boost_rebuild_from_scratch <- function() {
      if (isTRUE(boost$running)) {
        shiny::showNotification("Boost is already running. Press 'Stop boost' to stop and keep the best solution so far.", type = "warning")
        return(invisible(NULL))
      }
      
      all_peps <- pep_universe_vec
      all_peps <- toupper(trimws(as.character(all_peps)))
      all_peps <- all_peps[!is.na(all_peps) & nzchar(all_peps)]
      all_peps <- sort(unique(all_peps))
      if (!length(all_peps)) return(invisible(NULL))
      
      max_chain_AA_snap <- max_chain_AA_val()
      if (!is.finite(max_chain_AA_snap) || max_chain_AA_snap < 1) max_chain_AA_snap <- Inf
      boost$max_chain_AA <- max_chain_AA_snap
      
      cons <- rv$gene_constraints
      boost$cons_snapshot <- cons
      
      .allowed_for_pep_cons <- function(pep) {
        pep <- toupper(trimws(as.character(pep)))
        if (is.na(pep) || !nzchar(pep)) return(NULL)
        if (is.null(cons) || !length(cons)) return(NULL)
        genes <- .split_genes(.gene_for_peptide(pep, src_map))
        hit <- intersect(genes, names(cons))
        if (!length(hit)) return(NULL)
        allowed <- NULL
        for (g in hit) {
          v <- cons[[g]]
          v <- suppressWarnings(as.integer(v))
          v <- v[is.finite(v) & v >= 1]
          if (is.null(allowed)) allowed <- v else allowed <- intersect(allowed, v)
        }
        if (is.null(allowed)) allowed <- integer(0)
        sort(unique(allowed))
      }
      
      mx_allowed <- 0L
      if (!is.null(cons) && length(cons)) {
        vv <- suppressWarnings(as.integer(unlist(cons, use.names = FALSE)))
        vv <- vv[is.finite(vv) & vv >= 1]
        if (length(vv)) mx_allowed <- max(vv)
      }
      n_chains <- max(1L, length(rv$chains), mx_allowed)
      
      .score_solution <- function(chains) {
        used <- unique(unlist(chains))
        used <- used[!is.na(used) & nzchar(used)]
        used <- intersect(used, pep_universe_vec)
        score_sum <- sum(vapply(chains, function(ch) .chain_score_sum(ch, edges_lu), numeric(1)), na.rm = TRUE)
        list(chains = chains, used = unique(used), used_n = length(unique(used)), score_sum = score_sum)
      }
      
      .init_seed_state <- function(seed) {
        chains <- vector("list", n_chains)
        for (i in seq_len(n_chains)) chains[[i]] <- character(0)
        
        a_seed <- .allowed_for_pep_cons(seed)
        if (is.finite(max_chain_AA_snap) && nchar(seed) > max_chain_AA_snap) {
          return(list(
            seed = seed, chains = chains, remaining = setdiff(all_peps, seed),
            phase = "done", scan_idx = 1L,
            best_score = -Inf, best_mean = -Inf, best_sum = -Inf,
            best_pep = NA_character_, best_opt = NULL,
            empty_ids = integer(0),
            cand = NA_character_, cand_chain = NA_integer_,
            best_rank = Inf, best_len = -Inf
          ))
        }
        
        if (!is.null(a_seed) && !length(a_seed)) {
          return(list(
            seed = seed, chains = chains, remaining = setdiff(all_peps, seed),
            phase = "done", scan_idx = 1L,
            best_score = -Inf, best_mean = -Inf, best_sum = -Inf,
            best_pep = NA_character_, best_opt = NULL,
            empty_ids = integer(0),
            cand = NA_character_, cand_chain = NA_integer_,
            best_rank = Inf, best_len = -Inf
          ))
        }
        
        seed_cid <- if (is.null(a_seed)) 1L else min(a_seed)
        if (seed_cid > length(chains)) {
          for (k in seq_len(seed_cid - length(chains))) chains[[length(chains) + 1L]] <- character(0)
        }
        chains[[seed_cid]] <- seed
        
        list(
          seed = seed,
          chains = chains,
          remaining = all_peps[all_peps != seed],
          phase = "search",
          scan_idx = 1L,
          best_score = -Inf,
          best_mean = -Inf,
          best_sum = -Inf,
          best_pep = NA_character_,
          best_opt = NULL,
          empty_ids = integer(0),
          cand = NA_character_,
          cand_chain = NA_integer_,
          best_rank = Inf,
          best_len = -Inf
        )
      }
      
      .reset_search <- function(st) {
        st$phase <- "search"
        st$scan_idx <- 1L
        st$best_score <- -Inf
        st$best_mean <- -Inf
        st$best_sum <- -Inf
        st$best_pep <- NA_character_
        st$best_opt <- NULL
        st
      }
      
      .reset_seed_empty <- function(st) {
        st$phase <- "seed_empty"
        st$scan_idx <- 1L
        st$empty_ids <- which(vapply(st$chains, function(ch) {
          ch <- ch[!is.na(ch) & nzchar(ch)]
          length(ch) == 0
        }, logical(1)))
        st$cand <- NA_character_
        st$cand_chain <- NA_integer_
        st$best_rank <- Inf
        st$best_len <- -Inf
        st
      }
      
      .seed_step <- function(st, chunk = 5L) {
        if (is.null(st) || is.null(st$chains)) return(list(st = st, finished = TRUE))
        if (identical(st$phase, "done")) return(list(st = st, finished = TRUE))
        if (!length(st$remaining)) {
          st$phase <- "done"
          return(list(st = st, finished = TRUE))
        }
        
        rem <- st$remaining
        
        if (identical(st$phase, "search")) {
          from <- as.integer(st$scan_idx)
          if (!is.finite(from) || from < 1L) from <- 1L
          to <- min(length(rem), from + as.integer(chunk) - 1L)
          
          if (from <= to) {
            for (i in seq.int(from, to)) {
              p <- rem[[i]]
              if (is.finite(max_chain_AA_snap) && nchar(p) > max_chain_AA_snap) next
              ap <- .allowed_for_pep_cons(p)
              if (!is.null(ap) && !length(ap)) next
              
              opts <- .insert_options_for_peptide(p, st$chains, edges_lu, thr, max_chain_AA = max_chain_AA_snap)
              if (nrow(opts) && !is.null(ap)) {
                opts <- opts[opts$chain_id %in% ap, , drop = FALSE]
              }
              if (!nrow(opts)) next
              o1 <- opts[1, , drop = FALSE]
              
              smin <- o1$score_min[[1]]
              smean <- o1$score_mean[[1]]
              ssum <- o1$score_sum[[1]]
              if (!is.finite(smin)) smin <- -Inf
              if (!is.finite(smean)) smean <- -Inf
              if (!is.finite(ssum)) ssum <- -Inf
              
              if (smin > st$best_score ||
                  (smin == st$best_score &&
                   (smean > st$best_mean ||
                    (smean == st$best_mean && ssum > st$best_sum)))) {
                st$best_score <- smin
                st$best_mean <- smean
                st$best_sum <- ssum
                st$best_pep <- p
                st$best_opt <- o1
              }
            }
          }
          
          st$scan_idx <- to + 1L
          
          if (st$scan_idx > length(rem)) {
            if (!is.null(st$best_opt)) {
              st$chains <- .apply_insertion(st$chains, st$best_opt)
              st$remaining <- rem[rem != st$best_pep]
              st <- .reset_search(st)
              return(list(st = st, finished = FALSE))
            }
            
            st <- .reset_seed_empty(st)
            if (!length(st$empty_ids)) {
              st$phase <- "done"
              return(list(st = st, finished = TRUE))
            }
            return(list(st = st, finished = FALSE))
          }
          
          return(list(st = st, finished = FALSE))
        }
        
        if (identical(st$phase, "seed_empty")) {
          empty_ids <- st$empty_ids
          if (!length(empty_ids)) {
            st$phase <- "done"
            return(list(st = st, finished = TRUE))
          }
          
          from <- as.integer(st$scan_idx)
          if (!is.finite(from) || from < 1L) from <- 1L
          to <- min(length(rem), from + as.integer(chunk) - 1L)
          
          if (from <= to) {
            for (i in seq.int(from, to)) {
              p <- rem[[i]]
              if (is.finite(max_chain_AA_snap) && nchar(p) > max_chain_AA_snap) next
              ap <- .allowed_for_pep_cons(p)
              if (!is.null(ap) && !length(ap)) next
              
              possible <- if (is.null(ap)) empty_ids else intersect(empty_ids, ap)
              if (!length(possible)) next
              
              rank <- if (is.null(ap)) 999L else length(ap)
              lp <- nchar(p)
              
              if (rank < st$best_rank ||
                  (rank == st$best_rank &&
                   (lp > st$best_len || (lp == st$best_len && (is.na(st$cand) || p < st$cand))))) {
                st$best_rank <- rank
                st$best_len <- lp
                st$cand <- p
                st$cand_chain <- min(possible)
              }
            }
          }
          
          st$scan_idx <- to + 1L
          
          if (st$scan_idx > length(rem)) {
            if (!is.na(st$cand) && is.finite(st$cand_chain)) {
              st$chains[[as.integer(st$cand_chain)]] <- st$cand
              st$remaining <- rem[rem != st$cand]
              st <- .reset_search(st)
              return(list(st = st, finished = FALSE))
            }
            
            st$phase <- "done"
            return(list(st = st, finished = TRUE))
          }
          
          return(list(st = st, finished = FALSE))
        }
        
        st$phase <- "done"
        list(st = st, finished = TRUE)
      }
      
      .commit_best_solution <- function(best_solution) {
        if (is.null(best_solution)) return(FALSE)
        rv$chains <- best_solution$chains
        .ensure_chain_meta()
        
        used <- unique(unlist(rv$chains))
        used <- used[!is.na(used) & nzchar(used)]
        used <- intersect(used, pep_universe_vec)
        unused <- setdiff(all_peps, used)
        
        rv$unassigned <- data.frame(
          Peptide = unused,
          pep_len = nchar(unused),
          source_proteins = vapply(unused, .gene_for_peptide, character(1), src_map = src_map),
          stringsAsFactors = FALSE
        )
        rv$unassigned <- rv$unassigned[order(rv$unassigned$Peptide), , drop = FALSE]
        rownames(rv$unassigned) <- NULL
        
        rv$skipped <- character(0)
        rv$current_pep <- if (nrow(rv$unassigned)) rv$unassigned$Peptide[[1]] else NA_character_
        rv$selected_chain_id <- if (length(rv$chains)) 1L else NA_integer_
        TRUE
      }
      
      boost$running <- TRUE
      boost$stop <- FALSE
      boost$session_ended <- FALSE
      boost$all_peps <- all_peps
      boost$idx <- 1L
      boost$n <- length(all_peps)
      boost$best <- NULL
      
      if (!is.null(boost$progress)) {
        try(boost$progress$close(), silent = TRUE)
        boost$progress <- NULL
      }
      boost$progress <- shiny::Progress$new(session, min = 0, max = length(all_peps))
      boost$progress$set(
        message = "Boost rebuilding from scratch (maximize incorporation)",
        value = 0,
        detail = sprintf("seed %d/%d", 0, length(all_peps))
      )
      
      .finalize_boost <- function(stop_requested = FALSE) {
        if (!is.null(boost$progress)) {
          try(boost$progress$close(), silent = TRUE)
          boost$progress <- NULL
        }
        boost$running <- FALSE
        boost$stop <- FALSE
        
        best <- boost$best
        if (!is.null(best)) {
          shiny::withReactiveDomain(session, {
            shiny::isolate({
              .commit_best_solution(best)
            })
          })
          shiny::showNotification(
            if (stop_requested) "Boost stopped — using best solution found so far." else "Boost completed — best solution applied.",
            type = "message",
            session = session
          )
        } else {
          shiny::showNotification("Boost stopped before any seed was evaluated — keeping current assembly.", type = "warning", session = session)
        }
        invisible(NULL)
      }
      
      .update_best <- function(r) {
        if (is.null(r) || is.null(r$used_n) || is.null(r$score_sum)) return(invisible(NULL))
        if (is.null(boost$best) || r$used_n > boost$best$used_n ||
            (r$used_n == boost$best$used_n && r$score_sum > boost$best$score_sum)) {
          boost$best <- r
        }
        invisible(NULL)
      }
      
      .complete_seed <- function(st) {
        if (is.null(st) || is.null(st$chains)) return(invisible(NULL))
        r <- .score_solution(st$chains)
        .update_best(r)
        boost$idx <- boost$idx + 1L
        boost$seed_state <- NULL
        boost$seed_steps <- 0L
        
        if (!is.null(boost$progress)) {
          try(boost$progress$set(
            value = boost$idx - 1L,
            detail = sprintf("seed %d/%d", boost$idx - 1L, boost$n)
          ), silent = TRUE)
        }
        invisible(NULL)
      }
      
      boost$seed_state <- NULL
      boost$seed_steps <- 0L
      boost$seed_chunk <- 1L
      
      step_runner <- NULL
      step_runner <- function() {
        if (isTRUE(boost$session_ended)) return(invisible(NULL))
        if (!isTRUE(boost$running)) return(invisible(NULL))
        
        if (isTRUE(boost$stop)) {
          if (!is.null(boost$seed_state) && !is.null(boost$seed_state$chains)) {
            try(.update_best(.score_solution(boost$seed_state$chains)), silent = TRUE)
          }
          .finalize_boost(stop_requested = TRUE)
          return(invisible(NULL))
        }
        
        if (boost$idx > boost$n) {
          .finalize_boost(stop_requested = FALSE)
          return(invisible(NULL))
        }
        
        if (is.null(boost$seed_state)) {
          seed <- boost$all_peps[[boost$idx]]
          boost$seed_state <- .init_seed_state(seed)
          boost$seed_steps <- 0L
          if (!is.null(boost$progress)) {
            try(boost$progress$set(
              value = boost$idx - 1L,
              detail = sprintf("seed %d/%d (building...)", boost$idx, boost$n)
            ), silent = TRUE)
          }
        }
        
        st <- boost$seed_state
        if (!is.null(st) && identical(st$phase, "done")) {
          .complete_seed(st)
          later::later(step_runner, 0.001)
          return(invisible(NULL))
        }
        
        res <- .seed_step(st, chunk = as.integer(boost$seed_chunk))
        boost$seed_state <- res$st
        boost$seed_steps <- boost$seed_steps + 1L
        
        if (!is.null(boost$progress) && !is.null(boost$seed_state) && !is.null(boost$seed_state$remaining)) {
          try(boost$progress$set(
            value = boost$idx - 1L,
            detail = sprintf("seed %d/%d (steps %d; remaining %d)", boost$idx, boost$n, boost$seed_steps, length(boost$seed_state$remaining))
          ), silent = TRUE)
        }
        
        if (!is.null(res$st) && isTRUE(res$finished)) {
          .complete_seed(res$st)
        }
        
        later::later(step_runner, 0.001)
        invisible(NULL)
      }
      
      later::later(step_runner, 0.001)
      invisible(NULL)
    }
    
    # --------------------- Batch constraint actions ---------------------------
    shiny::observeEvent(input$add_rule_btn, {
      genes <- as.character(input$restrict_gene)
      genes <- trimws(genes)
      genes <- genes[!is.na(genes) & nzchar(genes)]
      if (!length(genes)) {
        shiny::showNotification("Please choose at least one gene for this rule.", type = "warning")
        return()
      }
      
      allowed <- suppressWarnings(as.integer(input$restrict_chains))
      allowed <- allowed[is.finite(allowed) & allowed >= 1]
      if (!length(allowed)) {
        shiny::showNotification("Please select at least one allowed chain ID for this rule.", type = "warning")
        return()
      }
      
      rule <- list(genes = sort(unique(genes)), allowed = sort(unique(allowed)))
      rv$pending_constraints <- c(rv$pending_constraints, list(rule))
      
      shiny::showNotification(
        sprintf("Added batch rule: gene(s) [%s] → chain(s) %s", paste(rule$genes, collapse = ","), paste(rule$allowed, collapse = ",")),
        type = "message"
      )
    })
    
    shiny::observeEvent(input$remove_rule_btn, {
      sel <- input$batch_tbl_rows_selected
      pc <- rv$pending_constraints
      if (is.null(pc) || !length(pc) || is.null(sel) || !length(sel)) {
        shiny::showNotification("Select a batch rule row to remove.", type = "warning")
        return()
      }
      i <- as.integer(sel[[1]])
      if (!is.finite(i) || i < 1 || i > length(pc)) return()
      rv$pending_constraints <- pc[-i]
      shiny::showNotification(sprintf("Removed batch rule #%d", i), type = "message")
    })
    
    shiny::observeEvent(input$clear_batch_btn, {
      rv$pending_constraints <- list()
      shiny::showNotification("Cleared batch rules.", type = "message")
    })
    
    shiny::observeEvent(input$apply_batch_btn, {
      pc <- rv$pending_constraints
      if (is.null(pc) || !length(pc)) {
        shiny::showNotification("No pending batch rules to apply. Add rules first.", type = "warning")
        return()
      }
      
      merged <- list()
      for (r in pc) {
        gs <- as.character(r$genes)
        gs <- trimws(gs)
        gs <- gs[!is.na(gs) & nzchar(gs)]
        al <- suppressWarnings(as.integer(r$allowed))
        al <- al[is.finite(al) & al >= 1]
        al <- sort(unique(al))
        if (!length(gs) || !length(al)) next
        for (g in gs) {
          if (is.null(merged[[g]])) merged[[g]] <- al else merged[[g]] <- sort(unique(c(merged[[g]], al)))
        }
      }
      
      if (!length(merged)) {
        shiny::showNotification("Batch rules were empty after validation.", type = "warning")
        return()
      }
      
      for (g in names(merged)) rv$gene_constraints[[g]] <- merged[[g]]
      
      .enforce_gene_constraints()
      
      if (isTRUE(input$boost_after_apply)) {
        .boost_rebuild_from_scratch()
      }
      
      rv$pending_constraints <- list()
      
      shiny::showNotification(
        sprintf("Applied %d batch rule(s) (%d constrained gene(s)).%s",
                length(pc), length(names(merged)),
                if (isTRUE(input$boost_after_apply)) " (boost rebuild applied)" else ""),
        type = "message"
      )
    })
    
    shiny::observeEvent(input$clear_restrict_btn, {
      genes <- as.character(input$restrict_gene)
      genes <- trimws(genes)
      genes <- genes[!is.na(genes) & nzchar(genes)]
      if (!length(genes)) {
        shiny::showNotification("Please choose at least one gene to clear.", type = "warning")
        return()
      }
      
      cleared <- character(0)
      for (g in genes) {
        if (!is.null(rv$gene_constraints[[g]])) {
          rv$gene_constraints[[g]] <- NULL
          cleared <- c(cleared, g)
        }
      }
      
      if (length(cleared)) {
        shiny::showNotification(sprintf("Constraint cleared for gene(s): %s", paste(unique(cleared), collapse = ",")), type = "message")
      } else {
        shiny::showNotification("No matching active constraints found for the selected gene(s).", type = "warning")
      }
    })
    
    shiny::observeEvent(input$boost_rebuild_btn, {
      .boost_rebuild_from_scratch()
      if (isTRUE(boost$running)) {
        shiny::showNotification("Boost started — you can press 'Stop boost' to keep the best solution so far.", type = "message")
      }
    })
    
    shiny::observeEvent(input$stop_boost_btn, {
      if (isTRUE(boost$running)) {
        boost$stop <- TRUE
        shiny::showNotification("Stopping boost… (will keep the best solution found so far)", type = "message")
      } else {
        shiny::showNotification("Boost is not running.", type = "warning")
      }
    })
    
    output$boost_status_ui <- shiny::renderUI({
      if (!isTRUE(boost$running)) {
        return(shiny::tags$small(shiny::em("Boost: idle")))
      }
      shiny::invalidateLater(300, session)
      done <- max(0L, as.integer(boost$idx) - 1L)
      n <- as.integer(boost$n)
      best_n <- 0L
      if (!is.null(boost$best) && !is.null(boost$best$used_n)) best_n <- as.integer(boost$best$used_n)
      shiny::tags$div(
        shiny::tags$strong("Boost running… "),
        sprintf("evaluated %d/%d seeds; best incorporated = %d", done, n, best_n),
        shiny::tags$br(),
        shiny::tags$small(shiny::em("Press 'Stop boost' to stop and apply the best solution found so far."))
      )
    })
    
    output$inc_stats_ui <- shiny::renderUI({
      used <- used_peptides_reactive()
      used_n <- length(used)
      un_n <- if (is.null(rv$unassigned) || !nrow(rv$unassigned)) 0L else length(unique(rv$unassigned$Peptide))
      tot <- total_universe
      pct <- if (is.finite(tot) && tot > 0) sprintf("%.1f%%", 100 * used_n / tot) else "NA"
      shiny::tagList(
        shiny::tags$div(
          shiny::strong("Incorporated (unique peptides): "),
          sprintf("%d", used_n),
          if (is.finite(tot)) sprintf(" / %d (%s)", tot, pct) else ""
        ),
        shiny::tags$div(shiny::strong("Currently unassigned: "), sprintf("%d", un_n)),
        shiny::tags$div(shiny::strong("Chains: "), sprintf("%d", length(rv$chains)))
      )
    })
    
    output$chains_tbl <- DT::renderDataTable({
      .ensure_chain_meta()
      df <- .safe_do_call(.chains_summary_df, list(rv$chains, edges_lu, chain_names = rv$chain_names))
      DT::datatable(df, selection = "single", rownames = FALSE, options = list(pageLength = 10, scrollX = TRUE))
    })
    
    shiny::observeEvent(input$chains_tbl_rows_selected, {
      idx <- input$chains_tbl_rows_selected
      if (length(idx) == 1) {
        df <- .safe_do_call(.chains_summary_df, list(rv$chains, edges_lu, chain_names = rv$chain_names))
        if (nrow(df) >= idx) rv$selected_chain_id <- as.integer(df$chain_id[[idx]])
      }
    })
    
    output$unassigned_tbl <- DT::renderDataTable({
      df <- rv$unassigned
      df <- .ensure_unassigned_df(df)
      if ("source_proteins" %in% names(df)) names(df)[names(df) == "source_proteins"] <- "gene"
      DT::datatable(df, selection = "single", rownames = FALSE, options = list(pageLength = 10, scrollX = TRUE))
    })
    
    shiny::observeEvent(input$unassigned_tbl_rows_selected, {
      idx <- input$unassigned_tbl_rows_selected
      if (length(idx) == 1 && nrow(rv$unassigned) >= idx) rv$current_pep <- rv$unassigned$Peptide[[idx]]
    })
    
    output$current_pep_ui <- shiny::renderUI({
      cp <- rv$current_pep
      left_n <- if (is.null(rv$unassigned)) 0L else nrow(rv$unassigned)
      g <- if (is.na(cp) || !nzchar(cp)) "NA" else .gene_for_peptide(cp, src_map)
      shiny::tagList(
        shiny::strong("Current peptide: "),
        shiny::span(if (is.na(cp)) "(none)" else cp),
        shiny::br(),
        shiny::span(shiny::strong("Gene: "), g),
        shiny::br(),
        shiny::span(sprintf("Remaining unassigned: %d", left_n)),
        if (length(rv$skipped)) shiny::tags$div(sprintf("Skipped (hidden): %d", length(rv$skipped)))
      )
    })
    
    # ✅ 这里是你报错的位置：改为兼容式调用（chain_names 只有在 formals 存在时才传）
    output$chain_detail_tbl <- DT::renderDataTable({
      .ensure_chain_meta()
      df <- .safe_do_call(
        .chains_detail_df,
        list(rv$chains, src_map, selected_gene = input$gene_filter, chain_names = rv$chain_names)
      )
      dt <- DT::datatable(
        df,
        rownames = FALSE,
        options = list(
          pageLength = 15,
          scrollX = TRUE,
          columnDefs = list(list(visible = FALSE, targets = which(names(df) == "highlight") - 1))
        )
      )
      DT::formatStyle(
        dt,
        "highlight",
        target = "row",
        backgroundColor = DT::styleEqual(c(TRUE), c("#FFF2CC"))
      )
    })
    
    output$gene_dist_tbl <- DT::renderDataTable({
      .ensure_chain_meta()
      df <- .gene_distribution_df(rv$chains, rv$unassigned, src_map)
      if (!nrow(df)) {
        msg <- data.frame(message = "No gene annotations available to summarize.")
        return(DT::datatable(msg, rownames = FALSE, options = list(dom = "t")))
      }
      dt <- DT::datatable(df, rownames = FALSE, options = list(pageLength = 15, scrollX = TRUE))
      sel <- as.character(input$gene_filter)
      if (!is.na(sel)) sel <- trimws(sel)
      if (!is.na(sel) && nzchar(sel)) {
        dt <- DT::formatStyle(
          dt,
          "gene",
          target = "row",
          backgroundColor = DT::styleEqual(c(sel), c("#FFF2CC"))
        )
      }
      dt
    })
    
    # ---- Insertion candidates reactive ---------------------------------------
    ins_df <- shiny::reactive({
      cp <- rv$current_pep
      if (is.na(cp) || !nzchar(cp)) return(data.frame())
      cp <- toupper(trimws(as.character(cp)))
      if (!cp %in% rv$unassigned$Peptide) return(data.frame())
      
      allowed <- .allowed_chains_for_peptide(cp)
      opts <- .insert_options_for_peptide(cp, rv$chains, edges_lu, thr, max_chain_AA = max_chain_AA_val())
      if (nrow(opts) && !is.null(allowed)) opts <- opts[opts$chain_id %in% allowed, , drop = FALSE]
      opts
    })
    
    output$ins_tbl <- DT::renderDataTable({
      df <- ins_df()
      if (!nrow(df)) {
        msg <- data.frame(message = "No valid insertions for the current peptide under this threshold.")
        return(DT::datatable(msg, rownames = FALSE, options = list(dom = "t")))
      }
      
      drop_cols <- c("score_min", "score_mean", "score_sum")
      df_show <- df[, setdiff(names(df), drop_cols), drop = FALSE]
      
      DT::datatable(df_show, selection = "single", rownames = FALSE,
                    options = list(pageLength = 12, scrollX = TRUE))
    })
    
    # ---- Detach from chain ----------------------------------------------------
    .detach_from_chain <- function(from = c("head", "tail")) {
      from <- match.arg(from)
      
      cid <- suppressWarnings(as.integer(rv$selected_chain_id))
      if (!is.finite(cid) || cid < 1 || cid > length(rv$chains)) {
        shiny::showNotification("Please select a valid chain first.", type = "warning")
        return(invisible(NULL))
      }
      
      ch <- rv$chains[[cid]]
      ch <- ch[!is.na(ch) & nzchar(ch)]
      if (!length(ch)) {
        shiny::showNotification(sprintf("Chain %d is empty.", cid), type = "warning")
        return(invisible(NULL))
      }
      
      n <- suppressWarnings(as.integer(input$detach_n))
      if (!is.finite(n) || n < 1) n <- 1L
      n <- min(n, length(ch))
      
      if (from == "head") {
        removed <- ch[seq_len(n)]
        remain  <- if (n < length(ch)) ch[-seq_len(n)] else character(0)
      } else {
        removed <- ch[(length(ch) - n + 1L):length(ch)]
        remain  <- if (n < length(ch)) ch[seq_len(length(ch) - n)] else character(0)
      }
      
      rv$chains[[cid]] <- remain
      
      used_now <- unique(unlist(rv$chains))
      used_now <- used_now[!is.na(used_now) & nzchar(used_now)]
      used_now <- intersect(used_now, pep_universe_vec)
      
      to_add <- setdiff(unique(removed), unique(used_now))
      to_add <- intersect(to_add, pep_universe_vec)
      
      if (length(to_add)) {
        rv$unassigned <- .add_peptides_to_unassigned(rv$unassigned, to_add, src_map)
        rv$skipped <- setdiff(rv$skipped, to_add)
        if (is.na(rv$current_pep) && nrow(rv$unassigned)) rv$current_pep <- rv$unassigned$Peptide[[1]]
      }
      
      shiny::showNotification(sprintf("Detached %d peptide(s) from %s of chain %d.", n, from, cid), type = "message")
      invisible(NULL)
    }
    
    shiny::observeEvent(input$detach_head_btn, { .detach_from_chain("head") })
    shiny::observeEvent(input$detach_tail_btn, { .detach_from_chain("tail") })
    
    # ---- Skip / reset skip ----------------------------------------------------
    shiny::observeEvent(input$skip_btn, {
      cp <- rv$current_pep
      if (is.na(cp) || !nzchar(cp)) return()
      rv$skipped <- unique(c(rv$skipped, cp))
      rv$unassigned <- rv$unassigned[rv$unassigned$Peptide != cp, , drop = FALSE]
      rv$current_pep <- if (nrow(rv$unassigned)) rv$unassigned$Peptide[1] else NA_character_
    })
    
    shiny::observeEvent(input$reset_skip_btn, {
      if (!length(rv$skipped)) return()
      back <- data.frame(
        Peptide = rv$skipped,
        pep_len = nchar(rv$skipped),
        source_proteins = vapply(rv$skipped, .gene_for_peptide, character(1), src_map = src_map),
        stringsAsFactors = FALSE
      )
      rv$unassigned <- rbind(.ensure_unassigned_df(rv$unassigned), back)
      rv$unassigned <- rv$unassigned[order(rv$unassigned$Peptide), , drop = FALSE]
      rownames(rv$unassigned) <- NULL
      rv$skipped <- character(0)
      if (is.na(rv$current_pep) && nrow(rv$unassigned)) rv$current_pep <- rv$unassigned$Peptide[1]
    })
    
    # ---- Apply selected insertion --------------------------------------------
    shiny::observeEvent(input$apply_btn, {
      df <- ins_df()
      if (!nrow(df)) return()
      
      sel <- input$ins_tbl_rows_selected
      if (length(sel) != 1) {
        shiny::showNotification("Please select exactly one insertion option.", type = "warning")
        return()
      }
      
      opt <- df[sel, , drop = FALSE]
      cp  <- as.character(opt$insert_peptide[[1]])
      typ <- as.character(opt$insert_type[[1]])
      
      if (identical(typ, "new_chain")) {
        rv$chains[[length(rv$chains) + 1L]] <- cp
        .ensure_chain_meta()
      } else if (identical(typ, "seed_chain")) {
        cid <- suppressWarnings(as.integer(opt$chain_id[[1]]))
        if (!is.finite(cid) || cid < 1) {
          shiny::showNotification("Invalid chain_id for seed_chain.", type = "warning")
          return()
        }
        if (cid > length(rv$chains)) {
          for (k in seq_len(cid - length(rv$chains))) rv$chains[[length(rv$chains) + 1L]] <- character(0)
        }
        .ensure_chain_meta()
        ch <- rv$chains[[cid]]
        ch <- ch[!is.na(ch) & nzchar(ch)]
        if (length(ch)) {
          shiny::showNotification(sprintf("Chain %d is not empty; cannot seed.", cid), type = "warning")
          return()
        }
        rv$chains[[cid]] <- cp
      } else {
        rv$chains <- .apply_insertion(rv$chains, opt)
        .ensure_chain_meta()
      }
      
      rv$unassigned <- rv$unassigned[rv$unassigned$Peptide != cp, , drop = FALSE]
      rv$current_pep <- if (nrow(rv$unassigned)) rv$unassigned$Peptide[1] else NA_character_
      
      shiny::showNotification(
        sprintf(
          "%s %s.",
          if (identical(typ, "new_chain")) "Started new chain with" else if (identical(typ, "seed_chain")) "Seeded chain with" else "Inserted",
          cp
        ),
        type = "message"
      )
    })
    
    # ---- Download -------------------------------------------------------------
    output$download_zip <- shiny::downloadHandler(
      filename = function() paste0(out_base, ".zip"),
      content = function(file) {
        .ensure_chain_meta()
        
        tmpdir <- tempfile("manual_asm_")
        dir.create(tmpdir)
        
        chain_out <- .safe_do_call(
          .build_chain_table,
          list(
            rv$chains, edges_lu, src_map,
            chain_names = rv$chain_names,
            addons = rv$addons
          )
        )
        edge_out <- .edges_from_chains(rv$chains, edges_lu)
        unassigned_out <- .ensure_unassigned_df(rv$unassigned)
        
        chain_tsv <- file.path(tmpdir, paste0(out_base, "_chains.tsv"))
        edge_tsv <- file.path(tmpdir, paste0(out_base, "_edges.tsv"))
        unassigned_tsv <- file.path(tmpdir, paste0(out_base, "_unassigned_peptides.tsv"))
        state_rds <- file.path(tmpdir, paste0(out_base, "_manual_state.rds"))
        
        readr::write_tsv(chain_out, chain_tsv)
        readr::write_tsv(edge_out, edge_tsv)
        readr::write_tsv(unassigned_out, unassigned_tsv)
        
        saveRDS(
          list(
            stage2_state_rds = stage2_state_rds,
            use_netchop = TRUE,
            netchop_thr = thr,
            chains = rv$chains,
            chain_names = rv$chain_names,
            addons = rv$addons,
            chain_table = chain_out,
            edge_table = edge_out,
            unassigned_table = unassigned_out,
            gene_constraints = rv$gene_constraints,
            skipped_hidden = rv$skipped
          ),
          state_rds
        )
        
        old <- setwd(tmpdir)
        on.exit(setwd(old), add = TRUE)
        utils::zip(zipfile = file, files = basename(c(chain_tsv, edge_tsv, unassigned_tsv, state_rds)))
      }
    )
  } # end server()
  
  app <- shiny::shinyApp(ui = ui, server = server)
  shiny::runApp(app, launch.browser = isTRUE(launch_browser))
  invisible(NULL)
}
