# NetChop parsing ------------------------------------------------------------

#' @keywords internal
parse_netchop_txt <- function(path) {
  if (is.null(path) || !nzchar(path) || !file.exists(path)) {
    stop("netchop_txt does not exist: ", path)
  }
  lines <- readLines(path, warn = FALSE)
  lines <- lines[!is.na(lines)]
  cur_id <- NA_character_
  out <- list()
  k <- 0L

  for (ln in lines) {
    ln <- trimws(ln)
    if (!nzchar(ln)) next
    if (startsWith(ln, "#")) next

    # Format 1: FASTA-like headers (some NetChop exports)
    if (startsWith(ln, ">")) {
      cur_id <- sub("^>\\s*", "", ln)
      next
    }

    # Format 2: NetChop 3.x long output table, e.g.
    #   1   T  .   0.028237  pep000001
    # (pos, AA, C, score, Ident)
    m <- regexec(
      "^\\s*(\\d+)\\s+\\S+\\s+\\S+\\s+([-+]?\\d*\\.?\\d+(?:[eE][-+]?\\d+)?)\\s+(\\S+)\\s*$",
      ln,
      perl = TRUE
    )
    mm <- regmatches(ln, m)[[1]]
    if (length(mm)) {
      pos <- suppressWarnings(as.integer(mm[2]))
      sc  <- suppressWarnings(as.numeric(mm[3]))
      pid <- if (!is.na(cur_id) && nzchar(cur_id)) cur_id else mm[4]
      if (is.finite(pos) && is.finite(sc) && nzchar(pid)) {
        k <- k + 1L
        out[[k]] <- data.frame(pep_id = pid, pos = pos, score = sc, stringsAsFactors = FALSE)
      }
      next
    }

    # Format 3: Generic whitespace-separated output after a '>' header.
    # Older formats often have: pos ... score (score is the last numeric token).
    toks <- strsplit(ln, "\\s+")[[1]]
    if (length(toks) < 2) next
    pos <- suppressWarnings(as.integer(toks[1]))
    if (is.na(pos)) next

    sc <- NA_real_
    for (j in rev(seq_along(toks))) {
      v <- suppressWarnings(as.numeric(toks[j]))
      if (!is.na(v)) { sc <- v; break }
    }
    if (is.na(sc)) next
    if (is.na(cur_id) || !nzchar(cur_id)) next

    k <- k + 1L
    out[[k]] <- data.frame(pep_id = cur_id, pos = pos, score = sc, stringsAsFactors = FALSE)
  }
  if (!length(out)) stop("Failed to parse NetChop output. Unsupported format? File: ", path)
  do.call(rbind, out)
}

#' @keywords internal
netchop_boundary_scores <- function(map_dt, netchop_df) {
  map_df <- as.data.frame(map_dt, stringsAsFactors = FALSE)
  need <- c("pep_id","A_len","A","B")
  if (!all(need %in% names(map_df))) stop("map_dt is missing required columns: ", paste(setdiff(need, names(map_df)), collapse = ", "))

  # boundary position: A_len
  netchop_df <- as.data.frame(netchop_df, stringsAsFactors = FALSE)
  netchop_df$pos <- suppressWarnings(as.integer(netchop_df$pos))
  netchop_df$score <- suppressWarnings(as.numeric(netchop_df$score))

  # merge by pep_id and pos == A_len
  # Use base merge with a helper key
  map_df$key <- paste(map_df$pep_id, map_df$A_len, sep = "::")
  netchop_df$key <- paste(netchop_df$pep_id, netchop_df$pos, sep = "::")
  m <- merge(map_df, netchop_df[, c("key","score")], by = "key", all.x = TRUE)
  m$key <- NULL
  names(m)[names(m) == "score"] <- "netchop_score_boundary"
  m
}
