# Internal helpers ------------------------------------------------------------

.ensure_dir <- function(path) {
  if (!dir.exists(path)) dir.create(path, recursive = TRUE, showWarnings = FALSE)
  normalizePath(path, winslash = "/", mustWork = FALSE)
}

# Safer substring extraction for AA sequences
safe_substr <- function(x, start, end) {
  if (length(x) == 0L) return(character(0))
  out <- character(length(x))
  for (i in seq_along(x)) {
    xi <- as.character(x[[i]])
    si <- suppressWarnings(as.integer(start[[i]]))
    ei <- suppressWarnings(as.integer(end[[i]]))
    if (is.na(xi) || is.na(si) || is.na(ei) || !nzchar(xi)) {
      out[[i]] <- NA_character_
      next
    }
    si <- max(1L, si)
    ei <- min(nchar(xi), ei)
    if (si > ei) {
      out[[i]] <- NA_character_
    } else {
      out[[i]] <- substr(xi, si, ei)
    }
  }
  out
}

# Decide which files to ignore during NetMHCpan directory scan
.should_skip_by_name <- function(x) {
  x <- tolower(basename(x))
  grepl("(^~\\$|\\.(tmp|bak)$|_cleaned\\.txt$|\\.ds_store$)", x) ||
    grepl("netchop", x) ||
    grepl("(^|[_-])stderr([_-]|$)|(^|[_-])stdout([_-]|$)", x)
}

# Parse raw NetMHCpan text output (non-TSV) into a data.frame
.read_netmhcpan_raw_text <- function(path) {
  lines <- tryCatch(readLines(path, warn = FALSE), error = function(e) character(0))
  if (!length(lines)) return(NULL)
  lines <- gsub("\r$", "", lines)

  # drop comment lines and empty/separator lines
  lines2 <- lines[!grepl("^\\s*#", lines)]
  lines2 <- lines2[nzchar(trimws(lines2))]
  lines2 <- lines2[!grepl("^\\s*-{3,}\\s*$", lines2)]

  # find header line containing Peptide
  h <- which(grepl("\\bPeptide\\b", lines2, ignore.case = TRUE))
  if (!length(h)) return(NULL)
  h <- h[1]

  # keep subsequent lines that look like data rows (start with position integer)
  data_lines <- character(0)
  if (h < length(lines2)) {
    rest <- lines2[(h + 1):length(lines2)]
    data_lines <- rest[grepl("^\\s*\\d+\\s+", rest)]
  }
  if (!length(data_lines)) return(NULL)

  txt <- paste(c(lines2[h], data_lines), collapse = "\n")
  df <- tryCatch(
    utils::read.table(
      text = txt,
      header = TRUE,
      sep = "",
      fill = TRUE,
      stringsAsFactors = FALSE,
      check.names = FALSE,
      quote = "",
      comment.char = ""
    ),
    error = function(e) NULL
  )
  if (is.null(df) || !nrow(df)) return(NULL)

  names(df) <- make.unique(gsub("[[:space:]]+", "_", names(df)))
  df
}

# Read xls/xlsx/tsv/txt in a minimal way
.read_table_any <- function(path) {
  ext <- tolower(tools::file_ext(path))
  if (ext %in% c("xls", "xlsx")) {
    # Many NetMHCpan "*.xls" outputs are actually plain text tables.
    # Try readxl first; if it fails, fall back to a tab/whitespace parser.
    df <- tryCatch(
      as.data.frame(readxl::read_excel(path, .name_repair = "unique_quiet")),
      error = function(e) NULL
    )

    if (is.null(df)) {
      df <- tryCatch(
        data.table::fread(path,
                          sep = "\t",
                          header = TRUE,
                          fill = TRUE,
                          data.table = FALSE,
                          comment.char = "#"),
        error = function(e) NULL
      )
    }

    # If still not usable, try the raw NetMHCpan text parser (works for many .xls text exports).
    if (!is.null(df) && !("Peptide" %in% names(df))) {
      df2 <- .read_netmhcpan_raw_text(path)
      if (!is.null(df2)) df <- df2
    }
    if (is.null(df)) {
      df <- .read_netmhcpan_raw_text(path)
    }

    return(df)
  }
  # fallback: tab-delimited first
  df <- tryCatch(
    data.table::fread(path, sep = "\t", header = TRUE, data.table = FALSE),
    error = function(e) NULL
  )
  if (is.null(df)) {
    df <- tryCatch(
      utils::read.table(path, sep = "\t", header = TRUE, stringsAsFactors = FALSE, check.names = FALSE),
      error = function(e) NULL
    )
  }

  # If txt/tsv is actually raw NetMHCpan output, try whitespace parser
  if (!is.null(df)) {
    if (!("Peptide" %in% names(df)) && ext %in% c("txt", "tsv")) {
      df2 <- .read_netmhcpan_raw_text(path)
      if (!is.null(df2)) df <- df2
    }
  } else {
    if (ext %in% c("txt", "tsv")) {
      df <- .read_netmhcpan_raw_text(path)
    }
  }

  df
}

# Flatten header: if the first row looks like a header continuation, combine it
.flatten_netmhc_header <- function(df, exclude_last = 2) {
  if (nrow(df) < 2) return(df)

  # If any column names are NA/empty, fix now
  cn <- colnames(df)
  cn[is.na(cn) | cn == ""] <- paste0("X", seq_along(cn))[is.na(cn) | cn == ""]
  colnames(df) <- cn

  # Heuristic: flatten ONLY when the first data row looks like allele labels
  # (common in NetMHCpan xls exports where allele names occupy the first row).
  row1 <- df[1, , drop = FALSE]
  row1_chr <- vapply(row1, function(z) as.character(z[[1]]), character(1))
  nonempty <- sum(nzchar(trimws(row1_chr)))
  if (nonempty < 2) return(df)

  has_allele_like <- any(grepl("(?i)HLA|\\b[ABC]\\*\\d|\\bDRB\\d|\\bDQB\\d|\\bDPB\\d|\\bH-2\\b|Mamu|Patr|BoLA", row1_chr, perl = TRUE)) ||
    any(grepl(":", row1_chr, fixed = TRUE))
  if (!has_allele_like) return(df)

  # Combine: new names = paste(colname, row1) except last exclude_last columns
  k <- ncol(df)
  keep_k <- max(0, k - exclude_last)
  new_names <- cn
  if (keep_k > 0) {
    for (j in seq_len(keep_k)) {
      add <- trimws(row1_chr[[j]])
      if (nzchar(add)) {
        new_names[[j]] <- paste0(cn[[j]], "_", add)
      }
    }
  }
  colnames(df) <- make.unique(gsub("[[:space:]]+", "_", new_names))
  df <- df[-1, , drop = FALSE]
  rownames(df) <- NULL
  df
}

# Parse numeric ranks robustly from strings like "0.12", "0.12 | 0.34", "Rank:0.12"
.parse_numeric_min <- function(x) {
  if (is.null(x)) return(NA_real_)
  s <- as.character(x)
  s <- gsub(",", ".", s, fixed = TRUE)
  nums <- suppressWarnings(as.numeric(unlist(strsplit(s, "[^0-9\\.eE\\+\\-]+"))))
  nums <- nums[is.finite(nums)]
  if (!length(nums)) return(NA_real_)
  min(nums)
}

# Collapse unique values as a single string (used when merging intervals)
.collapse_unique <- function(x) {
  ux <- unique(as.character(x))
  ux <- ux[!is.na(ux) & nzchar(ux)]
  if (!length(ux)) return(NA_character_)
  paste(ux, collapse = " | ")
}
