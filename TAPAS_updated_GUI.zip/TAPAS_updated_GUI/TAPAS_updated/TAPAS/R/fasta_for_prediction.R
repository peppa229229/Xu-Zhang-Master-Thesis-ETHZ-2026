#' FASTA generator for NetMHCpan / pan input (RSEM/TPM / 3CA / Gene list / Protein list)
#'
#' Key behavior:
#' - Load RSEM/TPM: ONLY read + map ENSG->HUGO, NO sequence fetching.
#' - Sequence fetch happens ONLY at Export step, and only for the selected subset.
#' - Transcript table: two columns (Gene/HUGO + TranscriptID). One cell can contain multiple TIDs
#'   separated by comma/Chinese comma/space. Auto alias: GENE_A, GENE_B, ...
#' - Gene table & plots remain gene-level (HUGO). Export annotation records Alias->TID and AA source.
#'
#' Manual AA (Export-only):
#' - Paste: KEY<TAB>AA where KEY can be HUGO or ENST.
#' - HUGO applies ONLY to gene-level rows (TranscriptID is empty).
#' - ENST applies ONLY to transcript rows (TranscriptID matches).
#' - This step can override existing AA; will prompt which genes are being overwritten.
#'
#' Fixes:
#' - 3CA sheet missing numeric columns no longer crashes DT/plots (ensures columns exist as NA)
#' - DT no longer uses formatRound(na=...) (removed invalid argument)
#' - Guards against NULL columns producing length-0 vectors
#' - TPM_display never hidden when 3CA disabled
#'
#' Download fix (NEW):
#' - Example template download uses static direct links (addResourcePath + <a download>) when Examples exists.
#' - Export download provides direct links as fallback even if Shiny downloadButton is unresponsive.
#'
#' TPM output (NEW):
#' - Export also writes a TPM workbook: <prefix>_TPM.xlsx with sheets:
#'   - TPM_gene: HUGO, TPM, ENSG
#'   - TPM_header: Header, Gene, TranscriptID, TPM, ENSG
#'
#' NetMHC command generator (NEW):
#' - In Export tab, build copyable terminal commands for netMHCpan / netMHCIIpan.
#' - Paste FASTA path, choose Class I/II, paste HLA alleles (comma-separated), choose lengths, output name, workdir.
#'
#' @param out_dir Directory to write exported files (default: temporary directory).
#' @param threeca_default_path Default path shown in the UI for 3CA xlsx.
#' @export
fasta_for_prediction <- function(
    out_dir = tempdir(),
    threeca_default_path = "C:/Users/peppa/Downloads/3CA_Malignant_markers.xlsx"
) {
  out_dir <- normalizePath(out_dir, winslash = "/", mustWork = FALSE)
  if (!dir.exists(out_dir)) dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
  
  options(shiny.maxRequestSize = 200 * 1024^2)  # 200 MB
  
  # ---- deps ----
  .ffp_need <- function(pkg) {
    if (!requireNamespace(pkg, quietly = TRUE)) {
      stop("Package '", pkg, "' is required for fasta_for_prediction(). Please install it.")
    }
  }
  
  .ffp_need("shiny")
  .ffp_need("DT")
  .ffp_need("readxl")
  .ffp_need("dplyr")
  .ffp_need("tidyr")
  .ffp_need("stringr")
  .ffp_need("plotly")
  .ffp_need("writexl")
  .ffp_need("htmltools")
  .ffp_need("tools")
  
  # make %>% available even if dplyr is not attached
  `%>%` <- dplyr::`%>%`
  
  .ffp_need_biomart <- function() {
    if (!requireNamespace("biomaRt", quietly = TRUE)) {
      stop(
        "biomaRt is required for Ensembl mapping / peptide fetching in fasta_for_prediction().\n",
        "Install via Bioconductor: BiocManager::install('biomaRt')"
      )
    }
  }
  
  `%||%` <- function(a, b) if (!is.null(a)) a else b
  
  .ffp_try_read <- function(expr, quiet = TRUE) {
    tryCatch(expr, error = function(e) {
      if (!quiet) message(e$message)
      NULL
    })
  }
  
  .ffp_norm_ens_id <- function(x) {
    x <- as.character(x)
    x[is.na(x)] <- ""
    x <- sub("\\..*$", "", x) # strip version suffix
    x <- trimws(x)
    x
  }
  
  .ffp_safe_num <- function(x) suppressWarnings(as.numeric(x))
  
  .ffp_input_num <- function(x, default = 0) {
    if (is.null(x) || length(x) == 0) return(default)
    v <- suppressWarnings(as.numeric(x))
    if (length(v) == 0 || is.na(v[1])) return(default)
    v[1]
  }
  
  .ffp_pick_col <- function(df, candidates) {
    if (is.null(df) || !nrow(df)) return(NA_character_)
    nm <- names(df)
    hit <- candidates[candidates %in% nm]
    if (!length(hit)) return(NA_character_)
    hit[1]
  }
  
  .ffp_read_excel_any <- function(path) {
    if (is.null(path) || !nzchar(path) || !file.exists(path)) return(NULL)
    ext <- tolower(tools::file_ext(path))
    if (!(ext %in% c("xlsx", "xls"))) return(NULL)
    .ffp_try_read(as.data.frame(readxl::read_excel(path, .name_repair = "unique_quiet"), stringsAsFactors = FALSE))
  }
  
  .ffp_read_table_any <- function(path) {
    if (is.null(path) || !nzchar(path) || !file.exists(path)) return(NULL)
    ext <- tolower(tools::file_ext(path))
    
    if (ext %in% c("xlsx", "xls")) return(.ffp_read_excel_any(path))
    
    if (ext == "csv") {
      df <- .ffp_try_read(as.data.frame(utils::read.csv(path, stringsAsFactors = FALSE, check.names = FALSE)))
      return(df)
    }
    
    df <- .ffp_try_read(as.data.frame(utils::read.delim(path, stringsAsFactors = FALSE, sep = "\t", check.names = FALSE)))
    if (is.null(df)) return(NULL)
    if (ncol(df) <= 1) {
      df2 <- .ffp_try_read(as.data.frame(utils::read.table(path, stringsAsFactors = FALSE, header = TRUE, sep = "", check.names = FALSE)))
      if (!is.null(df2) && ncol(df2) > 1) df <- df2
    }
    df
  }
  
  .ffp_ensure_cols <- function(df, cols, default_val = NA_real_) {
    for (cn in cols) {
      if (!(cn %in% names(df))) df[[cn]] <- default_val
    }
    df
  }
  
  .ffp_mart <- function(build = c("GRCh38", "GRCh37")) {
    .ffp_need_biomart()
    build <- match.arg(build)
    if (build == "GRCh37") {
      biomaRt::useEnsembl(biomart = "ensembl", dataset = "hsapiens_gene_ensembl", GRCh = 37)
    } else {
      biomaRt::useEnsembl(biomart = "ensembl", dataset = "hsapiens_gene_ensembl")
    }
  }
  
  .ffp_map_ensg_to_hugo <- function(ensg, build = c("GRCh38", "GRCh37")) {
    build <- match.arg(build)
    ensg <- unique(.ffp_norm_ens_id(ensg))
    ensg <- ensg[!is.na(ensg) & nzchar(ensg)]
    if (!length(ensg)) return(data.frame(ENSG = character(0), HUGO = character(0), stringsAsFactors = FALSE))
    mart <- .ffp_mart(build)
    bm <- biomaRt::getBM(
      attributes = c("ensembl_gene_id", "hgnc_symbol"),
      filters = "ensembl_gene_id",
      values = ensg,
      mart = mart
    )
    out <- data.frame(
      ENSG = as.character(bm$ensembl_gene_id),
      HUGO = trimws(as.character(bm$hgnc_symbol)),
      stringsAsFactors = FALSE
    )
    out$HUGO[out$HUGO == ""] <- NA_character_
    out
  }
  
  .ffp_map_hugo_to_ensg <- function(hugo, build = c("GRCh38", "GRCh37")) {
    build <- match.arg(build)
    hugo <- unique(trimws(as.character(hugo)))
    hugo <- hugo[!is.na(hugo) & nzchar(hugo)]
    if (!length(hugo)) return(data.frame(HUGO = character(0), ENSG = character(0), stringsAsFactors = FALSE))
    mart <- .ffp_mart(build)
    bm <- biomaRt::getBM(
      attributes = c("hgnc_symbol", "ensembl_gene_id"),
      filters = "hgnc_symbol",
      values = hugo,
      mart = mart
    )
    data.frame(
      HUGO = trimws(as.character(bm$hgnc_symbol)),
      ENSG = as.character(bm$ensembl_gene_id),
      stringsAsFactors = FALSE
    )
  }
  
  # ---------------- Example templates (ABS paths) + direct static links (NEW) ----------------
  .ffp_examples_abs <- c(
    "TPM.xlsx" = "C:/Users/peppa/Downloads/TAPAS_updated/TAPAS/Examples/TPM.xlsx",
    "Gene_List.xlsx" = "C:/Users/peppa/Downloads/TAPAS_updated/TAPAS/Examples/Gene_List.xlsx",
    "Gene_List_Transcript_ID.xlsx" = "C:/Users/peppa/Downloads/TAPAS_updated/TAPAS/Examples/Gene_List_Transcript_ID.xlsx",
    "Protein_List.xlsx" = "C:/Users/peppa/Downloads/TAPAS_updated/TAPAS/Examples/Protein_List.xlsx"
  )
  
  .ffp_examples_dir <- normalizePath(dirname(.ffp_examples_abs[[1]]), winslash = "/", mustWork = FALSE)
  have_examples_dir <- dir.exists(.ffp_examples_dir)
  
  # Expose Examples/ as static files: /tapas_examples/<file>
  if (have_examples_dir) shiny::addResourcePath("tapas_examples", .ffp_examples_dir)
  
  # Expose out_dir as static files: /tapas_out/<file>  (for export direct links)
  shiny::addResourcePath("tapas_out", out_dir)
  
  # --------------- fallback example generator (kept) ---------------
  .ffp_write_fallback_example_xlsx <- function(kind = c("tpm", "genelist", "enst", "protein"), dest_file) {
    kind <- match.arg(kind)
    if (kind == "tpm") {
      df <- data.frame(
        HUGO = c("TP53", "BRCA1", "GAPDH"),
        TPM  = c(12.3, 4.5, 95.0),
        stringsAsFactors = FALSE
      )
      writexl::write_xlsx(list(TPM = df), path = dest_file)
      return(invisible(TRUE))
    }
    if (kind == "genelist") {
      df <- data.frame(
        HUGO = c("TP53", "BRCA1", "EGFR"),
        ENSG = c("ENSG00000141510", "ENSG00000012048", "ENSG00000146648"),
        stringsAsFactors = FALSE
      )
      writexl::write_xlsx(list(Gene_List = df), path = dest_file)
      return(invisible(TRUE))
    }
    if (kind == "enst") {
      df <- data.frame(
        Gene = c("TP53", "BRCA1"),
        TranscriptID = c("ENST00000269305, ENST00000420246", "ENST00000357654"),
        stringsAsFactors = FALSE
      )
      writexl::write_xlsx(list(Gene_Transcript = df), path = dest_file)
      return(invisible(TRUE))
    }
    if (kind == "protein") {
      df <- data.frame(
        HUGO = c("TP53", "BRCA1"),
        AA   = c("MEEPQSDPSVEPPLSQETFSDLWKLLPENNVLSPLPSQAMDDLMLSPDDIEQWFTEDPGP",
                 "MDLSALRVEEVQNVINAMQKILECPICLELIKEPVG..."),
        stringsAsFactors = FALSE
      )
      writexl::write_xlsx(list(Protein_List = df), path = dest_file)
      return(invisible(TRUE))
    }
    invisible(FALSE)
  }
  
  .ffp_download_example <- function(kind = c("tpm", "genelist", "enst", "protein"), filename, file) {
    kind <- match.arg(kind)
    # Prefer your absolute Examples paths
    src <- .ffp_examples_abs[[filename]]
    if (!is.null(src) && nzchar(src) && file.exists(src)) {
      ok <- file.copy(src, file, overwrite = TRUE)
      if (!isTRUE(ok)) .ffp_write_fallback_example_xlsx(kind = kind, dest_file = file)
    } else {
      .ffp_write_fallback_example_xlsx(kind = kind, dest_file = file)
    }
  }
  
  # --- fetching peptides (ONLY used at Export step) ---
  .ffp_fetch_canonical_peptide_grch38 <- function(hugo_vec) {
    .ffp_need_biomart()
    hugo_vec <- unique(trimws(as.character(hugo_vec)))
    hugo_vec <- hugo_vec[!is.na(hugo_vec) & nzchar(hugo_vec)]
    if (!length(hugo_vec)) {
      return(data.frame(HUGO = character(0), TID = character(0), AA = character(0), AA_len = integer(0), stringsAsFactors = FALSE))
    }
    mart38 <- .ffp_mart("GRCh38")
    meta <- biomaRt::getBM(
      attributes = c("hgnc_symbol", "ensembl_transcript_id", "transcript_is_canonical", "transcript_biotype"),
      filters = "hgnc_symbol",
      values = hugo_vec,
      mart = mart38
    )
    meta <- as.data.frame(meta, stringsAsFactors = FALSE)
    if (!nrow(meta)) {
      return(data.frame(HUGO = hugo_vec, TID = NA_character_, AA = NA_character_, AA_len = NA_integer_, stringsAsFactors = FALSE))
    }
    meta <- meta[!is.na(meta$transcript_is_canonical) & meta$transcript_is_canonical == 1L & meta$transcript_biotype == "protein_coding", , drop = FALSE]
    if (!nrow(meta)) {
      return(data.frame(HUGO = hugo_vec, TID = NA_character_, AA = NA_character_, AA_len = NA_integer_, stringsAsFactors = FALSE))
    }
    seqs <- biomaRt::getSequence(
      id = unique(meta$ensembl_transcript_id),
      type = "ensembl_transcript_id",
      seqType = "peptide",
      mart = mart38
    )
    seqs <- as.data.frame(seqs, stringsAsFactors = FALSE)
    if (!nrow(seqs)) {
      return(data.frame(HUGO = hugo_vec, TID = NA_character_, AA = NA_character_, AA_len = NA_integer_, stringsAsFactors = FALSE))
    }
    colnames(seqs)[colnames(seqs) == "peptide"] <- "AA"
    colnames(seqs)[colnames(seqs) == "ensembl_transcript_id"] <- "TID"
    
    meta2 <- dplyr::inner_join(meta, seqs, by = c("ensembl_transcript_id" = "TID"))
    meta2$AA <- gsub("[^A-Za-z]", "", as.character(meta2$AA))
    meta2$AA_len <- nchar(meta2$AA)
    meta2 <- meta2[meta2$AA_len > 0, , drop = FALSE]
    if (!nrow(meta2)) {
      return(data.frame(HUGO = hugo_vec, TID = NA_character_, AA = NA_character_, AA_len = NA_integer_, stringsAsFactors = FALSE))
    }
    
    meta2 <- meta2 %>%
      dplyr::group_by(hgnc_symbol) %>%
      dplyr::arrange(dplyr::desc(AA_len), ensembl_transcript_id) %>%
      dplyr::slice(1) %>%
      dplyr::ungroup() %>%
      dplyr::transmute(HUGO = hgnc_symbol, TID = ensembl_transcript_id, AA, AA_len)
    
    meta2 <- dplyr::right_join(meta2, data.frame(HUGO = hugo_vec, stringsAsFactors = FALSE), by = "HUGO")
    meta2
  }
  
  .ffp_fetch_peptide_by_enst <- function(enst_vec, build = c("GRCh38", "GRCh37")) {
    .ffp_need_biomart()
    build <- match.arg(build)
    enst_vec <- unique(.ffp_norm_ens_id(enst_vec))
    enst_vec <- enst_vec[!is.na(enst_vec) & nzchar(enst_vec)]
    if (!length(enst_vec)) {
      return(data.frame(TID = character(0), HUGO = character(0), AA = character(0), AA_len = integer(0), stringsAsFactors = FALSE))
    }
    mart <- .ffp_mart(build)
    meta <- biomaRt::getBM(
      attributes = c("ensembl_transcript_id", "hgnc_symbol", "transcript_biotype"),
      filters = "ensembl_transcript_id",
      values = enst_vec,
      mart = mart
    )
    meta <- as.data.frame(meta, stringsAsFactors = FALSE)
    if (!nrow(meta)) {
      return(data.frame(TID = enst_vec, HUGO = NA_character_, AA = NA_character_, AA_len = NA_integer_, stringsAsFactors = FALSE))
    }
    meta <- meta[meta$transcript_biotype == "protein_coding", , drop = FALSE]
    if (!nrow(meta)) {
      return(data.frame(TID = enst_vec, HUGO = NA_character_, AA = NA_character_, AA_len = NA_integer_, stringsAsFactors = FALSE))
    }
    seqs <- biomaRt::getSequence(
      id = unique(meta$ensembl_transcript_id),
      type = "ensembl_transcript_id",
      seqType = "peptide",
      mart = mart
    )
    seqs <- as.data.frame(seqs, stringsAsFactors = FALSE)
    if (!nrow(seqs)) {
      return(data.frame(TID = enst_vec, HUGO = NA_character_, AA = NA_character_, AA_len = NA_integer_, stringsAsFactors = FALSE))
    }
    colnames(seqs)[colnames(seqs) == "peptide"] <- "AA"
    colnames(seqs)[colnames(seqs) == "ensembl_transcript_id"] <- "TID"
    out <- dplyr::inner_join(meta, seqs, by = c("ensembl_transcript_id" = "TID"))
    out$AA <- gsub("[^A-Za-z]", "", as.character(out$AA))
    out$AA_len <- nchar(out$AA)
    out <- out[out$AA_len > 0, , drop = FALSE]
    out %>% dplyr::transmute(TID = ensembl_transcript_id, HUGO = hgnc_symbol, AA, AA_len)
  }
  
  .ffp_alpha_suffix <- function(n) {
    if (n <= 0) return("")
    letters <- LETTERS
    s <- ""
    while (n > 0) {
      r <- (n - 1) %% 26 + 1
      s <- paste0(letters[r], s)
      n <- (n - 1) %/% 26
    }
    s
  }
  
  .ffp_split_tids <- function(x) {
    x <- as.character(x)
    x[is.na(x)] <- ""
    x <- trimws(x)
    if (!nzchar(x)) return(character(0))
    parts <- unlist(strsplit(x, "[,，\\s]+"))
    parts <- trimws(parts)
    parts <- parts[nzchar(parts)]
    .ffp_norm_ens_id(parts)
  }
  
  # ---- Manual AA (Export-only) parser: KEY<TAB>AA where KEY can be HUGO or ENST ----
  .ffp_parse_manual_aa_export <- function(txt) {
    txt <- as.character(txt)
    if (is.null(txt) || !nzchar(txt)) {
      return(data.frame(Key = character(0), KeyType = character(0), AA = character(0), AA_len = integer(0), stringsAsFactors = FALSE))
    }
    lines <- unlist(strsplit(txt, "\\r?\\n"))
    lines <- lines[nzchar(trimws(lines))]
    if (!length(lines)) {
      return(data.frame(Key = character(0), KeyType = character(0), AA = character(0), AA_len = integer(0), stringsAsFactors = FALSE))
    }
    
    spl <- lapply(lines, function(li) {
      li <- trimws(li)
      li <- gsub(",", "\t", li)
      toks <- unlist(strsplit(li, "\\t+|\\s+"))
      toks <- toks[nzchar(toks)]
      if (length(toks) < 2) return(NULL)
      
      key <- toks[1]
      aa <- paste0(toks[-1], collapse = "")
      aa <- toupper(gsub("[^A-Za-z]", "", aa))
      if (!nzchar(key) || !nzchar(aa)) return(NULL)
      
      key_trim <- trimws(key)
      key_norm <- .ffp_norm_ens_id(key_trim)
      
      keytype <- ifelse(grepl("^ENST\\d+", toupper(key_norm)), "TID", "HUGO")
      if (keytype == "HUGO") {
        key_norm <- key_trim
      }
      
      data.frame(Key = key_norm, KeyType = keytype, AA = aa, AA_len = nchar(aa), stringsAsFactors = FALSE)
    })
    
    out <- dplyr::bind_rows(spl)
    if (!nrow(out)) return(out)
    
    out$Key <- trimws(as.character(out$Key))
    out <- out[!is.na(out$Key) & nzchar(out$Key) & !is.na(out$AA) & nzchar(out$AA), , drop = FALSE]
    
    out %>%
      dplyr::group_by(KeyType, Key) %>%
      dplyr::arrange(dplyr::desc(AA_len)) %>%
      dplyr::slice(1) %>%
      dplyr::ungroup()
  }
  
  # apply manual overrides to FASTA entries
  .ffp_apply_manual_overrides <- function(fe, man_df, respect_user_replaced = FALSE) {
    if (is.null(fe) || !nrow(fe) || is.null(man_df) || !nrow(man_df)) {
      return(list(fe = fe, overridden_genes = character(0), overridden_headers = character(0), unmatched = character(0), applied_n = 0L))
    }
    
    fe2 <- fe
    fe2$TranscriptID_norm <- ifelse(!is.na(fe2$TranscriptID) & nzchar(fe2$TranscriptID), .ffp_norm_ens_id(fe2$TranscriptID), NA_character_)
    fe2$Gene_up <- toupper(trimws(as.character(fe2$Gene)))
    fe2$AA <- ifelse(!is.na(fe2$AA) & nzchar(fe2$AA), toupper(gsub("[^A-Za-z]", "", fe2$AA)), fe2$AA)
    
    overridden_genes <- character(0)
    overridden_headers <- character(0)
    unmatched <- character(0)
    applied_n <- 0L
    
    for (k in seq_len(nrow(man_df))) {
      key <- as.character(man_df$Key[k])
      keytype <- as.character(man_df$KeyType[k])
      aa_new <- as.character(man_df$AA[k])
      aa_len_new <- as.integer(man_df$AA_len[k])
      
      idx <- integer(0)
      
      if (identical(keytype, "TID")) {
        key_norm <- .ffp_norm_ens_id(key)
        idx <- which(!is.na(fe2$TranscriptID_norm) & fe2$TranscriptID_norm == key_norm)
      } else {
        key_up <- toupper(trimws(key))
        idx <- which(
          (is.na(fe2$TranscriptID) | !nzchar(fe2$TranscriptID)) &
            !is.na(fe2$Gene_up) & fe2$Gene_up == key_up
        )
      }
      
      if (!length(idx)) {
        unmatched <- c(unmatched, paste0(keytype, ":", key))
        next
      }
      
      if (isTRUE(respect_user_replaced) && "AA_source" %in% names(fe2)) {
        idx <- idx[!(fe2$AA_source[idx] %in% "user_replaced")]
        if (!length(idx)) next
      }
      
      had <- !is.na(fe2$AA[idx]) & nzchar(fe2$AA[idx])
      diff <- had & (fe2$AA[idx] != aa_new)
      if (any(diff)) {
        overridden_genes <- c(overridden_genes, unique(fe2$Gene[idx][diff]))
        overridden_headers <- c(overridden_headers, unique(fe2$Header[idx][diff]))
      }
      
      fe2$AA[idx] <- aa_new
      fe2$AA_len[idx] <- aa_len_new
      fe2$AA_source[idx] <- "manual_export"
      applied_n <- applied_n + length(idx)
    }
    
    fe2$TranscriptID_norm <- NULL
    fe2$Gene_up <- NULL
    
    overridden_genes <- unique(overridden_genes[!is.na(overridden_genes) & nzchar(overridden_genes)])
    overridden_headers <- unique(overridden_headers[!is.na(overridden_headers) & nzchar(overridden_headers)])
    unmatched <- unique(unmatched[!is.na(unmatched) & nzchar(unmatched)])
    
    list(fe = fe2, overridden_genes = overridden_genes, overridden_headers = overridden_headers, unmatched = unmatched, applied_n = applied_n)
  }
  
  # ---------------- NetMHC command generator helpers (NEW) ----------------
  .ffp_parse_alleles <- function(txt) {
    txt <- as.character(txt %||% "")
    if (!nzchar(trimws(txt))) return(character(0))
    
    # only English comma allowed as delimiter
    parts <- unlist(strsplit(txt, "\\s*,\\s*"))
    parts <- trimws(parts)
    parts <- parts[nzchar(parts)]
    parts
  }
  
  .ffp_shell_quote<-function(x){x<-as.character(x%||%"");x<-gsub('"','\\"',x,fixed=TRUE);paste0('"',x,'"')}
  
  .ffp_path_dirname_safe <- function(p) {
    p <- as.character(p %||% "")
    if (!nzchar(trimws(p))) return("")
    # R dirname works for / and \ on Windows
    d <- tryCatch(dirname(p), error = function(e) "")
    if (is.na(d)) d <- ""
    d
  }
  
  .ffp_path_basename_safe <- function(p) {
    p <- as.character(p %||% "")
    if (!nzchar(trimws(p))) return("")
    b <- tryCatch(basename(p), error = function(e) "")
    if (is.na(b)) b <- ""
    b
  }
  
  .ffp_norm_path_like <- function(p) {
    # best-effort normalize for comparison; do NOT require file exists
    p <- as.character(p %||% "")
    p <- trimws(p)
    if (!nzchar(p)) return("")
    p <- gsub("\\\\", "/", p)
    p <- gsub("/+$", "", p)
    p
  }
  
  .ffp_build_netmhc_cmds <- function(
    class = c("I", "II"),
    fasta_path,
    alleles_text,
    workdir,
    out_name,
    len_I = c("8","9","10","11"),
    len_II = as.character(13:25)
  ) {
    class <- match.arg(class)
    
    fasta_path <- trimws(as.character(fasta_path %||% ""))
    workdir <- trimws(as.character(workdir %||% ""))
    out_name <- trimws(as.character(out_name %||% ""))
    
    if (!nzchar(out_name)) out_name <- ifelse(class == "I", "ClassI_out", "ClassII_out")
    
    als <- .ffp_parse_alleles(alleles_text)
    als_str <- paste(als, collapse = ",")
    
    fasta_dir <- .ffp_path_dirname_safe(fasta_path)
    fasta_base <- .ffp_path_basename_safe(fasta_path)
    
    wd <- workdir
    if (!nzchar(wd)) wd <- fasta_dir
    if (!nzchar(wd)) wd <- "."
    
    # decide -f argument: basename if running in same folder, else full path
    same_dir <- nzchar(fasta_dir) && nzchar(wd) && identical(.ffp_norm_path_like(fasta_dir), .ffp_norm_path_like(wd))
    f_arg <- if (same_dir && nzchar(fasta_base)) fasta_base else fasta_path
    if (!nzchar(f_arg)) f_arg <- "<PASTE_FASTA_PATH_HERE>"
    
    lines <- c(
      paste0("cd ", .ffp_shell_quote(wd)),
      paste0('ALLELES=', .ffp_shell_quote(als_str))
    )
    
    if (class == "I") {
      lens <- len_I
      lens <- as.character(lens %||% character(0))
      lens <- lens[nzchar(lens)]
      if (!length(lens)) lens <- c("8","9","10","11")
      l_arg <- paste(lens, collapse = ",")
      
      lines <- c(
        lines,
        paste0(
          "netMHCpan -f ", .ffp_shell_quote(f_arg),
          " -a \"$ALLELES\"",
          " -l ", l_arg,
          " -xls -xlsfile ", .ffp_shell_quote(paste0(out_name, ".xls")),
          " > ", .ffp_shell_quote(paste0(out_name, ".txt"))
        )
      )
    } else {
      lens <- len_II
      lens <- as.character(lens %||% character(0))
      lens <- lens[nzchar(lens)]
      if (!length(lens)) lens <- as.character(13:25)
      
      # for-loop, same style as user's example
      lines <- c(
        lines,
        paste0("for L in ", paste(lens, collapse = " "), "; do"),
        paste0(
          "  netMHCIIpan -f ", .ffp_shell_quote(f_arg),
          " -a \"$ALLELES\"",
          " -length $L",
          " -xls -xlsfile ", .ffp_shell_quote(paste0(out_name, "_len${L}.xls")),
          " > ", .ffp_shell_quote(paste0(out_name, "_len${L}.txt")),
          ";"
        ),
        "done"
      )
    }
    
    paste(lines, collapse = "\n")
  }
  
  # ---- UI ----
  ui <- shiny::navbarPage(
    title = "FASTA for prediction (pan input)",
    header = shiny::tags$head(
      shiny::tags$style(shiny::HTML("
        .ffp-example-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 12px;
          padding: 8px 0;
          border-bottom: 1px solid #e6e6e6;
        }
        .ffp-example-row:last-child { border-bottom: none; }
        .ffp-example-text { line-height: 1.25; }
      "))
    ),
    shiny::tabPanel(
      "1) Inputs",
      shiny::fluidRow(
        shiny::column(
          6,
          shiny::h4("What do you have?"),
          shiny::tags$p("Please select the input types you have available. You may also download example templates for quick testing."),
          shiny::checkboxGroupInput(
            "have_inputs",
            label = NULL,
            choices = c(
              "RSEM/TPM file (xlsx/xls/csv/tsv/txt/*.rsem.genes.results)" = "tpm",
              "Gene list (HUGO/ENSG)" = "genelist",
              "Gene + Transcript ID (Gene/HUGO + ENST)" = "enst",
              "Protein list (HUGO/AA)" = "protein"
            )
          ),
          shiny::tags$hr(),
          shiny::h5("Download example templates"),
          
          # ---- Example template download: direct static link if Examples exists (NEW) ----
          shiny::tags$div(
            class = "ffp-example-row",
            shiny::tags$div(class = "ffp-example-text", "RSEM/TPM file (TPM.xlsx)"),
            if (have_examples_dir && file.exists(.ffp_examples_abs[["TPM.xlsx"]])) {
              shiny::tags$a(
                href = "tapas_examples/TPM.xlsx",
                class = "btn btn-default",
                download = "TPM.xlsx",
                shiny::icon("download"), " Download"
              )
            } else {
              shiny::downloadButton("dl_ex_tpm", "Download")
            }
          ),
          shiny::tags$div(
            class = "ffp-example-row",
            shiny::tags$div(class = "ffp-example-text", "Gene list (Gene_List.xlsx)"),
            if (have_examples_dir && file.exists(.ffp_examples_abs[["Gene_List.xlsx"]])) {
              shiny::tags$a(
                href = "tapas_examples/Gene_List.xlsx",
                class = "btn btn-default",
                download = "Gene_List.xlsx",
                shiny::icon("download"), " Download"
              )
            } else {
              shiny::downloadButton("dl_ex_genelist", "Download")
            }
          ),
          shiny::tags$div(
            class = "ffp-example-row",
            shiny::tags$div(class = "ffp-example-text", "Gene + Transcript ID (Gene_List_Transcript_ID.xlsx)"),
            if (have_examples_dir && file.exists(.ffp_examples_abs[["Gene_List_Transcript_ID.xlsx"]])) {
              shiny::tags$a(
                href = "tapas_examples/Gene_List_Transcript_ID.xlsx",
                class = "btn btn-default",
                download = "Gene_List_Transcript_ID.xlsx",
                shiny::icon("download"), " Download"
              )
            } else {
              shiny::downloadButton("dl_ex_enst", "Download")
            }
          ),
          shiny::tags$div(
            class = "ffp-example-row",
            shiny::tags$div(class = "ffp-example-text", "Protein list (Protein_List.xlsx)"),
            if (have_examples_dir && file.exists(.ffp_examples_abs[["Protein_List.xlsx"]])) {
              shiny::tags$a(
                href = "tapas_examples/Protein_List.xlsx",
                class = "btn btn-default",
                download = "Protein_List.xlsx",
                shiny::icon("download"), " Download"
              )
            } else {
              shiny::downloadButton("dl_ex_protein", "Download")
            }
          ),
          shiny::tags$hr(),
          
          shiny::h4("Upload files"),
          shiny::conditionalPanel(
            condition = "input.have_inputs && input.have_inputs.indexOf('tpm') >= 0",
            shiny::wellPanel(
              shiny::h5("RSEM/TPM file"),
              shiny::fileInput(
                "tpm_file",
                "Choose file",
                accept = c(".xlsx", ".xls", ".csv", ".tsv", ".txt", ".results", ".genes.results")
              ),
              shiny::textInput("tpm_path", "...or provide a path", value = ""),
              shiny::selectInput("tpm_build", "If using ENSG, genome build", choices = c("GRCh37", "GRCh38"), selected = "GRCh38"),
              shiny::actionButton("load_tpm", "Load RSEM/TPM"),
              shiny::uiOutput("tpm_col_ui"),
              DT::dataTableOutput("tpm_preview")
            )
          ),
          shiny::conditionalPanel(
            condition = "input.have_inputs && input.have_inputs.indexOf('genelist') >= 0",
            shiny::wellPanel(
              shiny::h5("Gene list (HUGO/ENSG)"),
              shiny::fileInput("gl_file", "Choose xlsx/xls/csv/tsv", accept = c(".xlsx", ".xls", ".csv", ".tsv", ".txt")),
              shiny::selectInput("gl_build", "If looking up ENSG, genome build", choices = c("GRCh37", "GRCh38"), selected = "GRCh38"),
              shiny::checkboxInput("gl_lookup_ensg", "If ENSG column is missing, look up ENSG from Ensembl", value = TRUE),
              shiny::actionButton("load_gl", "Load gene list"),
              shiny::uiOutput("gl_col_ui"),
              DT::dataTableOutput("gl_preview")
            )
          ),
          shiny::conditionalPanel(
            condition = "input.have_inputs && input.have_inputs.indexOf('enst') >= 0",
            shiny::wellPanel(
              shiny::h5("Gene + Transcript IDs (ENST)"),
              shiny::fileInput("enst_file", "Choose xlsx/xls/csv/tsv", accept = c(".xlsx", ".xls", ".csv", ".tsv", ".txt")),
              shiny::selectInput("enst_build", "ENST source build", choices = c("GRCh37", "GRCh38"), selected = "GRCh38"),
              shiny::actionButton("load_enst", "Load transcript list"),
              shiny::uiOutput("enst_col_ui"),
              DT::dataTableOutput("enst_preview")
            )
          ),
          shiny::conditionalPanel(
            condition = "input.have_inputs && input.have_inputs.indexOf('protein') >= 0",
            shiny::wellPanel(
              shiny::h5("Protein list (HUGO/AA)"),
              shiny::fileInput("prot_file", "Choose xlsx/xls/csv/tsv", accept = c(".xlsx", ".xls", ".csv", ".tsv", ".txt")),
              shiny::actionButton("load_prot", "Load protein list"),
              shiny::uiOutput("prot_col_ui"),
              DT::dataTableOutput("prot_preview")
            )
          )
        )
      )
    ),
    shiny::tabPanel(
      "2) 3CA",
      shiny::fluidRow(
        shiny::column(
          5,
          shiny::checkboxInput("use_3ca", "Use 3CA malignant markers", value = TRUE),
          shiny::conditionalPanel(
            condition = "input.use_3ca == true",
            shiny::wellPanel(
              shiny::h5("3CA xlsx"),
              shiny::fileInput("threeca_file", "Choose 3CA xlsx", accept = c(".xlsx", ".xls")),
              shiny::textInput("threeca_path", "...or use a path", value = threeca_default_path),
              shiny::actionButton("load_threeca", "Load 3CA"),
              shiny::uiOutput("threeca_sheet_ui"),
              shiny::tags$small("Expected columns: Gene, Specifity/Specificity, Sensitivity, CombinedSort")
            )
          )
        ),
        shiny::column(7, DT::dataTableOutput("threeca_preview"))
      )
    ),
    shiny::tabPanel(
      "3) Review & Filter",
      shiny::fluidRow(
        shiny::column(
          4,
          shiny::h4("Sequence fetching policy"),
          shiny::tags$p("Proteins are fetched ONLY at Export, and only for the selected subset."),
          shiny::checkboxInput("fetch_missing_at_export", "Fetch missing sequences at Export (selected subset only)", value = TRUE),
          shiny::checkboxInput("use_canonical", "Use canonical sequence if not provided (GRCh38 only)", value = TRUE),
          shiny::tags$small("If fetching is disabled, entries without AA (protein list/manual/canonical) will remain Not found."),
          shiny::tags$hr(),
          shiny::h4("Include/Exclude by source-category"),
          shiny::selectInput("inc_exc_mode", "Mode", choices = c("Include only" = "include", "Exclude" = "exclude"), selected = "include"),
          shiny::uiOutput("status_filter_ui"),
          shiny::tags$hr(),
          shiny::h4("Thresholds (keep >=)"),
          shiny::uiOutput("threshold_ui"),
          shiny::tags$hr(),
          shiny::h4("Plot controls"),
          shiny::radioButtons(
            "plot_scope",
            "Plot scope (applied only when clicking the button below):",
            choices = c(
              "All genes (current view)" = "all_view",
              "Ticked genes (snapshot)" = "ticked_snapshot"
            ),
            selected = "all_view"
          ),
          shiny::actionButton("apply_plot_scope", "Plot / Apply scope"),
          shiny::tags$hr(),
          shiny::numericInput("tpm_axis_max", "Set a manual maximum for TPM axis", value = NA, min = 0, step = 1),
          shiny::tags$small("Notes: Missing TPM/3CA values are plotted as 0 but kept as NA in the table."),
          shiny::tags$hr(),
          shiny::actionButton("reset_plots", "Reset plots (autoscale)")
        ),
        shiny::column(
          8,
          shiny::h4("Gene table (tick genes for export)"),
          shiny::checkboxInput("show_only_ticked", "Show only ticked genes", value = FALSE),
          DT::dataTableOutput("gene_table"),
          shiny::tags$hr(),
          shiny::h4("Plots (red = kept for export; dashed = thresholds)"),
          plotly::plotlyOutput("plot_main", height = "420px"),
          plotly::plotlyOutput("plot_secondary", height = "420px"),
          plotly::plotlyOutput("plot_third", height = "420px")
        )
      )
    ),
    shiny::tabPanel(
      "4) Export",
      shiny::fluidRow(
        shiny::column(
          6,
          shiny::h4("FASTA entries (editable before export)"),
          shiny::tags$small("Missing sequences are fetched only at Export, and only for the selected subset."),
          DT::dataTableOutput("fasta_edit_table"),
          shiny::tags$hr(),
          
          shiny::h4("Manual AA overrides (optional; Export-only)"),
          shiny::tags$small("Paste: KEY<TAB>AA (KEY can be HUGO or ENST). HUGO applies only to gene-level rows (no TranscriptID); ENST applies to transcript rows. This can override existing AA."),
          shiny::textAreaInput("manual_aa_export", NULL, value = "", rows = 6),
          shiny::actionButton("apply_manual_aa_export", "Apply manual AA to FASTA entries"),
          shiny::tags$hr(),
          
          shiny::textInput("out_prefix", "Output prefix", value = "pan_input"),
          shiny::actionButton("refresh_fasta_entries", "Refresh FASTA entries from current selection"),
          shiny::actionButton("write_outputs", "Generate outputs (fetch subset sequences if needed)"),
          shiny::tags$hr(),
          shiny::verbatimTextOutput("export_status"),
          shiny::downloadButton("dl_fasta", "Download FASTA"),
          shiny::downloadButton("dl_xlsx", "Download annotation XLSX"),
          shiny::downloadButton("dl_tpm_xlsx", "Download TPM XLSX (gene + header/TID)"),
          
          # direct links fallback (NEW)
          shiny::uiOutput("direct_export_links"),
          
          # ---------------- NetMHCpan / NetMHCIIpan command generator (NEW) ----------------
          shiny::tags$hr(),
          shiny::h4("Generate terminal commands for NetMHCpan / NetMHCIIpan"),
          shiny::wellPanel(
            shiny::tags$small("For Windows: Use WSL path（e.g. /mnt/c/...）or adjust manually, Use Complete Path and Include Filename.fasta"),
            shiny::tags$br(),
            shiny::actionButton("nm_use_exported_fasta", "Use exported FASTA path (auto-fill)"),
            shiny::tags$br(), shiny::tags$br(),
            
            shiny::textInput("nm_fasta_path", "Paste FASTA path", value = ""),
            shiny::radioButtons(
              "nm_class",
              "Prediction class",
              choices = c("Class I" = "I", "Class II" = "II"),
              selected = "I",
              inline = TRUE
            ),
            
            shiny::uiOutput("nm_examples_ui"),
            
            shiny::textAreaInput(
              "nm_alleles",
              "Paste HLA alleles (comma-separated), no space",
              value = "",
              rows = 4,
              placeholder = "e.g. HLA-A02:01,HLA-A03:01"
            ),
            
            shiny::textInput("nm_workdir", "Output folder / working directory (cd here; leave blank = FASTA folder)", value = ""),
            shiny::textInput("nm_outname", "Output base name (without extension)", value = "Pt108_ClassI_TAA_out_full_2"),
            
            shiny::conditionalPanel(
              condition = "input.nm_class == 'I'",
              shiny::checkboxGroupInput(
                "nm_len_I",
                "Peptide lengths (-l)",
                choices = as.character(c(8, 9, 10, 11)),
                selected = as.character(c(8, 9, 10, 11)),
                inline = TRUE
              )
            ),
            shiny::conditionalPanel(
              condition = "input.nm_class == 'II'",
              shiny::tags$div(
                shiny::tags$label("Peptide lengths (-length): 13-25"),
                shiny::checkboxGroupInput(
                  "nm_len_II",
                  NULL,
                  choices = as.character(13:25),
                  selected = as.character(13:25),
                  inline = TRUE
                )
              )
            ),
            
            shiny::actionButton("nm_gen_cmd", "Generate Terminal Commands for NetMHCpan"),
            shiny::tags$hr(),
            shiny::tags$small("Copy the block below into terminal:"),
            shiny::verbatimTextOutput("nm_cmd_out")
          )
        ),
        shiny::column(
          6,
          shiny::h4("Current selection summary"),
          shiny::verbatimTextOutput("sel_summary")
        )
      )
    )
  )
  
  server <- function(input, output, session) {
    rv <- shiny::reactiveValues(
      tpm_raw = NULL,
      tpm_df = NULL,
      gl_raw = NULL,
      gl_df = NULL,
      enst_raw = NULL,
      enst_df = NULL,
      prot_raw = NULL,
      prot_df = NULL,
      threeca_path = NULL,
      threeca_sheets = NULL,
      threeca_df = NULL,
      cancer_sheet = NULL,
      
      manual_aa_export_map = NULL,
      
      keep_overrides = NULL,
      plot_genes = NULL,
      plot_scope_applied = NULL,
      fasta_entries = NULL,
      export_paths = NULL,
      export_fasta = NULL,
      export_xlsx = NULL,
      export_tpm_xlsx = NULL,  # NEW
      
      tpm_axis_max_user_set = FALSE,
      axis_auto_updating = FALSE,
      
      # NEW: netMHC command output
      nm_cmd = NULL
    )
    
    # ---------------- Example downloads (fallback downloadHandler kept) ----------------
    output$dl_ex_tpm <- shiny::downloadHandler(
      filename = function() "TPM.xlsx",
      content = function(file) {
        .ffp_download_example(kind = "tpm", filename = "TPM.xlsx", file = file)
      }
    )
    
    output$dl_ex_genelist <- shiny::downloadHandler(
      filename = function() "Gene_List.xlsx",
      content = function(file) {
        .ffp_download_example(kind = "genelist", filename = "Gene_List.xlsx", file = file)
      }
    )
    
    output$dl_ex_enst <- shiny::downloadHandler(
      filename = function() "Gene_List_Transcript_ID.xlsx",
      content = function(file) {
        .ffp_download_example(kind = "enst", filename = "Gene_List_Transcript_ID.xlsx", file = file)
      }
    )
    
    output$dl_ex_protein <- shiny::downloadHandler(
      filename = function() "Protein_List.xlsx",
      content = function(file) {
        .ffp_download_example(kind = "protein", filename = "Protein_List.xlsx", file = file)
      }
    )
    
    # ---------------- TPM/RSEM ----------------
    output$tpm_col_ui <- shiny::renderUI({
      df <- rv$tpm_raw
      if (is.null(df)) return(NULL)
      cols <- names(df)
      hugo_guess <- .ffp_pick_col(df, c("HUGO", "Gene", "SYMBOL", "HGNC", "gene_name", "hgnc_symbol", "gene"))
      ensg_guess <- .ffp_pick_col(df, c("ENSG", "ensembl_gene_id", "gene_id", "geneid", "ensg"))
      tpm_guess  <- .ffp_pick_col(df, c("TPM", "tpm", "TPM_gene", "TPM_value", "TPM..", "TPM."))
      shiny::tagList(
        shiny::selectInput("tpm_hugo_col", "HUGO/Gene symbol column (optional)", choices = c("(none)" = "", cols), selected = ifelse(is.na(hugo_guess), "", hugo_guess)),
        shiny::selectInput("tpm_ensg_col", "ENSG column (optional)", choices = c("(none)" = "", cols), selected = ifelse(is.na(ensg_guess), "", ensg_guess)),
        shiny::selectInput("tpm_val_col", "TPM column", choices = cols, selected = ifelse(is.na(tpm_guess), cols[min(2, length(cols))], tpm_guess)),
        shiny::actionButton("apply_tpm_cols", "Apply columns")
      )
    })
    
    shiny::observeEvent(input$load_tpm, {
      path <- NULL
      if (!is.null(input$tpm_file) && !is.null(input$tpm_file$datapath)) path <- input$tpm_file$datapath
      if (is.null(path) || !nzchar(path)) path <- input$tpm_path
      if (is.null(path) || !nzchar(path) || !file.exists(path)) {
        shiny::showNotification("TPM/RSEM file not found.", type = "error")
        rv$tpm_raw <- NULL
        return(NULL)
      }
      df <- .ffp_read_table_any(path)
      if (is.null(df) || !nrow(df)) {
        shiny::showNotification("Failed to read TPM/RSEM file (unsupported format or empty).", type = "error")
        rv$tpm_raw <- NULL
        return(NULL)
      }
      rv$tpm_raw <- df
      shiny::showNotification("TPM/RSEM loaded. Choose columns and click Apply.", type = "message")
    })
    
    shiny::observeEvent(input$apply_tpm_cols, {
      req(rv$tpm_raw)
      df <- rv$tpm_raw
      hugo_col <- input$tpm_hugo_col %||% ""
      ensg_col <- input$tpm_ensg_col %||% ""
      tpm_col  <- input$tpm_val_col
      
      out <- data.frame(
        HUGO = if (nzchar(hugo_col)) trimws(as.character(df[[hugo_col]])) else NA_character_,
        ENSG = if (nzchar(ensg_col)) .ffp_norm_ens_id(df[[ensg_col]]) else NA_character_,
        TPM  = .ffp_safe_num(df[[tpm_col]]),
        stringsAsFactors = FALSE
      )
      out$HUGO[out$HUGO == ""] <- NA_character_
      out$ENSG[out$ENSG == ""] <- NA_character_
      
      if (!nzchar(ensg_col) && nzchar(hugo_col)) {
        looks_ensg <- grepl("^ENSG\\d+", out$HUGO %||% "")
        if (any(looks_ensg, na.rm = TRUE) && all(is.na(out$ENSG))) {
          out$ENSG <- out$HUGO
          out$HUGO <- NA_character_
        }
      }
      
      if (all(is.na(out$HUGO)) && any(!is.na(out$ENSG))) {
        map <- .ffp_map_ensg_to_hugo(out$ENSG, build = input$tpm_build)
        out <- dplyr::left_join(out, map, by = "ENSG")
        out$HUGO <- dplyr::coalesce(out$HUGO.x, out$HUGO.y)
        out$HUGO.x <- NULL; out$HUGO.y <- NULL
      }
      
      out <- out %>%
        dplyr::filter(!is.na(HUGO) & nzchar(HUGO)) %>%
        dplyr::group_by(HUGO) %>%
        dplyr::summarise(
          TPM  = suppressWarnings(max(TPM, na.rm = TRUE)),
          ENSG = dplyr::first(ENSG[!is.na(ENSG) & nzchar(ENSG)]),
          .groups = "drop"
        )
      
      out$TPM[!is.finite(out$TPM)] <- NA_real_
      
      rv$tpm_df <- out
      shiny::showNotification("TPM/RSEM columns applied (no sequence fetch).", type = "message")
    })
    
    output$tpm_preview <- DT::renderDataTable({
      df <- rv$tpm_df
      if (is.null(df)) df <- rv$tpm_raw
      if (is.null(df)) return(DT::datatable(data.frame()))
      DT::datatable(utils::head(df, 50), options = list(pageLength = 10, scrollX = TRUE))
    })
    
    # ---------------- Gene list ----------------
    output$gl_col_ui <- shiny::renderUI({
      df <- rv$gl_raw
      if (is.null(df)) return(NULL)
      cols <- names(df)
      hugo_guess <- .ffp_pick_col(df, c("HUGO", "Gene", "SYMBOL", "HGNC", "hugo", "gene"))
      ensg_guess <- .ffp_pick_col(df, c("ENSG", "ensembl", "ensembl_gene_id", "gene_id"))
      shiny::tagList(
        shiny::selectInput("gl_hugo_col", "HUGO/Gene column", choices = cols, selected = ifelse(is.na(hugo_guess), cols[1], hugo_guess)),
        shiny::selectInput("gl_ensg_col", "ENSG column (optional)", choices = c("(none)" = "", cols), selected = ifelse(is.na(ensg_guess), "", ensg_guess)),
        shiny::actionButton("apply_gl_cols", "Apply columns")
      )
    })
    
    shiny::observeEvent(input$load_gl, {
      req(input$gl_file)
      df <- .ffp_read_table_any(input$gl_file$datapath)
      if (is.null(df) || !nrow(df)) {
        shiny::showNotification("Failed to read gene list.", type = "error")
        rv$gl_raw <- NULL
        return(NULL)
      }
      rv$gl_raw <- df
      shiny::showNotification("Gene list loaded. Choose columns and click Apply.", type = "message")
    })
    
    shiny::observeEvent(input$apply_gl_cols, {
      req(rv$gl_raw)
      df <- rv$gl_raw
      hugo_col <- input$gl_hugo_col
      ensg_col <- input$gl_ensg_col %||% ""
      
      out <- data.frame(
        HUGO = trimws(as.character(df[[hugo_col]])),
        ENSG = if (nzchar(ensg_col)) .ffp_norm_ens_id(df[[ensg_col]]) else NA_character_,
        stringsAsFactors = FALSE
      )
      out$HUGO[out$HUGO == ""] <- NA_character_
      out$ENSG[out$ENSG == ""] <- NA_character_
      out <- out[!is.na(out$HUGO) & nzchar(out$HUGO), , drop = FALSE]
      out <- out %>% dplyr::distinct(HUGO, ENSG)
      
      if (isTRUE(input$gl_lookup_ensg) && (!nzchar(ensg_col) || all(is.na(out$ENSG)))) {
        map <- .ffp_map_hugo_to_ensg(out$HUGO, build = input$gl_build)
        out <- dplyr::left_join(out, map, by = "HUGO")
        out$ENSG <- dplyr::coalesce(out$ENSG.x, out$ENSG.y)
        out$ENSG.x <- NULL; out$ENSG.y <- NULL
      }
      
      rv$gl_df <- out
      shiny::showNotification("Gene list columns applied.", type = "message")
    })
    
    output$gl_preview <- DT::renderDataTable({
      df <- rv$gl_df
      if (is.null(df)) df <- rv$gl_raw
      if (is.null(df)) return(DT::datatable(data.frame()))
      DT::datatable(utils::head(df, 50), options = list(pageLength = 10, scrollX = TRUE))
    })
    
    # ---------------- ENST list (no fetch here) ----------------
    output$enst_col_ui <- shiny::renderUI({
      df <- rv$enst_raw
      if (is.null(df)) return(NULL)
      cols <- names(df)
      gene_guess <- .ffp_pick_col(df, c("HUGO", "Gene", "SYMBOL", "HGNC", "gene"))
      tid_guess  <- .ffp_pick_col(df, c("ENST", "TID", "TranscriptID", "transcript_id", "Annotation_Transcript", "tid"))
      shiny::tagList(
        shiny::selectInput("enst_gene_col", "Gene/HUGO column", choices = cols, selected = ifelse(is.na(gene_guess), cols[1], gene_guess)),
        shiny::selectInput("enst_tid_col", "Transcript ID column (ENST)", choices = cols, selected = ifelse(is.na(tid_guess), cols[min(2, length(cols))], tid_guess)),
        shiny::actionButton("apply_enst_cols", "Apply columns (split multi-TIDs)")
      )
    })
    
    shiny::observeEvent(input$load_enst, {
      req(input$enst_file)
      df <- .ffp_read_table_any(input$enst_file$datapath)
      if (is.null(df) || !nrow(df)) {
        shiny::showNotification("Failed to read transcript list.", type = "error")
        rv$enst_raw <- NULL
        return(NULL)
      }
      rv$enst_raw <- df
      shiny::showNotification("Transcript list loaded. Choose columns and click Apply.", type = "message")
    })
    
    shiny::observeEvent(input$apply_enst_cols, {
      req(rv$enst_raw)
      df <- rv$enst_raw
      gene_col <- input$enst_gene_col
      tid_col  <- input$enst_tid_col
      
      gene_vec <- trimws(as.character(df[[gene_col]]))
      tid_vec  <- as.character(df[[tid_col]])
      
      long <- lapply(seq_along(gene_vec), function(i) {
        g <- gene_vec[i]
        if (is.na(g) || !nzchar(g)) return(NULL)
        tids <- .ffp_split_tids(tid_vec[i])
        tids <- tids[!is.na(tids) & nzchar(tids)]
        if (!length(tids)) return(NULL)
        data.frame(Gene = g, ENST = tids, stringsAsFactors = FALSE)
      })
      out <- dplyr::bind_rows(long)
      if (!nrow(out)) {
        shiny::showNotification("No valid (Gene, ENST) pairs found after splitting.", type = "error")
        rv$enst_df <- NULL
        return(NULL)
      }
      out <- out %>% dplyr::distinct(Gene, ENST)
      
      out <- out %>%
        dplyr::group_by(Gene) %>%
        dplyr::mutate(
          tx_idx = dplyr::row_number(),
          n_tx = dplyr::n(),
          has_multi = n_tx > 1
        ) %>%
        dplyr::ungroup()
      
      out$Alias <- ifelse(
        out$has_multi,
        paste0(out$Gene, "_", vapply(out$tx_idx, .ffp_alpha_suffix, character(1))),
        out$Gene
      )
      
      rv$enst_df <- out[, c("Gene", "ENST", "Alias", "has_multi", "tx_idx", "n_tx")]
      shiny::showNotification("Transcript list parsed (no sequence fetch until Export).", type = "message")
    })
    
    output$enst_preview <- DT::renderDataTable({
      df <- rv$enst_df
      if (is.null(df)) df <- rv$enst_raw
      if (is.null(df)) return(DT::datatable(data.frame()))
      DT::datatable(utils::head(df, 80), options = list(pageLength = 10, scrollX = TRUE))
    })
    
    # ---------------- Protein list ----------------
    output$prot_col_ui <- shiny::renderUI({
      df <- rv$prot_raw
      if (is.null(df)) return(NULL)
      cols <- names(df)
      hugo_guess <- .ffp_pick_col(df, c("HUGO", "Gene", "SYMBOL", "HGNC", "hugo", "gene"))
      aa_guess   <- .ffp_pick_col(df, c("AA", "peptide", "Protein", "Sequence", "Protein_Sequence", "seq"))
      shiny::tagList(
        shiny::selectInput("prot_hugo_col", "HUGO/Gene column", choices = cols, selected = ifelse(is.na(hugo_guess), cols[1], hugo_guess)),
        shiny::selectInput("prot_aa_col", "AA column", choices = cols, selected = ifelse(is.na(aa_guess), cols[min(2, length(cols))], aa_guess)),
        shiny::actionButton("apply_prot_cols", "Apply columns")
      )
    })
    
    shiny::observeEvent(input$load_prot, {
      req(input$prot_file)
      df <- .ffp_read_table_any(input$prot_file$datapath)
      if (is.null(df) || !nrow(df)) {
        shiny::showNotification("Failed to read protein list.", type = "error")
        rv$prot_raw <- NULL
        return(NULL)
      }
      rv$prot_raw <- df
      shiny::showNotification("Protein list loaded. Choose columns and click Apply.", type = "message")
    })
    
    shiny::observeEvent(input$apply_prot_cols, {
      req(rv$prot_raw)
      df <- rv$prot_raw
      out <- data.frame(
        HUGO = trimws(as.character(df[[input$prot_hugo_col]])),
        AA   = toupper(gsub("[^A-Za-z]", "", as.character(df[[input$prot_aa_col]]))),
        stringsAsFactors = FALSE
      )
      out$HUGO[out$HUGO == ""] <- NA_character_
      out$AA[out$AA == ""] <- NA_character_
      out <- out[!is.na(out$HUGO) & nzchar(out$HUGO) & !is.na(out$AA) & nzchar(out$AA), , drop = FALSE]
      out$AA_len <- nchar(out$AA)
      out <- out %>%
        dplyr::group_by(HUGO) %>%
        dplyr::arrange(dplyr::desc(AA_len)) %>%
        dplyr::slice(1) %>%
        dplyr::ungroup() %>%
        dplyr::select(HUGO, AA, AA_len)
      
      rv$prot_df <- out
      shiny::updateCheckboxInput(session, "use_canonical", value = TRUE)
      shiny::showNotification("Protein list applied (longest AA per gene kept).", type = "message")
    })
    
    output$prot_preview <- DT::renderDataTable({
      df <- rv$prot_df
      if (is.null(df)) df <- rv$prot_raw
      if (is.null(df)) return(DT::datatable(data.frame()))
      DT::datatable(utils::head(df, 50), options = list(pageLength = 10, scrollX = TRUE))
    })
    
    # ---------------- 3CA ----------------
    output$threeca_sheet_ui <- shiny::renderUI({
      sheets <- rv$threeca_sheets
      if (is.null(sheets) || !length(sheets)) return(NULL)
      shiny::selectInput("threeca_sheet", "Cancer type (worksheet)", choices = sheets, selected = sheets[1])
    })
    
    shiny::observeEvent(input$load_threeca, {
      path <- NULL
      if (!is.null(input$threeca_file) && !is.null(input$threeca_file$datapath)) path <- input$threeca_file$datapath
      if (is.null(path) || !nzchar(path)) path <- input$threeca_path
      if (is.null(path) || !nzchar(path) || !file.exists(path)) {
        rv$threeca_path <- NULL
        rv$threeca_sheets <- NULL
        rv$threeca_df <- NULL
        shiny::showNotification("3CA file not found.", type = "error")
        return(NULL)
      }
      rv$threeca_path <- path
      rv$threeca_sheets <- readxl::excel_sheets(path)
      shiny::showNotification("3CA loaded. Choose a sheet.", type = "message")
    })
    
    shiny::observeEvent(input$threeca_sheet, {
      req(rv$threeca_path)
      sh <- input$threeca_sheet
      
      df <- as.data.frame(
        readxl::read_excel(rv$threeca_path, sheet = sh, .name_repair = "unique_quiet"),
        stringsAsFactors = FALSE
      )
      
      if (is.null(df) || !nrow(df)) {
        rv$threeca_df <- NULL
        rv$cancer_sheet <- sh
        return(NULL)
      }
      
      names(df) <- trimws(names(df))
      names(df) <- gsub("\\s+", " ", names(df))
      
      if (length(names(df)) >= 1) {
        if (is.na(names(df)[1]) || names(df)[1] == "" || grepl("^\\.\\.+$", names(df)[1])) {
          names(df)[1] <- "Gene"
        }
      }
      
      gene_col <- NULL
      if ("Gene" %in% names(df)) {
        gene_col <- "Gene"
      } else {
        char_cols <- names(df)[vapply(df, function(x) is.character(x) || is.factor(x), logical(1))]
        if (length(char_cols)) gene_col <- char_cols[1] else gene_col <- names(df)[1]
      }
      
      df$Gene <- trimws(as.character(df[[gene_col]]))
      df <- df[!is.na(df$Gene) & nzchar(df$Gene), , drop = FALSE]
      
      nms_low <- tolower(names(df))
      
      spec_idx <- which(grepl("^specif", nms_low))
      df$Specificity <- if (length(spec_idx)) .ffp_safe_num(df[[ spec_idx[1] ]]) else NA_real_
      
      sens_idx <- which(grepl("^sensit", nms_low))
      df$Sensitivity <- if (length(sens_idx)) .ffp_safe_num(df[[ sens_idx[1] ]]) else NA_real_
      
      comb_idx <- which(grepl("combinedsort", nms_low))
      df$CombinedSort <- if (length(comb_idx)) .ffp_safe_num(df[[ comb_idx[1] ]]) else NA_real_
      
      asc_idx <- which(nms_low == "ascending")
      if (!any(is.finite(df$CombinedSort), na.rm = TRUE) && length(asc_idx)) {
        df$CombinedSort <- .ffp_safe_num(df[[ asc_idx[1] ]])
      }
      
      out <- df[, c("Gene", "Specificity", "Sensitivity", "CombinedSort"), drop = FALSE]
      
      rv$threeca_df <- out
      rv$cancer_sheet <- sh
    })
    
    output$threeca_preview <- DT::renderDataTable({
      df <- rv$threeca_df
      if (is.null(df)) return(DT::datatable(data.frame()))
      DT::datatable(utils::head(df, 80), options = list(pageLength = 10, scrollX = TRUE))
    })
    
    # ---------------- Threshold UI ----------------
    output$threshold_ui <- shiny::renderUI({
      base_try <- .ffp_try_read({
        use_3ca <- isTRUE(input$use_3ca)
        threeca <- if (use_3ca) rv$threeca_df else NULL
        tpm <- rv$tpm_df
        gl <- rv$gl_df
        tx <- rv$enst_df
        prot <- rv$prot_df
        
        genes_all <- character(0)
        if (!is.null(gl) && nrow(gl)) genes_all <- union(genes_all, gl$HUGO)
        if (!is.null(tx) && nrow(tx)) genes_all <- union(genes_all, unique(tx$Gene))
        if (!is.null(prot) && nrow(prot)) genes_all <- union(genes_all, prot$HUGO)
        if (!is.null(tpm) && nrow(tpm)) genes_all <- union(genes_all, tpm$HUGO)
        
        genes_3ca <- character(0)
        if (use_3ca && !is.null(threeca) && nrow(threeca) && ("Gene" %in% names(threeca))) {
          genes_3ca <- unique(threeca$Gene)
          genes_3ca <- genes_3ca[!is.na(genes_3ca) & nzchar(genes_3ca)]
        }
        
        genes_all <- sort(unique(c(genes_all, genes_3ca)))
        genes_all <- genes_all[!is.na(genes_all) & nzchar(genes_all)]
        if (!length(genes_all)) return(NULL)
        
        tbl <- data.frame(HUGO = genes_all, stringsAsFactors = FALSE)
        
        if (use_3ca && !is.null(threeca) && nrow(threeca)) {
          threeca2 <- threeca
          names(threeca2)[names(threeca2) == "Gene"] <- "HUGO"
          tbl <- dplyr::left_join(tbl, threeca2, by = "HUGO")
        }
        tbl <- .ffp_ensure_cols(tbl, c("Specificity", "Sensitivity", "CombinedSort"), default_val = NA_real_)
        
        if (!is.null(tpm) && nrow(tpm)) {
          tbl <- dplyr::left_join(tbl, tpm, by = "HUGO")
        } else {
          tbl$TPM <- NA_real_
        }
        tbl
      })
      
      if (is.null(base_try) || !nrow(base_try)) return(shiny::tags$em("Load inputs first."))
      tbl <- base_try
      
      has_tpm <- "TPM" %in% names(tbl) && any(is.finite(tbl$TPM), na.rm = TRUE)
      has_3ca <- isTRUE(input$use_3ca) && any(is.finite(tbl$CombinedSort) | is.finite(tbl$Specificity) | is.finite(tbl$Sensitivity), na.rm = TRUE)
      
      ui_list <- list()
      
      if (has_tpm) {
        mx_obs <- max(tbl$TPM, na.rm = TRUE); mx_obs <- max(1, ceiling(mx_obs))
        
        axis_max <- suppressWarnings(as.numeric(input$tpm_axis_max))
        mx <- if (!is.na(axis_max) && is.finite(axis_max) && axis_max > 0) max(1, ceiling(axis_max)) else mx_obs
        
        stepv <- max(0.1, mx / 200)
        
        cur <- .ffp_input_num(input$thr_tpm_num, 0)
        cur <- max(0, min(cur, mx))
        
        ui_list <- c(ui_list, list(
          shiny::sliderInput("thr_tpm", "TPM", min = 0, max = mx, value = cur, step = stepv),
          shiny::numericInput("thr_tpm_num", "TPM (manual)", value = cur, min = 0, max = mx, step = stepv)
        ))
      }
      
      if (has_3ca) {
        if (any(is.finite(tbl$CombinedSort), na.rm = TRUE)) {
          mx <- max(tbl$CombinedSort, na.rm = TRUE); mx <- max(1, ceiling(mx))
          stepv <- max(0.1, mx / 200)
          
          cur <- .ffp_input_num(input$thr_comb_num, 0)
          cur <- max(0, min(cur, mx))
          
          ui_list <- c(ui_list, list(
            shiny::sliderInput("thr_comb", "3CA_Combined", min = 0, max = mx, value = cur, step = stepv),
            shiny::numericInput("thr_comb_num", "3CA_Combined (manual)", value = cur, min = 0, max = mx, step = stepv)
          ))
        }
        if (any(is.finite(tbl$Specificity), na.rm = TRUE)) {
          mx <- max(tbl$Specificity, na.rm = TRUE); mx <- max(1, ceiling(mx))
          stepv <- max(0.01, mx / 200)
          
          cur <- .ffp_input_num(input$thr_spec_num, 0)
          cur <- max(0, min(cur, mx))
          
          ui_list <- c(ui_list, list(
            shiny::sliderInput("thr_spec", "3CA Specificity", min = 0, max = mx, value = cur, step = stepv),
            shiny::numericInput("thr_spec_num", "Specificity (manual)", value = cur, min = 0, max = mx, step = stepv)
          ))
        }
        if (any(is.finite(tbl$Sensitivity), na.rm = TRUE)) {
          mx <- max(tbl$Sensitivity, na.rm = TRUE); mx <- max(1, ceiling(mx))
          stepv <- max(0.01, mx / 200)
          
          cur <- .ffp_input_num(input$thr_sens_num, 0)
          cur <- max(0, min(cur, mx))
          
          ui_list <- c(ui_list, list(
            shiny::sliderInput("thr_sens", "3CA Sensitivity", min = 0, max = mx, value = cur, step = stepv),
            shiny::numericInput("thr_sens_num", "Sensitivity (manual)", value = cur, min = 0, max = mx, step = stepv)
          ))
        }
      }
      
      if (!length(ui_list)) return(shiny::tags$em("No numeric fields loaded yet."))
      do.call(shiny::tagList, ui_list)
    })
    
    .sync_pair <- function(slider_id, num_id) {
      shiny::observeEvent(input[[slider_id]], {
        if (!is.null(input[[slider_id]]) && !is.null(input[[num_id]]) &&
            !identical(input[[slider_id]], input[[num_id]])) {
          shiny::updateNumericInput(session, num_id, value = input[[slider_id]])
        }
      }, ignoreInit = TRUE)
      
      shiny::observeEvent(input[[num_id]], {
        if (!is.null(input[[num_id]]) && !is.null(input[[slider_id]]) &&
            !identical(input[[num_id]], input[[slider_id]])) {
          shiny::updateSliderInput(session, slider_id, value = input[[num_id]])
        }
      }, ignoreInit = TRUE)
    }
    .sync_pair("thr_tpm", "thr_tpm_num")
    .sync_pair("thr_comb", "thr_comb_num")
    .sync_pair("thr_spec", "thr_spec_num")
    .sync_pair("thr_sens", "thr_sens_num")
    
    # ---------------- TPM axis max auto-update (only if user hasn't manually set it) ----------------
    shiny::observeEvent(input$tpm_axis_max, {
      if (isTRUE(rv$axis_auto_updating)) return(NULL)
      v <- suppressWarnings(as.numeric(input$tpm_axis_max))
      rv$tpm_axis_max_user_set <- !is.na(v) && is.finite(v)
    }, ignoreInit = TRUE)
    
    shiny::observeEvent(rv$tpm_df, {
      df <- rv$tpm_df
      if (is.null(df) || !nrow(df) || !("TPM" %in% names(df))) return(NULL)
      mx <- suppressWarnings(max(df$TPM, na.rm = TRUE))
      if (!is.finite(mx) || is.na(mx)) return(NULL)
      mx <- max(1, ceiling(mx))
      
      cur <- suppressWarnings(as.numeric(input$tpm_axis_max))
      cur_is_set <- !is.na(cur) && is.finite(cur)
      
      if (!isTRUE(rv$tpm_axis_max_user_set) && !cur_is_set) {
        rv$axis_auto_updating <- TRUE
        on.exit({ rv$axis_auto_updating <- FALSE }, add = TRUE)
        shiny::updateNumericInput(session, "tpm_axis_max", value = mx)
      }
    }, ignoreInit = TRUE)
    
    # ---------------- Base gene table (NO peptide fetch) ----------------
    gene_tbl_base <- shiny::reactive({
      use_3ca <- isTRUE(input$use_3ca)
      threeca <- if (use_3ca) rv$threeca_df else NULL
      tpm <- rv$tpm_df
      gl <- rv$gl_df
      tx <- rv$enst_df
      prot <- rv$prot_df
      
      genes_gl   <- character(0)
      genes_tx   <- character(0)
      genes_prot <- character(0)
      genes_tpm  <- character(0)
      
      if (!is.null(gl) && nrow(gl))     genes_gl <- unique(gl$HUGO)
      if (!is.null(tx) && nrow(tx))     genes_tx <- unique(tx$Gene)
      if (!is.null(prot) && nrow(prot)) genes_prot <- unique(prot$HUGO)
      if (!is.null(tpm) && nrow(tpm))   genes_tpm <- unique(tpm$HUGO)
      
      genes_gl <- genes_gl[!is.na(genes_gl) & nzchar(genes_gl)]
      genes_tx <- genes_tx[!is.na(genes_tx) & nzchar(genes_tx)]
      genes_prot <- genes_prot[!is.na(genes_prot) & nzchar(genes_prot)]
      genes_tpm <- genes_tpm[!is.na(genes_tpm) & nzchar(genes_tpm)]
      
      # Gene List = Gene list file OR Gene+Transcript file (union)
      genes_genelist <- sort(unique(c(genes_gl, genes_tx)))
      genes_user_all <- sort(unique(c(genes_genelist, genes_prot, genes_tpm)))
      
      genes_3ca <- character(0)
      if (use_3ca && !is.null(threeca) && nrow(threeca) && ("Gene" %in% names(threeca))) {
        genes_3ca <- unique(threeca$Gene)
        genes_3ca <- genes_3ca[!is.na(genes_3ca) & nzchar(genes_3ca)]
      }
      
      genes_all <- sort(unique(c(genes_user_all, genes_3ca)))
      if (!length(genes_all)) return(NULL)
      
      tbl <- data.frame(HUGO = genes_all, stringsAsFactors = FALSE)
      
      tbl$in_3ca      <- if (use_3ca) tbl$HUGO %in% genes_3ca else FALSE
      tbl$in_rsem     <- tbl$HUGO %in% genes_tpm
      tbl$in_protein  <- tbl$HUGO %in% genes_prot
      tbl$in_genelist <- tbl$HUGO %in% genes_genelist
      tbl$has_tx      <- tbl$HUGO %in% genes_tx
      
      if (use_3ca && !is.null(threeca) && nrow(threeca)) {
        threeca2 <- threeca
        names(threeca2)[names(threeca2) == "Gene"] <- "HUGO"
        tbl <- dplyr::left_join(tbl, threeca2, by = "HUGO")
      }
      tbl <- .ffp_ensure_cols(tbl, c("Specificity", "Sensitivity", "CombinedSort"), default_val = NA_real_)
      tbl$CA_Combined <- tbl$CombinedSort
      
      if (!is.null(tpm) && nrow(tpm)) {
        tbl <- dplyr::left_join(tbl, tpm, by = "HUGO")
      } else {
        tbl$TPM <- NA_real_
        tbl$ENSG <- NA_character_
      }
      
      if (!is.null(gl) && nrow(gl) && ("ENSG" %in% names(gl))) {
        gl2 <- gl %>%
          dplyr::group_by(HUGO) %>%
          dplyr::summarise(ENSG_gl = dplyr::first(ENSG[!is.na(ENSG) & nzchar(ENSG)]), .groups = "drop")
        tbl <- dplyr::left_join(tbl, gl2, by = "HUGO")
        tbl$ENSG <- dplyr::coalesce(tbl$ENSG, tbl$ENSG_gl)
        tbl$ENSG_gl <- NULL
      }
      
      if (!is.null(tx) && nrow(tx)) {
        tx_sum <- tx %>%
          dplyr::group_by(Gene) %>%
          dplyr::summarise(
            n_TID = dplyr::first(n_tx),
            TIDs = paste(ENST, collapse = "; "),
            Aliases = paste(Alias, collapse = "; "),
            .groups = "drop"
          )
        names(tx_sum)[1] <- "HUGO"
        tbl <- dplyr::left_join(tbl, tx_sum, by = "HUGO")
      } else {
        tbl$n_TID <- NA_integer_
        tbl$TIDs <- NA_character_
        tbl$Aliases <- NA_character_
      }
      
      if (!is.null(prot) && nrow(prot)) {
        tbl <- dplyr::left_join(tbl, prot, by = "HUGO")
        tbl$seq_source <- ifelse(!is.na(tbl$AA) & nzchar(tbl$AA), "protein_list", NA_character_)
      } else {
        tbl$AA <- NA_character_
        tbl$AA_len <- NA_integer_
        tbl$seq_source <- NA_character_
      }
      
      # ---------- STATUS分类逻辑 ----------
      has_3ca2 <- use_3ca && !is.null(rv$threeca_df) && nrow(rv$threeca_df)
      has_rsem2 <- !is.null(rv$tpm_df) && nrow(rv$tpm_df)
      has_protein2 <- !is.null(rv$prot_df) && nrow(rv$prot_df)
      has_genelist2 <- (length(genes_genelist) > 0)
      
      if (has_3ca2 && has_rsem2 && has_genelist2 && !has_protein2) {
        tbl$status <- dplyr::case_when(
          tbl$in_genelist & tbl$in_3ca ~ "Gene List in 3CA",
          tbl$in_genelist ~ "Gene List Only",
          tbl$in_3ca ~ "3CA only",
          tbl$in_rsem ~ "RSEM only",
          TRUE ~ "Other"
        )
      } else if (has_3ca2 && has_rsem2 && has_protein2 && !has_genelist2) {
        tbl$status <- dplyr::case_when(
          tbl$in_protein & tbl$in_3ca ~ "Protein List in 3CA",
          tbl$in_protein ~ "Protein List Only",
          tbl$in_3ca ~ "3CA only",
          tbl$in_rsem ~ "RSEM only",
          TRUE ~ "Other"
        )
      } else if (has_3ca2 && has_rsem2 && has_protein2 && has_genelist2) {
        tbl$status <- dplyr::case_when(
          tbl$in_protein & tbl$in_3ca ~ "Protein List in 3CA",
          tbl$in_genelist & tbl$in_3ca ~ "Gene List in 3CA",
          tbl$in_protein ~ "Protein List Only",
          tbl$in_genelist ~ "Gene List Only",
          tbl$in_3ca ~ "3CA only",
          tbl$in_rsem ~ "RSEM only",
          TRUE ~ "Other"
        )
      } else {
        src3 <- ifelse(has_3ca2 & tbl$in_3ca, "3CA", "")
        srcR <- ifelse(has_rsem2 & tbl$in_rsem, "RSEM", "")
        srcP <- ifelse(has_protein2 & tbl$in_protein, "Protein List", "")
        srcG <- ifelse(has_genelist2 & tbl$in_genelist, "Gene List", "")
        combo <- paste(src3, srcP, srcG, srcR)
        combo <- gsub("\\s+", " ", trimws(combo))
        combo <- gsub("^$", "Other", combo)
        tbl$status <- combo
      }
      # ---------- STATUS分类逻辑结束 ----------
      
      if (has_3ca2 && any(is.finite(tbl$CA_Combined), na.rm = TRUE)) {
        tbl <- tbl %>% dplyr::arrange(dplyr::desc(CA_Combined), HUGO)
      } else if (any(is.finite(tbl$TPM), na.rm = TRUE)) {
        tbl <- tbl %>% dplyr::arrange(dplyr::desc(TPM), HUGO)
      } else {
        tbl <- tbl %>% dplyr::arrange(HUGO)
      }
      
      tbl
    })
    
    # ---------------- status filter UI ----------------
    output$status_filter_ui <- shiny::renderUI({
      tbl <- gene_tbl_base()
      if (is.null(tbl) || !nrow(tbl)) return(shiny::tags$em("Load inputs first."))
      sts <- unique(tbl$status)
      sts <- sts[!is.na(sts) & nzchar(sts)]
      sts <- sort(sts)
      if (!length(sts)) return(shiny::tags$em("No status categories available."))
      shiny::checkboxGroupInput("status_filter", label = NULL, choices = sts, selected = sts)
    })
    
    compute_pass <- function(tbl) {
      if (is.null(tbl) || !nrow(tbl)) return(NULL)
      pass <- rep(TRUE, nrow(tbl))
      
      sts <- input$status_filter
      mode <- input$inc_exc_mode %||% "include"
      if (!is.null(sts) && length(sts)) {
        if (mode == "include") pass <- pass & (tbl$status %in% sts)
        if (mode == "exclude") pass <- pass & !(tbl$status %in% sts)
      }
      
      thr_tpm  <- .ffp_input_num(input$thr_tpm_num, 0)
      thr_comb <- .ffp_input_num(input$thr_comb_num, 0)
      thr_spec <- .ffp_input_num(input$thr_spec_num, 0)
      thr_sens <- .ffp_input_num(input$thr_sens_num, 0)
      
      if ("TPM" %in% names(tbl) && is.finite(thr_tpm) && thr_tpm > 0) {
        pass <- pass & is.finite(tbl$TPM) & tbl$TPM >= thr_tpm
      }
      if (isTRUE(input$use_3ca)) {
        if ("CA_Combined" %in% names(tbl) && is.finite(thr_comb) && thr_comb > 0) {
          pass <- pass & is.finite(tbl$CA_Combined) & tbl$CA_Combined >= thr_comb
        }
        if ("Specificity" %in% names(tbl) && is.finite(thr_spec) && thr_spec > 0) {
          pass <- pass & is.finite(tbl$Specificity) & tbl$Specificity >= thr_spec
        }
        if ("Sensitivity" %in% names(tbl) && is.finite(thr_sens) && thr_sens > 0) {
          pass <- pass & is.finite(tbl$Sensitivity) & tbl$Sensitivity >= thr_sens
        }
      }
      pass
    }
    
    gene_tbl_current <- shiny::reactive({
      base <- gene_tbl_base()
      if (is.null(base) || !nrow(base)) return(NULL)
      
      pass <- compute_pass(base)
      if (is.null(pass)) pass <- rep(TRUE, nrow(base))
      base$Pass <- as.logical(pass)
      
      ov <- rv$keep_overrides
      keep <- base$Pass
      if (!is.null(ov) && length(ov)) {
        idx <- match(names(ov), base$HUGO)
        idx <- idx[!is.na(idx)]
        if (length(idx)) keep[idx] <- as.logical(ov[base$HUGO[idx]])
      }
      base$Keep <- as.logical(keep)
      
      base$Override <- FALSE
      if (!is.null(ov) && length(ov)) base$Override <- base$HUGO %in% names(ov)
      
      base
    })
    
    shiny::observeEvent(input$apply_plot_scope, {
      tbl <- gene_tbl_current()
      if (is.null(tbl) || !nrow(tbl)) return(NULL)
      
      scope <- input$plot_scope %||% "all_view"
      if (identical(scope, "all_view")) {
        genes <- if (isTRUE(input$show_only_ticked)) tbl$HUGO[tbl$Keep %in% TRUE] else tbl$HUGO
        rv$plot_genes <- unique(genes[!is.na(genes) & nzchar(genes)])
        rv$plot_scope_applied <- "all_view"
      } else {
        genes <- tbl$HUGO[tbl$Keep %in% TRUE]
        rv$plot_genes <- unique(genes[!is.na(genes) & nzchar(genes)])
        rv$plot_scope_applied <- "ticked_snapshot"
      }
    }, ignoreInit = TRUE)
    
    shiny::observe({
      tbl <- gene_tbl_current()
      if (is.null(tbl) || !nrow(tbl)) return(NULL)
      if (!is.null(rv$plot_genes)) return(NULL)
      rv$plot_genes <- tbl$HUGO
      rv$plot_scope_applied <- "all_view"
    })
    
    output$gene_table <- DT::renderDataTable({
      tbl <- gene_tbl_current()
      if (is.null(tbl) || !nrow(tbl)) return(DT::datatable(data.frame()))
      
      if (isTRUE(input$show_only_ticked)) {
        tbl <- tbl[tbl$Keep %in% TRUE, , drop = FALSE]
        if (!nrow(tbl)) return(DT::datatable(data.frame()))
      }
      
      n <- nrow(tbl)
      fmt <- function(x, digits = 3) {
        if (is.null(x) || length(x) == 0) return(rep("NA (0)", n))
        ifelse(is.na(x), "NA (0)", format(round(x, digits), trim = TRUE, scientific = FALSE))
      }
      
      tbl$Keep_order <- ifelse(tbl$Keep %in% TRUE, 1L, 0L)
      
      tbl$TPM_num <- tbl$TPM
      tbl$CA_Combined_num <- tbl$CA_Combined
      tbl$Specificity_num <- tbl$Specificity
      tbl$Sensitivity_num <- tbl$Sensitivity
      
      tbl$TPM <- fmt(tbl$TPM_num, 3)
      tbl$CA_Combined <- fmt(tbl$CA_Combined_num, 3)
      tbl$Specificity <- fmt(tbl$Specificity_num, 3)
      tbl$Sensitivity <- fmt(tbl$Sensitivity_num, 3)
      
      tbl$TID <- ifelse(!is.na(tbl$TIDs) & nzchar(tbl$TIDs), gsub(";\\s*", ", ", tbl$TIDs), NA_character_)
      
      tbl$Keep <- sprintf(
        '<input type="checkbox" class="keepbox" data-gene="%s" %s/>',
        htmltools::htmlEscape(tbl$HUGO),
        ifelse(tbl$Keep_order == 1L, "checked", "")
      )
      
      show_cols <- c(
        "Keep_order",
        "Keep",
        "HUGO",
        "status",
        "TPM_num", "TPM",
        "CA_Combined_num", "CA_Combined",
        "Specificity_num", "Specificity",
        "Sensitivity_num", "Sensitivity",
        "TID"
      )
      tbl_show <- tbl[, show_cols, drop = FALSE]
      
      order_list <- list(list(0, "desc"))
      if (isTRUE(input$use_3ca) && any(is.finite(tbl_show$CA_Combined_num), na.rm = TRUE)) {
        order_list <- c(order_list, list(list(6, "desc")))
      } else if (any(is.finite(tbl_show$TPM_num), na.rm = TRUE)) {
        order_list <- c(order_list, list(list(4, "desc")))
      }
      order_list <- c(order_list, list(list(2, "asc")))
      
      DT::datatable(
        tbl_show,
        rownames = FALSE,
        escape = FALSE,
        options = list(
          pageLength = 15,
          scrollX = TRUE,
          dom = "tip",
          order = order_list,
          columnDefs = list(
            list(orderable = FALSE, targets = 1),
            list(width = "55px", targets = 1),
            list(visible = FALSE, targets = c(0, 4, 6, 8, 10)),
            list(visible = isTRUE(input$use_3ca), targets = c(7, 9, 11))
          )
        ),
        callback = DT::JS(
          "table.on('change', 'input.keepbox', function() {",
          "  var gene = $(this).data('gene');",
          "  var checked = $(this).prop('checked');",
          "  Shiny.setInputValue('keep_toggle', {gene: gene, checked: checked, nonce: Math.random()}, {priority: 'event'});",
          "});"
        )
      )
    })
    
    shiny::observeEvent(input$keep_toggle, {
      ev <- input$keep_toggle
      if (is.null(ev$gene) || !nzchar(ev$gene)) return(NULL)
      
      tbl <- gene_tbl_current()
      if (is.null(tbl) || !nrow(tbl)) return(NULL)
      
      gene <- as.character(ev$gene)
      desired <- isTRUE(ev$checked)
      
      i <- match(gene, tbl$HUGO)
      if (is.na(i)) return(NULL)
      pass_i <- isTRUE(tbl$Pass[i])
      
      ov <- rv$keep_overrides
      if (is.null(ov)) ov <- setNames(logical(0), character(0))
      
      if (identical(desired, pass_i)) {
        ov <- ov[setdiff(names(ov), gene)]
      } else {
        ov[gene] <- desired
      }
      rv$keep_overrides <- ov
    }, ignoreInit = TRUE)
    
    .plot_df <- shiny::reactive({
      tbl <- gene_tbl_current()
      genes <- rv$plot_genes
      if (is.null(tbl) || !nrow(tbl) || is.null(genes) || !length(genes)) return(NULL)
      genes <- unique(as.character(genes))
      genes <- genes[!is.na(genes) & nzchar(genes)]
      keep_genes <- intersect(genes, tbl$HUGO)
      if (!length(keep_genes)) return(NULL)
      tbl[match(keep_genes, tbl$HUGO), , drop = FALSE]
    })
    
    .plt_scatter <- function(df, x_col, y_col, xthr = NA_real_, ythr = NA_real_, title = "", tpm_axis_max = NA_real_) {
      if (is.null(df) || !nrow(df)) return(plotly::plot_ly())
      
      x_raw <- df[[x_col]]; y_raw <- df[[y_col]]
      x <- ifelse(is.na(x_raw) | !is.finite(x_raw), 0, x_raw)
      y <- ifelse(is.na(y_raw) | !is.finite(y_raw), 0, y_raw)
      
      keep_flag <- df$Keep %in% TRUE
      
      p <- plotly::plot_ly(
        x = x, y = y,
        type = "scatter", mode = "markers",
        text = df$HUGO, hoverinfo = "text+x+y",
        marker = list(color = ifelse(keep_flag, "red", "black"), size = 8)
      )
      
      shapes <- list()
      if (is.finite(xthr) && !is.na(xthr) && xthr > 0) {
        shapes <- c(shapes, list(list(type = "line", x0 = xthr, x1 = xthr, y0 = 0, y1 = 1, yref = "paper", line = list(dash = "dash", width = 1))))
      }
      if (is.finite(ythr) && !is.na(ythr) && ythr > 0) {
        shapes <- c(shapes, list(list(type = "line", y0 = ythr, y1 = ythr, x0 = 0, x1 = 1, xref = "paper", line = list(dash = "dash", width = 1))))
      }
      
      xaxis <- list(title = x_col, autorange = TRUE, fixedrange = FALSE, automargin = TRUE)
      yaxis <- list(title = y_col, autorange = TRUE, fixedrange = FALSE, automargin = TRUE)
      
      if (is.finite(tpm_axis_max) && !is.na(tpm_axis_max) && tpm_axis_max > 0) {
        if (identical(x_col, "TPM")) xaxis$range <- c(0, tpm_axis_max)
        if (identical(y_col, "TPM")) yaxis$range <- c(0, tpm_axis_max)
      }
      
      plotly::layout(
        p, title = title,
        xaxis = xaxis, yaxis = yaxis,
        shapes = shapes,
        margin = list(l = 70, r = 20, b = 60, t = 50)
      )
    }
    
    .plt_barh <- function(df, val_col, title = "") {
      if (is.null(df) || !nrow(df)) return(plotly::plot_ly())
      vraw <- df[[val_col]]
      v <- ifelse(is.na(vraw) | !is.finite(vraw), 0, vraw)
      df2 <- df
      df2$val_plot <- v
      df2 <- df2 %>% dplyr::arrange(val_plot)
      
      p <- plotly::plot_ly(
        df2, x = ~val_plot, y = ~HUGO,
        type = "bar", orientation = "h",
        marker = list(color = ifelse(df2$Keep %in% TRUE, "red", "black"))
      )
      plotly::layout(
        p, title = title,
        yaxis = list(title = "", fixedrange = FALSE, automargin = TRUE),
        xaxis = list(title = val_col, fixedrange = FALSE, automargin = TRUE),
        margin = list(l = 150, r = 20, b = 60, t = 50)
      )
    }
    
    output$plot_main <- plotly::renderPlotly({
      df <- .plot_df()
      if (is.null(df) || !nrow(df)) return(plotly::plot_ly())
      
      use_3ca <- isTRUE(input$use_3ca)
      thr_tpm  <- .ffp_input_num(input$thr_tpm_num, NA_real_)
      thr_comb <- .ffp_input_num(input$thr_comb_num, NA_real_)
      tpm_max  <- .ffp_input_num(input$tpm_axis_max, NA_real_)
      
      has_tpm <- "TPM" %in% names(df)
      has_comb <- use_3ca && "CA_Combined" %in% names(df)
      
      if (use_3ca && has_tpm && has_comb) {
        return(.plt_scatter(df, "TPM", "CA_Combined", xthr = thr_tpm, ythr = thr_comb,
                            title = "3CA_Combined vs TPM", tpm_axis_max = tpm_max))
      }
      if (has_tpm) {
        df$idx <- seq_len(nrow(df))
        return(.plt_scatter(df, "TPM", "idx", xthr = thr_tpm, ythr = NA_real_,
                            title = "TPM (genes)", tpm_axis_max = tpm_max))
      }
      plotly::plot_ly()
    })
    
    output$plot_secondary <- plotly::renderPlotly({
      df <- .plot_df()
      if (is.null(df) || !nrow(df)) return(plotly::plot_ly())
      
      use_3ca <- isTRUE(input$use_3ca)
      thr_tpm  <- .ffp_input_num(input$thr_tpm_num, NA_real_)
      thr_spec <- .ffp_input_num(input$thr_spec_num, NA_real_)
      thr_sens <- .ffp_input_num(input$thr_sens_num, NA_real_)
      tpm_max  <- .ffp_input_num(input$tpm_axis_max, NA_real_)
      
      has_tpm <- "TPM" %in% names(df)
      
      if (use_3ca && has_tpm && "Sensitivity" %in% names(df)) {
        return(.plt_scatter(df, "TPM", "Sensitivity", xthr = thr_tpm, ythr = thr_sens,
                            title = "3CA Sensitivity vs TPM", tpm_axis_max = tpm_max))
      }
      if (use_3ca && has_tpm && "Specificity" %in% names(df)) {
        return(.plt_scatter(df, "TPM", "Specificity", xthr = thr_tpm, ythr = thr_spec,
                            title = "3CA Specificity vs TPM", tpm_axis_max = tpm_max))
      }
      if (use_3ca && "CA_Combined" %in% names(df)) {
        return(.plt_barh(df, "CA_Combined", title = "3CA_Combined (bar)"))
      }
      plotly::plot_ly()
    })
    
    output$plot_third <- plotly::renderPlotly({
      df <- .plot_df()
      if (is.null(df) || !nrow(df)) return(plotly::plot_ly())
      
      use_3ca <- isTRUE(input$use_3ca)
      thr_spec <- .ffp_input_num(input$thr_spec_num, NA_real_)
      thr_sens <- .ffp_input_num(input$thr_sens_num, NA_real_)
      
      if (use_3ca && "Specificity" %in% names(df) && "Sensitivity" %in% names(df)) {
        return(.plt_scatter(df, "Specificity", "Sensitivity", xthr = thr_spec, ythr = thr_sens,
                            title = "3CA Sensitivity vs Specificity", tpm_axis_max = NA_real_))
      }
      plotly::plot_ly()
    })
    
    shiny::observeEvent(input$reset_plots, {
      plotly::plotlyProxy("plot_main", session) %>% plotly::plotlyProxyInvoke("relayout", list("xaxis.autorange" = TRUE, "yaxis.autorange" = TRUE))
      plotly::plotlyProxy("plot_secondary", session) %>% plotly::plotlyProxyInvoke("relayout", list("xaxis.autorange" = TRUE, "yaxis.autorange" = TRUE))
      plotly::plotlyProxy("plot_third", session) %>% plotly::plotlyProxyInvoke("relayout", list("xaxis.autorange" = TRUE, "yaxis.autorange" = TRUE))
    })
    
    output$sel_summary <- shiny::renderText({
      tbl <- gene_tbl_current()
      if (is.null(tbl) || !nrow(tbl)) return("No genes loaded yet.")
      keep <- tbl$Keep %in% TRUE
      n_keep <- sum(keep, na.rm = TRUE)
      n_total <- nrow(tbl)
      
      missing_gene_aa <- tbl$HUGO[keep & !(tbl$has_tx %in% TRUE) & (is.na(tbl$AA) | !nzchar(tbl$AA))]
      missing_gene_aa <- unique(missing_gene_aa[!is.na(missing_gene_aa) & nzchar(missing_gene_aa)])
      
      tx <- rv$enst_df
      tx_keep_n <- 0
      if (!is.null(tx) && nrow(tx)) {
        keep_genes <- tbl$HUGO[keep]
        tx_keep <- tx[tx$Gene %in% keep_genes, , drop = FALSE]
        tx_keep_n <- nrow(tx_keep)
      }
      
      paste0(
        "Total genes: ", n_total, "\n",
        "Kept genes (for export): ", n_keep, "\n",
        "Kept transcript entries (will fetch at Export if enabled): ", tx_keep_n, "\n",
        "Kept gene-level entries missing AA (needs protein list/manual override/canonical at Export): ", length(missing_gene_aa), "\n"
      )
    })
    
    build_fasta_entries <- function() {
      gtbl <- gene_tbl_current()
      if (is.null(gtbl) || !nrow(gtbl)) return(NULL)
      
      keep_genes <- gtbl$HUGO[gtbl$Keep %in% TRUE]
      keep_genes <- keep_genes[!is.na(keep_genes) & nzchar(keep_genes)]
      if (!length(keep_genes)) return(NULL)
      
      tx <- rv$enst_df
      
      # TPM lookup
      tpm_map <- gtbl[, c("HUGO", "TPM", "ENSG"), drop = FALSE]
      names(tpm_map)[1] <- "Gene"
      
      tx_entries <- data.frame()
      if (!is.null(tx) && nrow(tx)) {
        tx_keep <- tx[tx$Gene %in% keep_genes, , drop = FALSE]
        if (nrow(tx_keep)) {
          tx_entries <- tx_keep %>%
            dplyr::transmute(
              Header = Alias,
              Gene = Gene,
              TranscriptID = ENST,
              AA = NA_character_,
              AA_source = "to_fetch_at_export"
            )
          tx_entries <- dplyr::left_join(tx_entries, tpm_map, by = "Gene")
        }
      }
      
      g_keep <- gtbl[gtbl$HUGO %in% keep_genes & !(gtbl$has_tx %in% TRUE), , drop = FALSE]
      g_entries <- data.frame()
      if (nrow(g_keep)) {
        g_entries <- g_keep %>%
          dplyr::transmute(
            Header = HUGO,
            Gene = HUGO,
            TranscriptID = NA_character_,
            AA = ifelse(is.na(AA) | !nzchar(AA), NA_character_, toupper(gsub("[^A-Za-z]", "", AA))),
            AA_source = ifelse(!is.na(AA) & nzchar(AA), seq_source, "not found"),
            TPM = TPM,
            ENSG = ENSG
          )
      }
      
      entries <- dplyr::bind_rows(
        if (nrow(tx_entries)) tx_entries else NULL,
        if (nrow(g_entries)) g_entries else NULL
      )
      if (!nrow(entries)) return(NULL)
      if (!("TPM" %in% names(entries))) entries$TPM <- NA_real_
      if (!("ENSG" %in% names(entries))) entries$ENSG <- NA_character_
      
      entries$AA_len <- ifelse(!is.na(entries$AA) & nzchar(entries$AA), nchar(entries$AA), NA_integer_)
      
      entries <- entries %>%
        dplyr::group_by(Header) %>%
        dplyr::arrange(dplyr::desc(AA_len)) %>%
        dplyr::slice(1) %>%
        dplyr::ungroup()
      
      if (!is.null(rv$manual_aa_export_map) && nrow(rv$manual_aa_export_map)) {
        ap <- .ffp_apply_manual_overrides(entries, rv$manual_aa_export_map, respect_user_replaced = TRUE)
        entries <- ap$fe
      }
      
      entries
    }
    
    shiny::observeEvent(input$refresh_fasta_entries, {
      new_entries <- build_fasta_entries()
      if (is.null(new_entries) || !nrow(new_entries)) {
        rv$fasta_entries <- NULL
        shiny::showNotification("No FASTA entries from current selection.", type = "warning")
        return(NULL)
      }
      
      if (!is.null(rv$fasta_entries) && nrow(rv$fasta_entries)) {
        old <- rv$fasta_entries[, c("Header", "AA"), drop = FALSE]
        names(old)[2] <- "AA_old"
        new_entries <- dplyr::left_join(new_entries, old, by = "Header")
        keep_edit <- !is.na(new_entries$AA_old) & nzchar(new_entries$AA_old)
        new_entries$AA[keep_edit] <- new_entries$AA_old[keep_edit]
        new_entries$AA_source[keep_edit] <- "user_replaced"
        new_entries$AA_old <- NULL
        new_entries$AA_len <- ifelse(!is.na(new_entries$AA) & nzchar(new_entries$AA), nchar(new_entries$AA), NA_integer_)
      }
      
      if (!is.null(rv$manual_aa_export_map) && nrow(rv$manual_aa_export_map)) {
        ap <- .ffp_apply_manual_overrides(new_entries, rv$manual_aa_export_map, respect_user_replaced = TRUE)
        new_entries <- ap$fe
      }
      
      rv$fasta_entries <- new_entries
      shiny::showNotification("FASTA entries refreshed.", type = "message")
    }, ignoreInit = TRUE)
    
    shiny::observe({
      if (is.null(rv$fasta_entries)) {
        fe <- build_fasta_entries()
        if (!is.null(fe) && nrow(fe)) rv$fasta_entries <- fe
      }
    })
    
    output$fasta_edit_table <- DT::renderDataTable({
      fe <- rv$fasta_entries
      if (is.null(fe) || !nrow(fe)) return(DT::datatable(data.frame()))
      show <- fe[, c("Header", "Gene", "TranscriptID", "TPM", "AA", "AA_source", "AA_len"), drop = FALSE]
      DT::datatable(
        show,
        rownames = FALSE,
        options = list(pageLength = 12, scrollX = TRUE),
        editable = list(target = "cell", disable = list(columns = c(0, 1, 2, 3, 5, 6)))
      )
    })
    
    shiny::observeEvent(input$fasta_edit_table_cell_edit, {
      info <- input$fasta_edit_table_cell_edit
      fe <- rv$fasta_entries
      if (is.null(fe) || !nrow(fe)) return(NULL)
      
      i <- info$row
      j <- info$col + 1
      colname <- c("Header", "Gene", "TranscriptID", "TPM", "AA", "AA_source", "AA_len")[j]
      if (colname != "AA") return(NULL)
      
      v <- toupper(gsub("[^A-Za-z]", "", as.character(info$value)))
      if (!nzchar(v)) v <- NA_character_
      fe$AA[i] <- v
      fe$AA_source[i] <- ifelse(!is.na(v) & nzchar(v), "user_replaced", fe$AA_source[i])
      fe$AA_len[i] <- ifelse(!is.na(v) & nzchar(v), nchar(v), NA_integer_)
      rv$fasta_entries <- fe
    })
    
    shiny::observeEvent(input$apply_manual_aa_export, {
      fe <- rv$fasta_entries
      if (is.null(fe) || !nrow(fe)) {
        fe <- build_fasta_entries()
        if (is.null(fe) || !nrow(fe)) {
          shiny::showNotification("No FASTA entries available to apply manual AA.", type = "error")
          return(NULL)
        }
      }
      
      man <- .ffp_parse_manual_aa_export(input$manual_aa_export)
      if (!nrow(man)) {
        rv$manual_aa_export_map <- NULL
        shiny::showNotification("No valid manual AA lines parsed.", type = "warning")
        return(NULL)
      }
      
      rv$manual_aa_export_map <- man
      
      ap <- .ffp_apply_manual_overrides(fe, man, respect_user_replaced = FALSE)
      rv$fasta_entries <- ap$fe
      
      if (length(ap$unmatched)) {
        shiny::showNotification(
          paste0("Manual AA: unmatched keys ignored: ", paste(utils::head(ap$unmatched, 15), collapse = ", "),
                 ifelse(length(ap$unmatched) > 15, paste0(" ... (+", length(ap$unmatched) - 15, ")"), "")),
          type = "warning", duration = 8
        )
      }
      
      if (length(ap$overridden_genes)) {
        genes_show <- utils::head(ap$overridden_genes, 40)
        shiny::showModal(
          shiny::modalDialog(
            title = "Manual AA will override existing sequences",
            shiny::tags$p("These genes have existing AA that will be overwritten by Manual AA:"),
            shiny::tags$pre(paste0(paste(genes_show, collapse = "\n"),
                                   ifelse(length(ap$overridden_genes) > 40, paste0("\n... (+", length(ap$overridden_genes) - 40, " more)"), ""))),
            easyClose = TRUE,
            footer = shiny::modalButton("OK")
          )
        )
      } else {
        shiny::showNotification("Manual AA applied to FASTA entries.", type = "message")
      }
    }, ignoreInit = TRUE)
    
    shiny::observeEvent(input$write_outputs, {
      fe <- rv$fasta_entries
      gtbl <- gene_tbl_current()
      if (is.null(gtbl) || !nrow(gtbl)) {
        rv$export_paths <- list(error = "No genes loaded.")
        return(NULL)
      }
      if (is.null(fe) || !nrow(fe)) {
        rv$export_paths <- list(error = "No FASTA entries available.")
        return(NULL)
      }
      
      fe2 <- fe
      
      man_now <- .ffp_parse_manual_aa_export(input$manual_aa_export)
      if (nrow(man_now)) {
        rv$manual_aa_export_map <- man_now
      }
      if (!is.null(rv$manual_aa_export_map) && nrow(rv$manual_aa_export_map)) {
        ap0 <- .ffp_apply_manual_overrides(fe2, rv$manual_aa_export_map, respect_user_replaced = FALSE)
        fe2 <- ap0$fe
        
        if (length(ap0$overridden_genes)) {
          genes_show <- utils::head(ap0$overridden_genes, 40)
          shiny::showModal(
            shiny::modalDialog(
              title = "Manual AA overrides at Export",
              shiny::tags$p("These genes were overwritten by Manual AA during Export:"),
              shiny::tags$pre(paste0(paste(genes_show, collapse = "\n"),
                                     ifelse(length(ap0$overridden_genes) > 40, paste0("\n... (+", length(ap0$overridden_genes) - 40, " more)"), ""))),
              easyClose = TRUE,
              footer = shiny::modalButton("OK")
            )
          )
        }
      }
      
      if (isTRUE(input$fetch_missing_at_export)) {
        tx_need <- fe2$TranscriptID[!is.na(fe2$TranscriptID) & nzchar(fe2$TranscriptID) & (is.na(fe2$AA) | !nzchar(fe2$AA))]
        tx_need <- unique(tx_need)
        if (length(tx_need)) {
          seqs <- .ffp_try_read(.ffp_fetch_peptide_by_enst(tx_need, build = input$enst_build), quiet = FALSE)
          if (!is.null(seqs) && nrow(seqs)) {
            seqs2 <- seqs %>% dplyr::transmute(TranscriptID = TID, AA_f = toupper(gsub("[^A-Za-z]", "", AA)), AA_len_f = AA_len)
            fe2 <- dplyr::left_join(fe2, seqs2, by = "TranscriptID")
            fill <- (is.na(fe2$AA) | !nzchar(fe2$AA)) & (!is.na(fe2$AA_f) & nzchar(fe2$AA_f))
            fe2$AA[fill] <- fe2$AA_f[fill]
            fe2$AA_len[fill] <- fe2$AA_len_f[fill]
            fe2$AA_source[fill] <- paste0("ENST_", input$enst_build)
            fe2$AA_f <- NULL
            fe2$AA_len_f <- NULL
          }
        }
        
        if (isTRUE(input$use_canonical)) {
          gene_need <- fe2$Gene[(is.na(fe2$TranscriptID) | !nzchar(fe2$TranscriptID)) & (is.na(fe2$AA) | !nzchar(fe2$AA))]
          gene_need <- unique(gene_need[!is.na(gene_need) & nzchar(gene_need)])
          if (length(gene_need)) {
            canon <- .ffp_try_read(.ffp_fetch_canonical_peptide_grch38(gene_need), quiet = FALSE)
            if (!is.null(canon) && nrow(canon)) {
              canon2 <- canon %>% dplyr::transmute(Gene = HUGO, CanonTID = TID, AA_c = toupper(gsub("[^A-Za-z]", "", AA)), AA_len_c = AA_len)
              fe2 <- dplyr::left_join(fe2, canon2, by = "Gene")
              fill <- (is.na(fe2$AA) | !nzchar(fe2$AA)) &
                (is.na(fe2$TranscriptID) | !nzchar(fe2$TranscriptID)) &
                (!is.na(fe2$AA_c) & nzchar(fe2$AA_c))
              fe2$AA[fill] <- fe2$AA_c[fill]
              fe2$AA_len[fill] <- fe2$AA_len_c[fill]
              fe2$AA_source[fill] <- "canonical_GRCh38"
              tid_fill <- (is.na(fe2$TranscriptID) | !nzchar(fe2$TranscriptID)) & fill & (!is.na(fe2$CanonTID) & nzchar(fe2$CanonTID))
              fe2$TranscriptID[tid_fill] <- fe2$CanonTID[tid_fill]
              
              fe2$CanonTID <- NULL
              fe2$AA_c <- NULL
              fe2$AA_len_c <- NULL
            }
          }
        }
      }
      
      if (!is.null(rv$manual_aa_export_map) && nrow(rv$manual_aa_export_map)) {
        ap1 <- .ffp_apply_manual_overrides(fe2, rv$manual_aa_export_map, respect_user_replaced = FALSE)
        fe2 <- ap1$fe
      }
      
      fe_out <- fe2[!is.na(fe2$AA) & nzchar(fe2$AA), , drop = FALSE]
      if (!nrow(fe_out)) {
        rv$export_paths <- list(error = "No FASTA entries with AA (all Not found or fetch disabled).")
        rv$fasta_entries <- fe2
        return(NULL)
      }
      
      prefix <- input$out_prefix
      if (is.null(prefix) || !nzchar(prefix)) prefix <- "pan_input"
      prefix <- gsub("[^A-Za-z0-9_.-]", "_", prefix)
      
      fasta_path <- file.path(out_dir, paste0(prefix, ".fasta"))
      ann_path   <- file.path(out_dir, paste0(prefix, "_annotation.xlsx"))
      tpm_path   <- file.path(out_dir, paste0(prefix, "_TPM.xlsx"))
      
      fasta_lines <- as.vector(rbind(paste0(">", fe_out$Header), fe_out$AA))
      writeLines(fasta_lines, con = fasta_path)
      rv$export_fasta <- fasta_path
      
      fasta_ann <- fe2 %>%
        dplyr::transmute(
          Header, Gene, TranscriptID, ENSG, TPM, AA_source, AA_len,
          AA_present = !is.na(AA) & nzchar(AA)
        )
      
      gene_ann <- gene_tbl_current()
      
      sheets <- list(
        FASTA_entries = fasta_ann,
        Gene_table = gene_ann
      )
      writexl::write_xlsx(sheets, path = ann_path)
      rv$export_xlsx <- ann_path
      
      # NEW: TPM workbook for later stages (gene + header/TID)
      tpm_gene <- rv$tpm_df
      if (is.null(tpm_gene) || !nrow(tpm_gene)) {
        tpm_gene <- data.frame(HUGO = character(0), TPM = numeric(0), ENSG = character(0), stringsAsFactors = FALSE)
      } else {
        tpm_gene <- tpm_gene %>% dplyr::select(HUGO, TPM, ENSG)
      }
      
      tpm_header <- fasta_ann %>%
        dplyr::select(Header, Gene, TranscriptID, TPM, ENSG)
      
      writexl::write_xlsx(
        list(
          TPM_gene = tpm_gene,
          TPM_header = tpm_header
        ),
        path = tpm_path
      )
      rv$export_tpm_xlsx <- tpm_path
      
      rv$fasta_entries <- fe2
      rv$export_paths <- list(fasta = fasta_path, xlsx = ann_path, tpm_xlsx = tpm_path)
      shiny::showNotification("Outputs generated.", type = "message")
    }, ignoreInit = TRUE)
    
    output$export_status <- shiny::renderText({
      p <- rv$export_paths
      if (is.null(p)) return("No outputs yet.")
      if (!is.null(p$error)) return(p$error)
      paste0(
        "Written:\n- FASTA: ", p$fasta, "\n- XLSX:  ", p$xlsx, "\n- TPM:   ", p$tpm_xlsx, "\n"
      )
    })
    
    output$dl_fasta <- shiny::downloadHandler(
      filename = function() {
        prefix <- input$out_prefix
        if (is.null(prefix) || !nzchar(prefix)) prefix <- "pan_input"
        paste0(prefix, ".fasta")
      },
      content = function(file) {
        req(rv$export_fasta)
        file.copy(rv$export_fasta, file, overwrite = TRUE)
      }
    )
    
    output$dl_xlsx <- shiny::downloadHandler(
      filename = function() {
        prefix <- input$out_prefix
        if (is.null(prefix) || !nzchar(prefix)) prefix <- "pan_input"
        paste0(prefix, "_annotation.xlsx")
      },
      content = function(file) {
        req(rv$export_xlsx)
        file.copy(rv$export_xlsx, file, overwrite = TRUE)
      }
    )
    
    output$dl_tpm_xlsx <- shiny::downloadHandler(
      filename = function() {
        prefix <- input$out_prefix
        if (is.null(prefix) || !nzchar(prefix)) prefix <- "pan_input"
        paste0(prefix, "_TPM.xlsx")
      },
      content = function(file) {
        req(rv$export_tpm_xlsx)
        file.copy(rv$export_tpm_xlsx, file, overwrite = TRUE)
      }
    )
    
    # ---- direct links fallback for export (NEW) ----
    output$direct_export_links <- shiny::renderUI({
      if (is.null(rv$export_paths) || !is.null(rv$export_paths$error)) return(NULL)
      req(rv$export_fasta, rv$export_xlsx, rv$export_tpm_xlsx)
      
      shiny::tagList(
        shiny::tags$hr(),
        shiny::tags$strong("If the buttons above don't respond, use direct links:"),
        shiny::tags$div(style = "display:flex; gap:10px; flex-wrap:wrap; margin-top:8px;",
                        shiny::tags$a(
                          href = paste0("tapas_out/", basename(rv$export_fasta)),
                          class = "btn btn-default",
                          download = basename(rv$export_fasta),
                          shiny::icon("download"), " FASTA (direct)"
                        ),
                        shiny::tags$a(
                          href = paste0("tapas_out/", basename(rv$export_xlsx)),
                          class = "btn btn-default",
                          download = basename(rv$export_xlsx),
                          shiny::icon("download"), " XLSX (direct)"
                        ),
                        shiny::tags$a(
                          href = paste0("tapas_out/", basename(rv$export_tpm_xlsx)),
                          class = "btn btn-default",
                          download = basename(rv$export_tpm_xlsx),
                          shiny::icon("download"), " TPM (direct)"
                        )
        )
      )
    })
    
    # ---------------- NetMHC command generator server logic (NEW) ----------------
    output$nm_examples_ui <- shiny::renderUI({
      if (identical(input$nm_class %||% "I", "I")) {
        shiny::tagList(
          shiny::tags$small("Examples:"),
          shiny::tags$pre('Class I example alleles: HLA-A02:01\n(You can paste multiple: HLA-A02:01,HLA-A03:01,HLA-A11:01)')
        )
      } else {
        shiny::tagList(
          shiny::tags$small("Examples:"),
          shiny::tags$pre('Class II example alleles:\nHLA-DQA10505-DQB10602\nDRB1_1501\n(You can paste multiple: DRB1_1501,DRB1_1201, HLA-DQA10505-DQB10602)')
        )
      }
    })
    
    shiny::observeEvent(input$nm_use_exported_fasta, {
      if (!is.null(rv$export_fasta) && nzchar(rv$export_fasta)) {
        shiny::updateTextInput(session, "nm_fasta_path", value = rv$export_fasta)
        shiny::showNotification("Filled FASTA path from exported FASTA.", type = "message", duration = 4)
      } else {
        shiny::showNotification("No exported FASTA path available yet. Please Generate outputs first.", type = "warning", duration = 5)
      }
    }, ignoreInit = TRUE)
    
    shiny::observeEvent(input$nm_gen_cmd, {
      fasta_path <- trimws(input$nm_fasta_path %||% "")
      if (!nzchar(fasta_path) && !is.null(rv$export_fasta) && nzchar(rv$export_fasta)) {
        fasta_path <- rv$export_fasta
      }
      if (!nzchar(fasta_path)) {
        rv$nm_cmd <- "Please paste FASTA path (or generate outputs first, then click 'Use exported FASTA path')."
        return(NULL)
      }
      
      cls <- input$nm_class %||% "I"
      alleles_txt <- input$nm_alleles %||% ""
      workdir <- input$nm_workdir %||% ""
      outname <- input$nm_outname %||% ""
      
      cmd <- if (identical(cls, "I")) {
        .ffp_build_netmhc_cmds(
          class = "I",
          fasta_path = fasta_path,
          alleles_text = alleles_txt,
          workdir = workdir,
          out_name = outname,
          len_I = input$nm_len_I %||% as.character(c(8,9,10,11))
        )
      } else {
        .ffp_build_netmhc_cmds(
          class = "II",
          fasta_path = fasta_path,
          alleles_text = alleles_txt,
          workdir = workdir,
          out_name = outname,
          len_II = input$nm_len_II %||% as.character(13:25)
        )
      }
      
      rv$nm_cmd <- cmd
    }, ignoreInit = TRUE)
    
    output$nm_cmd_out <- shiny::renderText({
      rv$nm_cmd %||% ""
    })
  }
  shiny::runApp(shiny::shinyApp(ui, server),
                launch.browser = getOption("shiny.launch.browser", TRUE))
  
}
