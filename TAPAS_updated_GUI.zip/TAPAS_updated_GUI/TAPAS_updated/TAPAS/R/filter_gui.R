#' Interactive filter before assembly (TPM / 3CA / rank / include genes)
#'
#' Opens a Shiny window to filter the Stage1 peptide list at gene level.
#' After clicking "Export & Close", the app writes filtered outputs to out_dir and returns their paths.
#'
#' Notes:
#' - TPM filter keeps genes with TPM >= threshold.
#' - 3CA filter keeps genes with 3CA >= threshold.
#' - Rank filter keeps genes with peptide-level mean winner_rank <= threshold.
#' - AUTO-TICK: all genes that pass thresholds are automatically ticked.
#' - User can untick / tick any gene.
#' - Priority: tick > untick. (If both are recorded, gene is kept.)
#' - Plots always show ALL genes: kept genes are red; filtered-out genes are black.
#' - Thresholds are drawn as dashed lines.
#' - Moving thresholds will NOT rescale axes (fixed axis ranges).
#' - If stage1_state_rds is provided and contains map_dt (pep_id preserved),
#'   we subset the original AB map and can reuse existing NetChop output.
#'
#' Major changes:
#' - Rank logic redesigned:
#'   * Parse Stage1 winner_rank per peptide, split numeric tokens, take MEAN per peptide (handles concatenated ranks).
#'   * Filtering uses peptide-level rank (mean winner_rank), not gene best_rank.
#' - Keep ONLY TPM vs 3CA scatter plot (gene-level).
#' - Add bar plot:
#'   * Each bar = (sum AA length of kept peptides for that gene) / (sum AA length of all kept peptides).
#' - Gene list:
#'   * Remove best_rank column
#'   * Show "Rank-pass peptide AA length" (sum peptide lengths after rank threshold) for each gene.
#'
#' @param stage1_state_rds Optional Stage1 state RDS (recommended if you want to reuse NetChop output).
#' @param stage1_tsv Optional Stage1 peptide TSV (res_pep2_merged.tsv). Required if stage1_state_rds is NULL.
#' @param tpm_xlsx Optional TPM xlsx path. First two columns must be HUGO and TPM OR workbook produced by fasta_for_prediction().
#' @param threeca_xlsx Optional 3CA xlsx path. If provided, you can choose a worksheet; it must contain a 'Gene' column.
#' @param threeca_sheet Optional worksheet name for 3CA (default tries 'Melanoma' then first sheet).
#' @param out_dir Output directory.
#' @param out_base Output base name.
#' @param na_as_zero_for_plots If TRUE, NA TPM/3CA are shown as 0 in plots (tables keep NA).
#' @return List of written output paths (via stopApp()).
#' @export
classI_filter_gui <- function(stage1_state_rds = NULL,
                              stage1_tsv = NULL,
                              tpm_xlsx = NULL,
                              threeca_xlsx = NULL,
                              threeca_sheet = NULL,
                              out_dir,
                              out_base = "classI_filtered",
                              na_as_zero_for_plots = TRUE) {
  
  stopifnot(is.character(out_dir), length(out_dir) == 1, nzchar(out_dir))
  
  # ---- deps ----
  pkgs <- c("shiny", "DT", "plotly", "data.table", "readxl", "readr", "writexl")
  for (p in pkgs) {
    if (!requireNamespace(p, quietly = TRUE)) stop("Package '", p, "' is required.")
  }
  
  .ensure_dir_local <- function(p) {
    if (!dir.exists(p)) dir.create(p, recursive = TRUE, showWarnings = FALSE)
    normalizePath(p, winslash = "/", mustWork = FALSE)
  }
  out_dir <- .ensure_dir_local(out_dir)
  
  # ---- export sanitizer: avoid TSV/CSV corruption ----
  sanitize_for_export <- function(df) {
    df <- as.data.frame(df, stringsAsFactors = FALSE, check.names = FALSE)
    
    # list columns -> single string
    for (nm in names(df)) {
      if (is.list(df[[nm]])) {
        df[[nm]] <- vapply(df[[nm]], function(z) {
          if (is.null(z) || length(z) == 0) return(NA_character_)
          paste(as.character(z), collapse = ";")
        }, character(1))
      }
    }
    
    # remove control chars that break delimited files
    for (nm in names(df)) {
      if (is.character(df[[nm]])) {
        df[[nm]] <- gsub("[\t\r\n]", " ", df[[nm]])
      }
    }
    df
  }
  
  state <- NULL
  pep <- NULL
  map_dt <- NULL
  
  if (!is.null(stage1_state_rds) && nzchar(stage1_state_rds)) {
    if (!file.exists(stage1_state_rds)) stop("stage1_state_rds does not exist: ", stage1_state_rds)
    state <- readRDS(stage1_state_rds)
    pep <- state$res_pep2_merged
    if (!is.null(state$map_dt)) map_dt <- state$map_dt
  }
  
  if (is.null(pep)) {
    if (is.null(stage1_tsv) || !nzchar(stage1_tsv) || !file.exists(stage1_tsv)) {
      stop("Provide either stage1_state_rds or stage1_tsv (existing file).")
    }
    pep <- data.table::fread(stage1_tsv, sep = "\t", header = TRUE, data.table = FALSE)
  }
  
  pep <- as.data.frame(pep, stringsAsFactors = FALSE)
  if (!("Peptide" %in% names(pep))) stop("Stage1 table missing 'Peptide' column.")
  
  # --- gene column detection ---
  gene_candidates <- c("ProteinID.x", "ProteinID", "ID")
  gene_col <- gene_candidates[gene_candidates %in% names(pep)][1]
  if (is.na(gene_col) || is.null(gene_col)) {
    stop("Stage1 table must contain one of these gene columns: ProteinID.x / ProteinID / ID.")
  }
  
  # --- rank column detection (prefer winner_rank) ---
  rank_candidates <- c("winner_rank", "winner_rank.x", "winner_rank.y", "rank", "Rank")
  rank_col <- rank_candidates[rank_candidates %in% names(pep)][1]
  if (is.na(rank_col) || is.null(rank_col)) rank_col <- NULL
  
  # --- normalize peptide + gene ---
  pep$Peptide <- toupper(trimws(as.character(pep$Peptide)))
  pep[[gene_col]] <- trimws(as.character(pep[[gene_col]]))
  pep$pep_len <- nchar(pep$Peptide)
  
  # --- parse mean winner_rank per peptide row (split numeric tokens, take mean) ---
  parse_rank_mean <- function(x) {
    x <- as.character(x)
    x[is.na(x)] <- ""
    nums_list <- regmatches(
      x,
      gregexpr("[-+]?[0-9]*\\.?[0-9]+([eE][-+]?[0-9]+)?", x, perl = TRUE)
    )
    vapply(nums_list, function(v) {
      if (!length(v)) return(NA_real_)
      vv <- suppressWarnings(as.numeric(v))
      vv <- vv[is.finite(vv)]
      if (!length(vv)) NA_real_ else mean(vv)
    }, numeric(1))
  }
  
  # --- build unique peptide table (gene + peptide), store peptide_mean_rank ---
  pep_dt <- data.table::as.data.table(pep)
  pep_dt <- pep_dt[!is.na(Peptide) & nchar(Peptide) > 0]
  pep_dt[, pep_len := nchar(Peptide)]
  
  if (!is.null(rank_col)) {
    pep_dt[, pep_rank_row := parse_rank_mean(get(rank_col))]
  } else {
    pep_dt[, pep_rank_row := NA_real_]
  }
  
  # aggregate duplicates (gene, peptide): mean rank across rows, length = max
  pep_u <- pep_dt[, .(
    pep_len = suppressWarnings(max(pep_len, na.rm = TRUE)),
    pep_rank = {
      v <- pep_rank_row[is.finite(pep_rank_row)]
      if (length(v)) mean(v) else NA_real_
    }
  ), by = c(gene_col, "Peptide")]
  
  # --- load TPM / 3CA ---
  load_tpm <- function(path) {
    if (is.null(path) || !nzchar(path) || !file.exists(path)) return(NULL)
    
    safe_sheets <- tryCatch(readxl::excel_sheets(path), error = function(e) character(0))
    
    read_sheet <- function(sheet = NULL) {
      tryCatch(
        as.data.frame(
          readxl::read_excel(path, sheet = sheet, .name_repair = "unique_quiet"),
          stringsAsFactors = FALSE
        ),
        error = function(e) NULL
      )
    }
    
    df_gene <- NULL
    df_header <- NULL
    
    if (length(safe_sheets)) {
      if ("TPM_gene" %in% safe_sheets) df_gene <- read_sheet("TPM_gene")
      if ("TPM_header" %in% safe_sheets) df_header <- read_sheet("TPM_header")
      if (is.null(df_gene) && is.null(df_header)) df_gene <- read_sheet(safe_sheets[1])
    } else {
      df_gene <- read_sheet(NULL)
    }
    
    pick_col <- function(df, patterns) {
      if (is.null(df) || !nrow(df)) return(NA_character_)
      nm <- names(df)
      for (pat in patterns) {
        hit <- grep(pat, nm, ignore.case = TRUE, value = TRUE)
        if (length(hit)) return(hit[1])
      }
      NA_character_
    }
    
    by_gene <- NULL
    if (!is.null(df_gene) && nrow(df_gene) && ncol(df_gene) >= 2) {
      gcol <- pick_col(df_gene, c("^hugo$", "^gene$", "hgnc", "symbol"))
      tcol <- pick_col(df_gene, c("^tpm$", "tpm"))
      ecol <- pick_col(df_gene, c("^ensg$", "ensembl_gene", "ensemblgene", "ensemblgeneid"))
      
      if (is.na(gcol)) gcol <- names(df_gene)[1]
      if (is.na(tcol)) tcol <- names(df_gene)[2]
      
      by_gene <- data.frame(
        HUGO = trimws(as.character(df_gene[[gcol]])),
        TPM = suppressWarnings(as.numeric(df_gene[[tcol]])),
        ENSG = if (!is.na(ecol)) trimws(as.character(df_gene[[ecol]])) else NA_character_,
        stringsAsFactors = FALSE
      )
      by_gene$HUGO[by_gene$HUGO == ""] <- NA_character_
      by_gene <- by_gene[!is.na(by_gene$HUGO) & nzchar(by_gene$HUGO), , drop = FALSE]
    }
    
    by_header <- NULL
    if (!is.null(df_header) && nrow(df_header) && ncol(df_header) >= 2) {
      hcol <- pick_col(df_header, c("^header$", "^id$", "^alias$"))
      gcol <- pick_col(df_header, c("^gene$", "^hugo$", "hgnc", "symbol"))
      tcol <- pick_col(df_header, c("transcript", "^tid$", "enst"))
      tpmc <- pick_col(df_header, c("^tpm$", "tpm"))
      ecol <- pick_col(df_header, c("^ensg$", "ensembl_gene", "ensemblgene", "ensemblgeneid"))
      
      if (!is.na(hcol) && !is.na(tpmc)) {
        by_header <- data.frame(
          Header = trimws(as.character(df_header[[hcol]])),
          HUGO = if (!is.na(gcol)) trimws(as.character(df_header[[gcol]])) else NA_character_,
          TranscriptID = if (!is.na(tcol)) trimws(as.character(df_header[[tcol]])) else NA_character_,
          TPM = suppressWarnings(as.numeric(df_header[[tpmc]])),
          ENSG = if (!is.na(ecol)) trimws(as.character(df_header[[ecol]])) else NA_character_,
          stringsAsFactors = FALSE
        )
        by_header$Header[by_header$Header == ""] <- NA_character_
        by_header$HUGO[by_header$HUGO == ""] <- NA_character_
        by_header$TranscriptID[by_header$TranscriptID == ""] <- NA_character_
        by_header <- by_header[!is.na(by_header$Header) & nzchar(by_header$Header), , drop = FALSE]
      }
    }
    
    if (is.null(by_gene) && is.null(by_header)) return(NULL)
    list(by_gene = by_gene, by_header = by_header)
  }
  
  load_threeca <- function(path, sheet = NULL) {
    if (is.null(path) || !nzchar(path) || !file.exists(path)) return(NULL)
    sheets <- readxl::excel_sheets(path)
    if (is.null(sheet) || !nzchar(sheet)) {
      sheet <- sheets[match("Melanoma", sheets)]
      if (is.na(sheet)) sheet <- sheets[1]
    }
    df <- as.data.frame(readxl::read_excel(path, sheet = sheet, .name_repair = "unique_quiet"))
    if (!("Gene" %in% names(df))) names(df)[1] <- "Gene"
    
    score_col <- NULL
    if ("CombinedSort" %in% names(df)) {
      score_col <- "CombinedSort"
    } else {
      num_cols <- names(df)[vapply(df, function(x) {
        xx <- suppressWarnings(as.numeric(x))
        any(is.finite(xx))
      }, logical(1))]
      if (length(num_cols)) score_col <- num_cols[length(num_cols)]
    }
    if (is.null(score_col)) return(NULL)
    
    data.frame(
      HUGO = trimws(as.character(df[["Gene"]])),
      X3CA = suppressWarnings(as.numeric(df[[score_col]])),
      stringsAsFactors = FALSE
    )
  }
  
  tpm_info <- load_tpm(tpm_xlsx)
  tpm_available <- !is.null(tpm_info)
  threeca_tbl <- load_threeca(threeca_xlsx, threeca_sheet)
  
  # --- gene base table (static fields) ---
  gene_base <- pep_u[, .(
    n_peptides = .N,
    total_pep_AA = sum(pep_len, na.rm = TRUE)
  ), by = gene_col]
  data.table::setnames(gene_base, gene_col, "Gene")
  gene_tbl <- as.data.frame(gene_base)
  gene_tbl$HUGO <- NA_character_
  gene_tbl$TranscriptID <- NA_character_
  gene_tbl$ENSG <- NA_character_
  gene_tbl$TPM <- NA_real_
  gene_tbl$X3CA <- NA_real_
  
  # --- attach TPM/Transcript metadata (supports HUGO-keyed or Header-keyed TPM tables) ---
  tpm_mode <- "none"
  if (!is.null(tpm_info)) {
    keys <- unique(as.character(gene_tbl$Gene))
    ov_gene <- 0
    ov_header <- 0
    if (!is.null(tpm_info$by_gene) && nrow(tpm_info$by_gene)) {
      ov_gene <- mean(keys %in% as.character(tpm_info$by_gene$HUGO))
    }
    if (!is.null(tpm_info$by_header) && nrow(tpm_info$by_header)) {
      ov_header <- mean(keys %in% as.character(tpm_info$by_header$Header))
    }
    
    use_header <- isTRUE(ov_header > ov_gene) && isTRUE(ov_header > 0)
    
    if (use_header && !is.null(tpm_info$by_header) && nrow(tpm_info$by_header)) {
      tpm_mode <- "header"
      idx <- match(gene_tbl$Gene, tpm_info$by_header$Header)
      gene_tbl$TPM <- tpm_info$by_header$TPM[idx]
      gene_tbl$HUGO <- tpm_info$by_header$HUGO[idx]
      gene_tbl$TranscriptID <- tpm_info$by_header$TranscriptID[idx]
      gene_tbl$ENSG <- tpm_info$by_header$ENSG[idx]
    } else if (!is.null(tpm_info$by_gene) && nrow(tpm_info$by_gene)) {
      tpm_mode <- "gene"
      idx <- match(gene_tbl$Gene, tpm_info$by_gene$HUGO)
      gene_tbl$TPM <- tpm_info$by_gene$TPM[idx]
      gene_tbl$ENSG <- tpm_info$by_gene$ENSG[idx]
      gene_tbl$HUGO <- as.character(gene_tbl$Gene)
      
      # If header-level sheet exists, aggregate TranscriptID per gene
      if (!is.null(tpm_info$by_header) && nrow(tpm_info$by_header)) {
        agg_tid <- tapply(
          tpm_info$by_header$TranscriptID,
          tpm_info$by_header$HUGO,
          function(v) {
            v <- unique(v[!is.na(v) & nzchar(v)])
            if (!length(v)) NA_character_ else paste(v, collapse = ",")
          }
        )
        gene_tbl$TranscriptID <- unname(agg_tid[gene_tbl$Gene])
      }
    }
    
    gene_tbl$HUGO[is.na(gene_tbl$HUGO) | !nzchar(gene_tbl$HUGO)] <- as.character(gene_tbl$Gene)
  }
  
  # --- attach 3CA (always gene-level: merge on HUGO if available, else Gene key) ---
  if (!is.null(threeca_tbl) && nrow(threeca_tbl)) {
    key3 <- ifelse(!is.na(gene_tbl$HUGO) & nzchar(gene_tbl$HUGO), gene_tbl$HUGO, gene_tbl$Gene)
    idx <- match(key3, threeca_tbl$HUGO)
    gene_tbl$X3CA <- threeca_tbl$X3CA[idx]
  }
  
  gene_tbl <- gene_tbl[order(gene_tbl$Gene), , drop = FALSE]
  
  # --- slider ranges (rank is peptide-level mean winner_rank) ---
  tpm_max <- gene_tbl$TPM[is.finite(gene_tbl$TPM)]
  tpm_max <- if (length(tpm_max)) max(tpm_max) else 0
  
  x3ca_max <- gene_tbl$X3CA[is.finite(gene_tbl$X3CA)]
  x3ca_max <- if (length(x3ca_max)) max(x3ca_max) else 0
  
  pep_rank_vals <- pep_u$pep_rank[is.finite(pep_u$pep_rank)]
  rank_min <- if (length(pep_rank_vals)) min(pep_rank_vals) else 0
  rank_max <- if (length(pep_rank_vals)) max(pep_rank_vals) else 1
  if (!is.finite(rank_min)) rank_min <- 0
  if (!is.finite(rank_max) || rank_max <= rank_min) rank_max <- max(1, rank_min + 1e-6)
  
  rank_init <- max(0.5, rank_min)
  use_rank_default <- !is.null(rank_col)
  
  # ---------- fixed axis specs for TPM vs 3CA (constant) ----------
  pad_range <- function(x, frac = 0.03, force_include0 = TRUE) {
    x <- x[is.finite(x)]
    if (!length(x)) return(c(0, 1))
    lo <- min(x); hi <- max(x)
    if (force_include0) lo <- min(lo, 0)
    if (lo == hi) {
      d <- if (lo == 0) 1 else abs(lo) * 0.1
      return(c(lo - d, hi + d))
    }
    d <- (hi - lo) * frac
    c(lo - d, hi + d)
  }
  nice_dtick <- function(lo, hi, n = 6) {
    span <- hi - lo
    if (!is.finite(span) || span <= 0) return(1)
    raw <- span / max(1, (n - 1))
    base <- 10^floor(log10(raw))
    mult <- c(1, 2, 5, 10)
    cand <- base * mult
    cand[which.min(abs(cand - raw))]
  }
  axis_spec <- function(rng, n = 6) {
    lo <- rng[1]; hi <- rng[2]
    dtick <- nice_dtick(lo, hi, n = n)
    tick0 <- dtick * floor(lo / dtick)
    dec <- if (!is.finite(dtick) || dtick >= 1) 0 else max(0, -floor(log10(dtick)) + 1)
    tickformat <- paste0(",.", dec, "f")
    list(range = c(lo, hi), tick0 = tick0, dtick = dtick, tickformat = tickformat)
  }
  
  axis_base <- gene_tbl
  axis_base$TPM_axis <- axis_base$TPM; axis_base$TPM_axis[is.na(axis_base$TPM_axis)] <- 0
  axis_base$X3CA_axis <- axis_base$X3CA; axis_base$X3CA_axis[is.na(axis_base$X3CA_axis)] <- 0
  
  TPM_AX  <- axis_spec(pad_range(axis_base$TPM_axis,  frac = 0.03, force_include0 = TRUE), n = 6)
  X3CA_AX <- axis_spec(pad_range(axis_base$X3CA_axis, frac = 0.03, force_include0 = TRUE), n = 6)
  
  # ---------- UI ----------
  ui <- shiny::fluidPage(
    shiny::titlePanel("TAPAS: Interactive filter (TPM / 3CA / peptide-rank / include genes)"),
    shiny::sidebarLayout(
      shiny::sidebarPanel(
        shiny::helpText(paste0(
          "Stage1 genes: ", nrow(gene_tbl),
          "  |  Unique gene-peptides: ", nrow(pep_u),
          if (!is.null(rank_col)) paste0("  |  Rank source: ", rank_col, " (per-peptide mean)") else "  |  Rank source: (none found)"
        )),
        
        shiny::checkboxInput("use_tpm", "Use TPM filter (>=)", value = isTRUE(tpm_available)),
        shiny::fluidRow(
          shiny::column(7, shiny::sliderInput("tpm_thr", NULL, min = 0, max = tpm_max, value = 0, step = 0.1)),
          shiny::column(5, shiny::numericInput("tpm_thr_num", "TPM", value = 0, min = 0, max = tpm_max, step = 0.1))
        ),
        
        shiny::checkboxInput("use_3ca", "Use 3CA filter (>=)", value = !is.null(threeca_tbl)),
        shiny::fluidRow(
          shiny::column(7, shiny::sliderInput("x3ca_thr", NULL, min = 0, max = x3ca_max, value = 0, step = 0.1)),
          shiny::column(5, shiny::numericInput("x3ca_thr_num", "3CA", value = 0, min = 0, max = x3ca_max, step = 0.1))
        ),
        
        shiny::checkboxInput("use_rank", "Use peptide rank filter (mean winner_rank <=)", value = use_rank_default),
        shiny::fluidRow(
          shiny::column(7, shiny::sliderInput("rank_thr", NULL, min = rank_min, max = rank_max,
                                              value = rank_init, step = 0.01)),
          shiny::column(5, shiny::numericInput("rank_thr_num", "Rank", value = rank_init,
                                               min = rank_min, max = rank_max, step = 0.01))
        ),
        
        shiny::checkboxInput("na0", "Plot NA as 0 (TPM/3CA only)", value = isTRUE(na_as_zero_for_plots)),
        shiny::tags$hr(),
        shiny::helpText("AUTO-tick all threshold-pass genes. You may untick/tick any gene. Priority: tick > untick."),
        shiny::actionButton("export_btn", "Export & Close"),
        shiny::tags$hr(),
        shiny::verbatimTextOutput("summary_txt")
      ),
      
      shiny::mainPanel(
        shiny::h4("Gene table (ticked = kept; auto-tick by thresholds; tick overrides untick)"),
        DT::DTOutput("gene_dt"),
        shiny::tags$hr(),
        shiny::fluidRow(
          shiny::column(6, plotly::plotlyOutput("p_tpm3ca", height = "340px")),
          shiny::column(6, plotly::plotlyOutput("p_gene_frac", height = "340px"))
        )
      )
    )
  )
  
  # ---------- SERVER ----------
  server <- function(input, output, session) {
    
    # ---- slider <-> numeric sync ----
    shiny::observeEvent(input$tpm_thr, {
      shiny::updateNumericInput(session, "tpm_thr_num", value = input$tpm_thr)
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$tpm_thr_num, {
      v <- suppressWarnings(as.numeric(input$tpm_thr_num))
      if (is.finite(v)) shiny::updateSliderInput(session, "tpm_thr", value = v)
    }, ignoreInit = TRUE)
    
    shiny::observeEvent(input$x3ca_thr, {
      shiny::updateNumericInput(session, "x3ca_thr_num", value = input$x3ca_thr)
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$x3ca_thr_num, {
      v <- suppressWarnings(as.numeric(input$x3ca_thr_num))
      if (is.finite(v)) shiny::updateSliderInput(session, "x3ca_thr", value = v)
    }, ignoreInit = TRUE)
    
    shiny::observeEvent(input$rank_thr, {
      shiny::updateNumericInput(session, "rank_thr_num", value = input$rank_thr)
    }, ignoreInit = TRUE)
    shiny::observeEvent(input$rank_thr_num, {
      v <- suppressWarnings(as.numeric(input$rank_thr_num))
      if (is.finite(v)) shiny::updateSliderInput(session, "rank_thr", value = v)
    }, ignoreInit = TRUE)
    
    # ----------------------------
    # USER OVERRIDES (tick/untick)
    # ----------------------------
    force_tick   <- shiny::reactiveVal(character(0))  # explicit tick (force include)
    force_untick <- shiny::reactiveVal(character(0))  # explicit untick (force exclude)
    
    # ----------------------------
    # DEBOUNCED thresholds (smooth UI)
    # ----------------------------
    thr_state <- shiny::reactive({
      list(
        use_tpm  = isTRUE(input$use_tpm),
        tpm_thr  = suppressWarnings(as.numeric(input$tpm_thr)),
        use_3ca  = isTRUE(input$use_3ca),
        x3ca_thr = suppressWarnings(as.numeric(input$x3ca_thr)),
        use_rank = isTRUE(input$use_rank),
        rank_thr = suppressWarnings(as.numeric(input$rank_thr))
      )
    })
    thr_state_d <- shiny::debounce(thr_state, millis = 200)
    
    # ---- helper: compute rank-pass peptide AA length per gene ----
    compute_rankpass_len <- function(use_rank, rank_thr) {
      dt <- pep_u
      if (isTRUE(use_rank)) {
        # NA rank: keep (do not drop missing)
        dt <- dt[is.na(pep_rank) | pep_rank <= rank_thr, ]
      }
      if (!nrow(dt)) return(setNames(rep(0, nrow(gene_tbl)), gene_tbl$Gene))
      
      agg <- dt[, .(rankpass_pep_AA = sum(pep_len, na.rm = TRUE)), by = .(Gene = get(gene_col))]
      m <- match(gene_tbl$Gene, agg$Gene)
      out <- rep(0, nrow(gene_tbl))
      out[!is.na(m)] <- agg$rankpass_pep_AA[m[!is.na(m)]]
      setNames(out, gene_tbl$Gene)
    }
    
    # ---- gene status table (reactive) ----
    gene_status <- shiny::reactive({
      st <- thr_state_d()
      
      dt <- gene_tbl
      dt$rankpass_pep_AA <- as.numeric(compute_rankpass_len(st$use_rank, st$rank_thr))
      
      pass <- rep(TRUE, nrow(dt))
      
      if (isTRUE(st$use_tpm)) {
        pass <- pass & (is.na(dt$TPM) | dt$TPM >= st$tpm_thr)
      }
      if (isTRUE(st$use_3ca)) {
        pass <- pass & (is.na(dt$X3CA) | dt$X3CA >= st$x3ca_thr)
      }
      if (isTRUE(st$use_rank)) {
        pass <- pass & (dt$rankpass_pep_AA > 0)
      }
      
      dt$pass_thresholds <- pass
      dt
    })
    
    pass_genes <- shiny::reactive({
      dt <- gene_status()
      as.character(dt$Gene[dt$pass_thresholds])
    })
    
    kept_genes <- shiny::reactive({
      allg <- as.character(gene_tbl$Gene)
      
      pg <- intersect(pass_genes(), allg)
      ft <- intersect(force_tick(), allg)
      fu <- intersect(force_untick(), allg)
      
      # tick wins: kept = ft U (pg \ fu)
      unique(c(ft, setdiff(pg, fu)))
    })
    
    # ---- DT table data ----
    make_gene_table_df <- function(use_rank, rank_thr) {
      dt <- gene_tbl
      dt$rankpass_pep_AA <- as.numeric(compute_rankpass_len(use_rank, rank_thr))
      dt <- dt[, c("Gene", "HUGO", "TranscriptID", "ENSG",
                   "n_peptides", "total_pep_AA", "rankpass_pep_AA", "TPM", "X3CA"), drop = FALSE]
      names(dt) <- c("Gene", "HUGO", "TranscriptID", "ENSG",
                     "n_peptides", "total_pep_AA", "pep_AA_after_rank", "TPM", "X3CA")
      dt[order(dt$Gene), , drop = FALSE]
    }
    
    rank_state <- shiny::reactive({
      list(
        use_rank = isTRUE(input$use_rank),
        rank_thr = suppressWarnings(as.numeric(input$rank_thr))
      )
    })
    rank_state_d <- shiny::debounce(rank_state, millis = 200)
    
    gene_dt_data <- shiny::reactive({
      rs <- rank_state_d()
      make_gene_table_df(rs$use_rank, rs$rank_thr)
    })
    
    output$gene_dt <- DT::renderDT({
      dt_show <- cbind(Select = "", gene_dt_data())
      
      cb <- DT::JS(sprintf(
        "
        window._xassembly_gene_dt = table;

        function selectedGenes(){
          return table.rows({selected:true}).data().toArray().map(function(r){ return r[1]; });
        }

        function sendSelectedList(){
          Shiny.setInputValue('%s', selectedGenes(), {priority: 'event'});
        }

        function sendToggle(gene, selected){
          Shiny.setInputValue('gene_dt_user_toggle',
            {gene: String(gene), selected: !!selected, nonce: Date.now()},
            {priority:'event'}
          );
        }

        table.on('select.dt', function(e, dt, type, indexes){
          if (table.settings()[0]._isAutoSelecting) return;
          var row = table.row(indexes[0]).data();
          if (row && row.length >= 2) sendToggle(row[1], true);
          sendSelectedList();
        });
        table.on('deselect.dt', function(e, dt, type, indexes){
          if (table.settings()[0]._isAutoSelecting) return;
          var row = table.row(indexes[0]).data();
          if (row && row.length >= 2) sendToggle(row[1], false);
          sendSelectedList();
        });

        if (!window._xassembly_gene_dt_handler_installed){
          window._xassembly_gene_dt_handler_installed = true;

          Shiny.addCustomMessageHandler('gene_dt_set_selection', function(genes){
            var t = window._xassembly_gene_dt;
            if (!t) return;

            var set = {};
            (genes || []).forEach(function(g){ set[String(g)] = true; });

            t.settings()[0]._isAutoSelecting = true;

            t.rows({selected:true}).deselect();
            t.rows().every(function(){
              var d = this.data();
              var gene = d[1];
              if (set[String(gene)]) this.select();
            });

            t.settings()[0]._isAutoSelecting = false;
            sendSelectedList();
          });
        }

        if (!table.settings()[0]._sentInit){
          table.settings()[0]._sentInit = true;
          sendSelectedList();
          Shiny.setInputValue('gene_dt_ready', Date.now(), {priority: 'event'});
        }
        ",
        "gene_dt_selected_genes"
      ))
      
      DT::datatable(
        dt_show,
        rownames = FALSE,
        selection = "none",
        extensions = "Select",
        callback = cb,
        options = list(
          pageLength = 12,
          scrollX = TRUE,
          deferRender = TRUE,
          select = list(style = "multi", selector = "td:first-child"),
          columnDefs = list(
            list(orderable = FALSE, className = "select-checkbox", targets = 0),
            list(width = "20px", targets = 0)
          )
        )
      )
    }, server = FALSE)
    
    shiny::observeEvent(input$gene_dt_ready, {
      session$sendCustomMessage("gene_dt_set_selection", kept_genes())
    }, ignoreInit = TRUE)
    
    shiny::observeEvent(kept_genes(), {
      session$sendCustomMessage("gene_dt_set_selection", kept_genes())
    }, ignoreInit = TRUE)
    
    shiny::observeEvent(input$gene_dt_user_toggle, {
      evt <- input$gene_dt_user_toggle
      if (is.null(evt$gene)) return(NULL)
      
      g <- as.character(evt$gene)
      sel <- isTRUE(evt$selected)
      
      allg <- as.character(gene_tbl$Gene)
      if (!(g %in% allg)) return(NULL)
      
      ft <- intersect(force_tick(), allg)
      fu <- intersect(force_untick(), allg)
      
      if (sel) {
        ft <- unique(c(ft, g))
        fu <- setdiff(fu, g)
      } else {
        fu <- unique(c(fu, g))
        ft <- setdiff(ft, g)
      }
      
      force_tick(ft)
      force_untick(fu)
    }, ignoreInit = TRUE)
    
    # --- status table for plots ---
    status_tbl <- shiny::reactive({
      gs <- gene_status()
      
      ft <- gs$Gene %in% force_tick()
      fu <- gs$Gene %in% force_untick()
      
      gs$forced_tick <- ft
      gs$forced_untick <- fu
      
      # tick wins
      gs$kept <- gs$forced_tick | (gs$pass_thresholds & !gs$forced_untick)
      gs$keep_label <- ifelse(gs$kept, "Kept", "Filtered out")
      
      gs
    })
    
    # --- kept peptides table (unique gene+peptide) ---
    kept_peptides_u <- shiny::reactive({
      st <- thr_state_d()
      kg <- kept_genes()
      
      dt <- pep_u[get(gene_col) %in% kg, ]
      if (isTRUE(st$use_rank)) {
        dt <- dt[is.na(pep_rank) | pep_rank <= st$rank_thr, ]
      }
      dt
    })
    
    # --- filtered peptides (full original pep rows subset by kept gene+peptide) ---
    filtered_peptides <- shiny::reactive({
      dt_keep <- kept_peptides_u()
      if (!nrow(dt_keep)) return(pep[0, , drop = FALSE])
      
      key_keep <- paste(dt_keep[[gene_col]], dt_keep$Peptide, sep = "::")
      key_all  <- paste(pep[[gene_col]], pep$Peptide, sep = "::")
      sub <- pep[key_all %in% key_keep, , drop = FALSE]
      
      # ---- add gene-level annotations WITHOUT merge (avoid row duplication / reorder) ----
      gs <- status_tbl()[, c("Gene", "HUGO", "TranscriptID", "ENSG", "TPM", "X3CA", "rankpass_pep_AA", "total_pep_AA"), drop = FALSE]
      names(gs)[1] <- gene_col
      names(gs)[names(gs) == "rankpass_pep_AA"] <- "gene_pep_AA_after_rank"
      names(gs)[names(gs) == "total_pep_AA"] <- "gene_total_pep_AA"
      
      gidx <- match(sub[[gene_col]], gs[[gene_col]])
      for (nm in setdiff(names(gs), gene_col)) {
        sub[[nm]] <- gs[[nm]][gidx]
      }
      
      # ---- add per-peptide mean rank WITHOUT merge ----
      dt_r <- as.data.frame(dt_keep[, c(gene_col, "Peptide", "pep_rank"), with = FALSE])
      names(dt_r)[names(dt_r) == "pep_rank"] <- "pep_rank_mean"
      rk_key <- paste(dt_r[[gene_col]], dt_r$Peptide, sep = "::")
      sub$pep_rank_mean <- dt_r$pep_rank_mean[
        match(paste(sub[[gene_col]], sub$Peptide, sep = "::"), rk_key)
      ]
      
      sub
    })
    
    output$summary_txt <- shiny::renderText({
      fp <- filtered_peptides()
      gene_n <- length(unique(fp[[gene_col]]))
      pep_n  <- length(unique(fp$Peptide))
      aa_sum <- sum(nchar(unique(fp$Peptide)), na.rm = TRUE)
      
      stg <- status_tbl()
      n_pass <- sum(stg$pass_thresholds, na.rm = TRUE)
      n_ft   <- sum(stg$forced_tick, na.rm = TRUE)
      n_fu   <- sum(stg$forced_untick, na.rm = TRUE)
      
      paste0(
        "Kept genes: ", gene_n, "\n",
        "Unique peptides (kept): ", pep_n, "\n",
        "Sum AA length (unique kept peptides): ", aa_sum, "\n",
        "Pass thresholds (auto-tick): ", n_pass, "\n",
        "Forced tick: ", n_ft, "\n",
        "Forced untick: ", n_fu, "\n",
        "Export folder: ", out_dir
      )
    })
    
    # ----------------------------
    # Plot configs (no zoom, fixed ticks)
    # ----------------------------
    plot_config <- function(p) {
      plotly::config(
        p,
        scrollZoom = FALSE,
        doubleClick = FALSE,
        displayModeBar = FALSE
      )
    }
    
    # threshold shapes for TPM vs 3CA
    thr_shapes_tpm3ca <- function(st) {
      sh <- list()
      if (isTRUE(st$use_tpm) && is.finite(st$tpm_thr)) {
        sh <- c(sh, list(list(
          type = "line",
          x0 = st$tpm_thr, x1 = st$tpm_thr,
          y0 = X3CA_AX$range[1], y1 = X3CA_AX$range[2],
          line = list(dash = "dash", width = 1)
        )))
      }
      if (isTRUE(st$use_3ca) && is.finite(st$x3ca_thr)) {
        sh <- c(sh, list(list(
          type = "line",
          x0 = TPM_AX$range[1], x1 = TPM_AX$range[2],
          y0 = st$x3ca_thr, y1 = st$x3ca_thr,
          line = list(dash = "dash", width = 1)
        )))
      }
      sh
    }
    
    # ---- TPM vs 3CA scatter (genes; kept red) ----
    output$p_tpm3ca <- plotly::renderPlotly({
      st <- thr_state_d()
      dt <- status_tbl()
      
      dt$TPM_plot <- dt$TPM
      dt$X3CA_plot <- dt$X3CA
      if (isTRUE(input$na0)) {
        dt$TPM_plot[is.na(dt$TPM_plot)] <- 0
        dt$X3CA_plot[is.na(dt$X3CA_plot)] <- 0
      }
      
      cols <- ifelse(dt$kept, "red", "black")
      hover <- paste0(
        "Key: ", dt$Gene,
        ifelse(!is.na(dt$HUGO) & nzchar(dt$HUGO) & dt$HUGO != dt$Gene, paste0("<br>HUGO: ", dt$HUGO), ""),
        ifelse(!is.na(dt$TranscriptID) & nzchar(dt$TranscriptID), paste0("<br>TranscriptID: ", dt$TranscriptID), ""),
        ifelse(!is.na(dt$ENSG) & nzchar(dt$ENSG), paste0("<br>ENSG: ", dt$ENSG), ""),
        "<br>Status: ", dt$keep_label,
        "<br>TPM: ", ifelse(is.na(dt$TPM), "NA", dt$TPM),
        "<br>3CA: ", ifelse(is.na(dt$X3CA), "NA", dt$X3CA),
        "<br>Rank-pass pep AA: ", dt$rankpass_pep_AA,
        "<br>Total pep AA: ", dt$total_pep_AA
      )
      
      p <- plotly::plot_ly(
        data = dt,
        x = ~TPM_plot, y = ~X3CA_plot,
        type = "scattergl", mode = "markers",
        text = hover, hoverinfo = "text",
        marker = list(color = cols, size = 6, opacity = 0.85)
      )
      
      p <- plotly::layout(
        p,
        margin = list(l = 55, r = 10, t = 10, b = 55),
        xaxis = list(
          title = "TPM",
          range = TPM_AX$range, autorange = FALSE, fixedrange = TRUE,
          tickmode = "linear", tick0 = TPM_AX$tick0, dtick = TPM_AX$dtick,
          tickformat = TPM_AX$tickformat, showexponent = "none"
        ),
        yaxis = list(
          title = "3CA",
          range = X3CA_AX$range, autorange = FALSE, fixedrange = TRUE,
          tickmode = "linear", tick0 = X3CA_AX$tick0, dtick = X3CA_AX$dtick,
          tickformat = X3CA_AX$tickformat, showexponent = "none"
        ),
        shapes = thr_shapes_tpm3ca(st)
      )
      
      plot_config(p)
    })
    
    # ---- Bar plot: gene peptide AA fraction among kept peptides ----
    output$p_gene_frac <- plotly::renderPlotly({
      dt_keep <- kept_peptides_u()
      if (!nrow(dt_keep)) {
        p <- plotly::plot_ly(x = character(0), y = numeric(0), type = "bar")
        p <- plotly::layout(
          p,
          xaxis = list(title = "Gene", fixedrange = TRUE),
          yaxis = list(title = "Fraction of kept peptide AA", range = c(0, 1), fixedrange = TRUE, tickformat = ".1%")
        )
        return(plot_config(p))
      }
      
      agg <- dt_keep[, .(pep_AA = sum(pep_len, na.rm = TRUE)), by = .(Gene = get(gene_col))]
      total_AA <- sum(agg$pep_AA, na.rm = TRUE)
      agg[, frac := if (total_AA > 0) pep_AA / total_AA else 0]
      
      agg <- agg[order(-frac)]
      if (nrow(agg) > 200) {
        top_n <- 60
        top <- agg[1:top_n]
        other <- agg[(top_n + 1):.N, .(Gene = "Others", pep_AA = sum(pep_AA), frac = sum(frac))]
        agg <- data.table::rbindlist(list(top, other), use.names = TRUE, fill = TRUE)
      }
      
      hover <- paste0(
        "Gene: ", agg$Gene,
        "<br>Kept pep AA: ", agg$pep_AA,
        "<br>Fraction: ", sprintf("%.2f%%", 100 * agg$frac)
      )
      
      p <- plotly::plot_ly(
        data = agg,
        x = ~Gene, y = ~frac,
        type = "bar",
        text = hover, hoverinfo = "text"
      )
      
      p <- plotly::layout(
        p,
        margin = list(l = 65, r = 10, t = 10, b = 120),
        xaxis = list(title = "Gene", fixedrange = TRUE, tickangle = 60),
        yaxis = list(title = "Fraction of kept peptide AA", range = c(0, 1), fixedrange = TRUE, tickformat = ".1%", dtick = 0.1)
      )
      
      plot_config(p)
    })
    
    # ---- Export (robust IO + guard huge pairing) ----
    shiny::observeEvent(input$export_btn, {
      shiny::withProgress(message = "Exporting...", value = 0, {
        tryCatch({
          
          incProgress(0.05, detail = "Preparing filtered peptides")
          fp_raw <- filtered_peptides()
          if (nrow(fp_raw) == 0) {
            shiny::showModal(shiny::modalDialog("No peptides after filtering.", easyClose = TRUE))
            return(NULL)
          }
          
          # sanitize for stable TSV/CSV
          fp <- sanitize_for_export(fp_raw)
          
          # ---- write peptide tables (robust, Excel-friendly) ----
          incProgress(0.12, detail = "Writing peptide tables")
          filtered_tsv <- file.path(out_dir, paste0(out_base, "_peptides_filtered.tsv"))
          filtered_csv <- file.path(out_dir, paste0(out_base, "_peptides_filtered.csv"))
          filtered_csv2 <- file.path(out_dir, paste0(out_base, "_peptides_filtered_excel_semicolon.csv"))
          
          readr::write_tsv(fp, filtered_tsv, na = "NA")
          readr::write_excel_csv(fp, filtered_csv, na = "NA")
          readr::write_excel_csv2(fp, filtered_csv2, na = "NA")
          
          # ---- Optional TPM filtered workbook ----
          incProgress(0.22, detail = "Writing TPM summary (optional)")
          tpm_filtered_xlsx <- NULL
          if (isTRUE(tpm_available)) {
            gt <- status_tbl()
            gt_keep <- gt[gt$kept, , drop = FALSE]
            if (nrow(gt_keep)) {
              tpm_filtered_xlsx <- file.path(out_dir, paste0(out_base, "_TPM_filtered.xlsx"))
              gt_out <- gt_keep[, c("Gene", "HUGO", "TranscriptID", "ENSG", "TPM", "X3CA",
                                    "n_peptides", "rankpass_pep_AA", "total_pep_AA"), drop = FALSE]
              try(writexl::write_xlsx(list(TPM_filtered = gt_out), tpm_filtered_xlsx), silent = TRUE)
              if (!file.exists(tpm_filtered_xlsx)) tpm_filtered_xlsx <- NULL
            }
          }
          
          # ---- Prepare peptides and AB map ----
          incProgress(0.32, detail = "Preparing AB pairs / NetChop FASTA")
          keep_peps <- unique(toupper(fp$Peptide))
          keep_peps <- keep_peps[!is.na(keep_peps) & nzchar(keep_peps)]
          
          map_out <- NULL
          fasta_out <- NULL
          map_csv_out <- NULL
          can_reuse_netchop <- FALSE
          
          # Guard: avoid "freeze" due to enormous AB pairing
          max_pairs <- 2e6
          est_pairs <- NA_real_
          
          md <- NULL
          if (!is.null(map_dt)) {
            md <- as.data.frame(map_dt, stringsAsFactors = FALSE)
            if (nrow(md)) {
              if ("A" %in% names(md)) md$A <- toupper(trimws(as.character(md$A)))
              if ("B" %in% names(md)) md$B <- toupper(trimws(as.character(md$B)))
              if (all(c("A", "B") %in% names(md))) {
                md <- md[md$A %in% keep_peps & md$B %in% keep_peps, , drop = FALSE]
              } else {
                md <- md[0, , drop = FALSE]
              }
            }
            est_pairs <- nrow(md)
          } else {
            npep <- length(unique(keep_peps))
            est_pairs <- npep * (npep - 1)
          }
          
          if (is.finite(est_pairs) && est_pairs > max_pairs) {
            shiny::showModal(shiny::modalDialog(
              title = "Too many AB pairs to export",
              paste0(
                "Estimated AB pairs: ", format(est_pairs, big.mark = ","),
                "\nThis will be extremely slow / may freeze the UI.\n\n",
                "Fix options:\n",
                "1) Provide stage1_state_rds (recommended) so we can reuse existing pep_id map.\n",
                "2) Reduce kept peptides (stricter thresholds / untick genes).\n",
                "3) Increase max_pairs only if you really want huge exports."
              ),
              easyClose = TRUE
            ))
            return(NULL)
          }
          
          incProgress(0.48, detail = "Building map table")
          if (!is.null(md) && nrow(md) > 0) {
            can_reuse_netchop <- TRUE
            map_out <- md
          } else {
            peps_u2 <- unique(keep_peps)
            if (length(peps_u2) < 2) {
              shiny::showModal(shiny::modalDialog("Need >=2 peptides to generate AB map.", easyClose = TRUE))
              return(NULL)
            }
            idx <- data.table::CJ(i = seq_along(peps_u2), j = seq_along(peps_u2), unique = TRUE)
            idx <- idx[idx$i != idx$j, , drop = FALSE]
            map_out <- data.frame(
              row_idx = seq_len(nrow(idx)),
              A = peps_u2[idx$i],
              B = peps_u2[idx$j],
              stringsAsFactors = FALSE
            )
            map_out$A_len <- nchar(map_out$A)
            map_out$combo_peptide <- paste0(map_out$A, map_out$B)
            map_out$pep_id <- sprintf("pep%06d", map_out$row_idx)
          }
          
          # ---- write map csv ----
          incProgress(0.62, detail = "Writing AB map (CSV)")
          map_csv_out <- file.path(out_dir, paste0(out_base, "_AB_pairs_map_filtered.csv"))
          data.table::fwrite(map_out, map_csv_out, sep = ",", quote = TRUE, na = "NA")
          
          # ---- write NetChop FASTA (vectorized) ----
          incProgress(0.78, detail = "Writing NetChop FASTA")
          if (!("pep_id" %in% names(map_out))) map_out$pep_id <- sprintf("pep%06d", seq_len(nrow(map_out)))
          if (!("combo_peptide" %in% names(map_out))) {
            if (all(c("A", "B") %in% names(map_out))) {
              map_out$combo_peptide <- paste0(map_out$A, map_out$B)
            } else {
              stop("map_out missing combo_peptide and (A,B).")
            }
          }
          
          fasta_out <- file.path(out_dir, paste0(out_base, "_AB_pairs_for_NetChop_filtered.fasta"))
          fa_lines <- as.vector(rbind(paste0(">", map_out$pep_id), map_out$combo_peptide))
          writeLines(fa_lines, fasta_out, useBytes = TRUE)
          
          # ---- save filtered state ----
          incProgress(0.92, detail = "Saving filtered state")
          filtered_state_rds <- file.path(out_dir, paste0(out_base, "_stage1_state_filtered.rds"))
          saveRDS(
            list(
              res_pep2_merged = fp,               # sanitized export table
              res_pep2_merged_raw = fp_raw,       # raw (unsanitized) in case you need exact original text fields
              map_dt = map_out,
              peptide_tsv = filtered_tsv,
              peptide_csv = filtered_csv,
              peptide_csv2 = filtered_csv2,
              map_csv = map_csv_out,
              netchop_fasta = fasta_out,
              can_reuse_netchop = can_reuse_netchop,
              source_stage1_state_rds = stage1_state_rds,
              source_stage1_tsv = stage1_tsv,
              tpm_xlsx = tpm_xlsx,
              tpm_mode = tpm_mode,
              tpm_filtered_xlsx = tpm_filtered_xlsx,
              threeca_xlsx = threeca_xlsx,
              gene_col_used = gene_col,
              rank_col_used = rank_col,
              rank_logic = "per-peptide mean(winner_rank numeric tokens)"
            ),
            filtered_state_rds
          )
          
          incProgress(1.00, detail = "Closing app")
          shiny::stopApp(list(
            peptide_tsv = filtered_tsv,
            peptide_csv = filtered_csv,
            peptide_csv2 = filtered_csv2,
            map_csv = map_csv_out,
            netchop_fasta = fasta_out,
            stage1_state_filtered_rds = filtered_state_rds,
            tpm_filtered_xlsx = tpm_filtered_xlsx,
            can_reuse_netchop = can_reuse_netchop
          ))
          
        }, error = function(e) {
          shiny::showModal(shiny::modalDialog(
            title = "Export failed",
            paste0("ERROR: ", conditionMessage(e)),
            easyClose = TRUE
          ))
        })
      })
    }, ignoreInit = TRUE)
  }
  
  shiny::runApp(
    shiny::shinyApp(ui, server),
    launch.browser = getOption("shiny.launch.browser", TRUE)
  )
}
