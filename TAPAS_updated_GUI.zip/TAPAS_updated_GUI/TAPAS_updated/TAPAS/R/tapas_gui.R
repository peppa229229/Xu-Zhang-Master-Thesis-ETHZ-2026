#' Launch TAPAS all-in-one GUI
#'
#' Launches a Shiny application that provides a home page to run TAPAS steps
#' (FASTA preparation, Stage1, interactive filter, Stage2, manual assembly) for
#' both Class I and Class II. External prediction steps (NetMHCpan/NetMHCIIpan
#' and NetChop) are not executed in the GUI.
#'
#' @param launch_browser Logical; whether to launch in the default web browser.
#' @param ... Passed to [shiny::runApp()] (e.g. `port`, `host`).
#' @export
tapas_gui <- function(launch_browser = TRUE, ...) {
  if (!requireNamespace("shiny", quietly = TRUE)) {
    stop("Package 'shiny' is required to run TAPAS GUI.")
  }
  app_dir <- system.file("tapas_gui", package = "TAPAS")
  if (!nzchar(app_dir) || !dir.exists(app_dir)) {
    stop("TAPAS GUI app directory not found in the installed package.")
  }
  shiny::runApp(app_dir, launch.browser = isTRUE(launch_browser), ...)
}
